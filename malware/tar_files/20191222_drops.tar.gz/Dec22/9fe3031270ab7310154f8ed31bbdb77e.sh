#!/bin/bash

# envia mensagens depositadas na pasta ./msg


# ambiente
lib='/home/ti'
dir='/home/ti/bot'
tmp="/home/ti/bot/tmp"
msgs="/home/ti/bot/msg"

cd $lib

source $lib/botID.sh
source $lib/servers.sh
source $dir/ShellBot.sh





send() { # para envio de mensagem no telegram - Ex.: 'send -n -tr'

	# envia a mensagem com as opções se houver
	ShellBot.sendMessage \
	--chat_id $user \
	--text "$msg" \
	--disable_notification true \
	--parse_mode markdown

    r=$?

	unset msg
}





# Inicializando o bot @VovoMaxxiBot
ShellBot.init -t $botToken --return map 



# enviar via comando. Ex. ~$ sendTelegram [userid] '[mensagem]'
[[ -n $1 ]] && { user="$1" ; shift ; msg="$@" ; send ; exit 0 ; }



while :
do

(

	# seleciona o arquivo mais antigo da pasta de mensagens
	msgfile=$( ls -1t $msgs | tail -n 1 )

	# se houver conteúdo
	[[ -n $msgfile ]] && {




		# define o user da mensagem
		case ${msgfile%%-*} in

			'vol') user=$vol ;;
			'status') user=$statusMaxxi ;;
			'precos') user=$promoMaxxi ;;
			'entrega') user=$entregas ;;

			# se o inicio do nome do arquivo for numérico
			# usa este número como ID de user
			*) [[ $(echo "${msgfile%%-*}" | egrep [0-9]) ]] && { user=${msgfile%%-*} ; } || { mv $msgs/$msgfile $msgs/.error/$msgfile ; } ;;
		esac





		# importa a mensagem do arquivo
		msg=$( cat $msgs/$msgfile | sed 's/&/e/g' )

		# ver no terminal
		echo
		echo "$msgs/$msgfile" - $(date +%H:%M:%S)
		echo "Destino: ${msgfile%%-*}"
		echo -e "$msg"

		send # enviar

		# se for um pedido online, guardar a ID da menagem enviada
		[[ $( echo "${msgfile}" | cut -d'-' -f2 ) == 'pedidoOnline' ]] && { pedidoID=$( echo "${msgfile}" | cut -d'-' -f3 ) ; echo "${return[message_id]}" > $ENTREGAS/pedidoOnline-$pedidoID.id ; }



		# remover mensagem da fila
		[[ ${return[ok]} == 'true' ]] && { rm $msgs/$msgfile ; } || { mv $msgs/$msgfile $msgs/.error/$msgfile ; }

	}
)

done