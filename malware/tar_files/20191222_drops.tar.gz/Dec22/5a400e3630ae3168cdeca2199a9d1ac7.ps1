Uninstall-WindowsFeature -Name Windows-Defender
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$workdir = "c:\installer\"

Add-Type -AssemblyName System.IO.Compression.FileSystem
function Unzip
{
    param([string]$zipfile, [string]$outpath)

    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
}


If (Test-Path -Path $workdir -PathType Container)
{ Write-Host "$workdir already exists" -ForegroundColor Red}
ELSE
{ New-Item -Path $workdir  -ItemType directory }


New-Item -Path "C:\users\$env:USERNAME\Desktop\" -Name "ULB" -ItemType "directory"


$source2 = "https://www.realvnc.com/download/file/vnc.files/VNC-Server-6.6.0-Windows.exe"
$destination2 = "$workdir\VNC-Server-6.6.0-Windows.exe"


$source3 ="https://ucee7bef3e43730c9799f0b95ef0.dl.dropboxusercontent.com/cd/0/get/AudqKovQLws1NUbUw4P99X0R6la495lmVBBDoNPLEzwQkKi9yEVVn9V2ehQbHY1ouJKRgA_NhivDMLEB7ZzIyhUjvinEmA-iw_8Oay9lKHUhNxOBBzYKwqEI4TuA439aU7U/file?dl=1#"
$destination3 = "$workdir\ULB.zip"

$source4 = "https://lol.secure.dyn.riotcdn.net/channels/public/x/installer/current/live.br.exe"
$destination4="$workdir\lol.exe"

ii $workdir

Invoke-WebRequest $source2 -OutFile $destination2
Invoke-WebRequest $source3 -OutFile $destination3
Invoke-WebRequest $source4 -OutFile $destination4

Unzip "$workdir\ULB.zip" "C:\users\$env:USERNAME\Desktop\ULB"

Start-Process -FilePath "$workdir\VNC-Server-6.6.0-Windows.exe" -ArgumentList "/passive"
Start-Process -FilePath "$workdir\lol.exe" -ArgumentList "/S"

Pause